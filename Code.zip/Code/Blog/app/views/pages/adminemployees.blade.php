

<?php

/*
########################################################
# Author: Luke Gassmann
# Purpose: This allows admin users to view all employees
########################################################

*/
?>


@extends('layouts.adminLayout')

@section('title')
    Admin Employees
@stop



@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminEmployees/adminemployeesstyles.css"/>
        
    <?php 

include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminEmployees/adminemployeesmobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
        <script src="Resources/Pages/AdminEmployees/adminemployeesanimate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
        
        
        window.onload = main();
    })
</script>

@stop


@section('breadcrumb')
	/ <a href="/adminEmployees">Admin Employees</a>
@stop

@section('introtabletitle')
    Admin Employees
@stop

@section('breadcrumbRoot')
    <a href="/adminHome">Home</a>
@stop

@section('introtableusertype')
    Administrator
@stop



    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')       
    <table class="mainTableContent">
        <tr>
            <td width=50%>
                @include('includes.introTable')
            </td>
            
            <!--
################################################################################
    Contents: Create Options
################################################################################
    -->
            <td>
                <div class="createDiv">
                    <p class="createTitle">Create a new Employee</p>
                    <p create_type="C" class="createButton">Council Member</p>
                    <p create_type="M" class="createButton">Maintenance Worker</p>
                </div>
            </td>
        </tr>
        
        <!--
################################################################################
    Contents: Group Search Options
################################################################################
    -->
        <tr>
            <td style="background-color: rgba(230, 230, 250, 0.5)" colspan="2">
                <p class="reviewTitle">Review Group</p>
            </td>
        </tr>
        <tr>
            <td width=50%>
                <div class="reviewGroupImage" id="reviewGroupImage1">
                    <p>Council Members</p>
                </div>
            </td>
            <td>
                <div class="reviewGroupImage" id="reviewGroupImage2">
                    <p>Maintenance Workers</p>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <div class="searchImageDiv">
                    <div class="searchBar">
                        <input type="email">
                        <img id="searchUsersButton" src="/Resources/Images/next.png">
                    </div>
                    
                    <p class="comment">Type to Search Users here</p>
                </div>
            </td>
        </tr>
        <!--
################################################################################
    Contents: Users Table
################################################################################
    -->
        <tr>
            <td colspan="2">
                <div class="centered">
                    <div id="resultsTable">
                        <table>
                            <tr>
                                <td>
                                    <p>Image</p>
                                </td>
                                <td>
                                    <p>Name</p>
                                </td>
                                <td>
                                    <p>Email</p>
                                </td>
                                <td>
                                    <p>Type</p>
                                </td>
                                <td>
                                    <p>Actions</p>
                                </td>
                            </tr>
                            
                            <?php 
                            
                                function display_table_contents($employees){
                                    foreach($employees as $employee){
                                    
                                    ?>
                                        <tr>
                                            <td>
                                                <div class="titleHeaderProfileImg employeeTableImage" style="background-image: url('/Resources/Images/Saved/<?php echo $employee["picture"]; ?>')"></div>
                                            </td>
                                            <td>
                                                <?php echo $employee["name"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $employee["email"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $employee["user_type"]; ?>
                                            </td>
                                            <td>
                                                <p employeeNumber="<?php echo $employee["id"]; ?>" class="userViewButton">View</p>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                                                
                                
                                $employees = $information["employees"];
                                display_table_contents($employees);
                                ?>
                                
                            
                        </table>
                    </div>
                </div>
            </td>
        </tr>
    </table>
@stop

