
<!-- Written by: Nicolas Euliarte, Joseph Lloyd & Joshua Walker -->
<!-- Purpose: Dynamically adapt view to the single maintanance bowser -->

<!-- Check homeLayout.blade.php for the section titles and meanings -->
<!-- include the homeLayout template -->

@extends('layouts.homeLayout')

<!-- Additional css & js -->
@section('preload')
	@include('includes.alertSuccess')
	
	<link href="Resources/CSS/bootstrap-4.3.1.css" rel="stylesheet">
	<style>
		/* bootstrap overwrite */
		p {
			margin-top: auto;
			margin-bottom: auto;
		}
		* {
			box-sizing: initial;
		}
		body {
			font-weight: initial;
			line-height: initial;
		}
		img {
			vertical-align: initial;
		}
		.breadcrumb {
			display: block;
			flex-wrap: initial;
			padding: 0;
			margin-bottom: 0;
			background-color: initial;
			border-radius: 0;
		}
		.container {
			max-width: none;
		}
	</style>
@stop
@section('pageCSS')
<!-- css for the page -->
	<link href="Resources/Pages/BowsersNearMe/styles.css" rel="stylesheet">

	<?php
		include "Resources/PHP/mobileCheck.php";
		if( isMobile() ) {?>
			<link rel="stylesheet" type="text/css" href="/Resources/Pages/BowsersNearMe/mobileStyles.css"/>
	<?php } ?>
@stop
@section('postLoad')
	
@stop
@section('pageJS')
<!-- javascript file for the page -->
	<script src="Resources/Pages/BowsersNearMe/bowsers.js" type="text/javascript"></script>
@stop



	
<!-- Change Title section (tab name) -->
@section('title')
    Bowsers Near Me
@stop

<!-- Create breadcrumb -->
@section('breadcrumb')
    <a href="/">Home</a> / <a href="/bowserNearMe">Bowsers Near Me</a>
@stop




<!-- Update page title -->                    
@section('pagetitle')
	<h1 id="titleHomeText" class="title">Bowsers Near Me </h1>
@stop

<!-- Update Subtitle for extra information -->
@section('subtitlesection')
	<p id="subtitleSection" class="subtitleClass">Here you can view information about the bowsers nearest to your current location!</p>
@Stop




@section('swapTableTitle1')
	All bowsers
@stop
@section('swapTableTitle2')
	Details
@stop



@section('swapTableArea1')
	<!-- Map and list of all bowsers -->
	<section class="container">
		<div class="row info">
<!-- additional styles if viewed on mobile device -->
<?php if( isMobile() ) {?>
			<div class="col-lg-7 map_Info">
<?php } else { ?>
			<div class="col-md-7 map_Info" >
<?php } ?>
				<?php $mapChar = 'A'; ?>
				@include('includes.map')
			</div>
<?php if( isMobile() ) {?>
			<div class="col-lg-5 tbl_Info">
<?php } else { ?>
			<div class="col-md-5 tbl_Info">
<?php } ?>
		        <table class="key bowsersTable">
		            <tr>
		                <td>
		                    <p class="keyHeading bowserHeader">Active Bowser</p>
		                </td>
		            </tr>
		        </table>
		        <table class="key bowsersTable">
		            <tr class="inactive">
		                <td>
		                    <p class="keyHeading bowserHeader">InActive Bowser</p>
		                </td>
		            </tr>
		        </table>
				<br/>
		        <table class="bowsersTable" id="bowsersTable">
		            <tr>
		                <td width="15%">
		                    <p class="bowserHeader">Distance</p>
		                </td>
		                <td width="15%">
		                    <p class="bowserHeader">Size</p>
		                </td>
		                <td width="55%">
		                    <p class="bowserHeader">Address</p>
		                </td>
		                <td width="15%">
		                    <p class="bowserHeader">Details</p>
		                </td>
		            </tr>
		            <tr class="bowserRow">
		                <td width="15%">
		                    <p></p>
		                </td>
		                <td width="15%">
		                    <p></p>
		                </td>
		                <td width="55%">
		                    <p>Loading ...</p>
		                </td>
		                <td width="15%">
							<p></a>
						</td>
		            </tr>
		        </table>
			</div>
		</div>
	</section>
@stop

@section('swapTableArea2')
	<!-- Map and details for single bowser -->
	<section class = "container">
		<div class="row info">
<!-- additional changes if viewed on mobile -->
<?php if( isMobile() ) {?>
			<div class="col-lg-7 map_Single">
<?php } else { ?>
			<div class="col-md-7 map_Single" >
<?php } ?>
				<?php $mapChar = 'B'; ?>
				@include('includes.map')
			</div>
<?php if( isMobile() ) {?>
			<div class="col-lg-5 tbl_Single">
<?php } else { ?>
			<div class="col-md-5 tbl_Single">
<?php } ?>
				<div class="problemDetail">
					<input type="hidden" id="searchBarBowser">
					
					<div class = "bowserInfo">
						<p>Distance: </p>
						<span id="bowser-distance">N/A</span>
					</div>
					
					<div class = "bowserInfo">
						<p>Size: </p>
						<span id="bowser-size">N/A</span>
					</div>
					
					<div class = "bowserInfo long">
						<p>Address: </p>
						<span id="bowser-address">N/A</span>
					</div>
					
				</div>
			</div>
		</div>
	</section>
@stop


<!-- Page content -->
@section('maincontents')
	<div class="padd">
		@include("includes.swapTable")
	</div>
@stop













