
<!-- Use layout based on user type -->
<?php
	$layout = 'layouts.default';
	
	if( Auth::user()->user_type == 'M' ) {
		
		$layout = 'layouts.maintenanceLayout';
	}
?>

@extends($layout)
	


<!-- Additional css & js -->
@section('preLoad')
	@include('includes.alertSuccess')
	
	<link href="Resources/CSS/bootstrap-4.3.1.css" rel="stylesheet">
	<style>
		/* bootstrap overwrite */
		p {
			margin-top: auto;
			margin-bottom: auto;
		}
		* {
			box-sizing: initial;
		}
		body {
			font-weight: initial;
			line-height: initial;
		}
		img {
			vertical-align: initial;
		}
		.container {
			max-width: none;
		}
	</style>
@stop
@section('pageCSS')
	<link href="Resources/Pages/TaskList/styles.css" rel="stylesheet">

	<?php
		include "Resources/PHP/mobileCheck.php";
		if( isMobile() ) {?>
			<link rel="stylesheet" type="text/css" href="/Resources/Pages/TaskList/mobileStyles.css"/>
	<?php } ?>
@stop
@section('postLoad')
	
@stop
@section('pageJS')
	<script src="Resources/Pages/TaskList/tasks.js" type="text/javascript"></script>
@stop



<!-- Page items -->
@section('title')
    Task List
@stop

@section('header')
	@parent
@stop



@section('breadcrumb')
	<?php if( Auth::user()->user_type == 'C' ) { ?>
		/ <a>Task List</a>
	<?php } ?>
@stop

@section('introtabletitle')
    Task List
@stop



@section('swapTableTitle1')
	All Tasks
@stop
@section('swapTableTitle2')
	Details
@stop



@section('swapTableArea1')
	<section class="container">
		<div class = "dateTime">
			<span id="timeA" class = "time"></span>
			<span id ="dateA" class = "date"></span>
		</div>
		<div class="row info">
<?php if( isMobile() ) {?>
			<div class="col-xl-7 map_Info">
<?php } else { ?>
			<div class="col-md-7 map_Info" >
<?php } ?>
				<?php $mapChar = 'A'; ?>
				@include('includes.map')
			</div>
<?php if( isMobile() ) {?>
			<div class="col-xl-5 tbl_Info">
<?php } else { ?>
			<div class="col-md-5 tbl_Info">
<?php } ?>
		        <table class="key tasksTable">
		            <tr>
		                <td>
		                    <p class="keyHeading taskHeader">Available Task</p>
		                </td>
		            </tr>
		        </table>
		        <table class="key tasksTable">
		            <tr class="myTask">
		                <td>
		                    <p class="keyHeading taskHeader">Acquired Task</p>
		                </td>
		            </tr>
		        </table>
				<br/>
		        <table class="tasksTable" id="tasksTable">
		            <tr>
		                <td width="15%">
		                    <p class="taskHeader">Priority</p>
		                </td>
		                <td width="15%">
		                    <p class="taskHeader">Distance</p>
		                </td>
		                <td width="15%">
		                    <p class="taskHeader">Size</p>
		                </td>
		                <td width="40%">
		                    <p class="taskHeader">Action</p>
		                </td>
		                <td width="15%">
		                    <p class="taskHeader">Details</p>
		                </td>
		            </tr>
		            <tr class="taskRow">
		                <td width="15%">
		                    <p></p>
		                </td>
		                <td width="15%">
		                    <p></p>
		                </td>
		                <td width="15%">
		                    <p></p>
		                </td>
		                <td width="40%">
		                    <p>Loading ...</p>
		                </td>
		                <td width="15%">
							<p></a>
						</td>
		            </tr>
		        </table>
			</div>
		</div>
	</section>
@stop

@section('swapTableArea2')
	<section class = "container">
		<div class = "dateTime">
			<span id="timeB" class = "time"></span>
			<span id ="dateB" class = "date"></span>
		</div>
		<div class="row info">
<?php if( isMobile() ) {?>
			<div class="col-xl-7 map_Single">
<?php } else { ?>
			<div class="col-md-7 map_Single" >
<?php } ?>
				<div class="locationMessage">
					<p>
						Location of Problem:
					</p>
				</div>
				<?php $mapChar = 'B'; ?>
				@include('includes.map')
			</div>
<?php if( isMobile() ) {?>
			<div class="col-xl-5 tbl_Single">
<?php } else { ?>
			<div class="col-md-5 tbl_Single">
<?php } ?>
				<div class = "options">
					<input type="hidden" id="searchBarBowser">
					
					<?php if( Auth::user()->user_type == 'M' ) { ?>
						<button onclick="finishTask()" id="finishTask" class="hidden">Finished</button>
						<br/>
					<?php } ?>
					
					<span><button onclick="location.href='/messageDesktop'" id="contactBtn">Contact</button></span>
					
					<?php if( Auth::user()->user_type == 'M' ) { ?>
						<span><button onclick="aquireTask()" id="aquireTask">Aquire</button></span>
						<span><button onclick="unassignTask()" id="unassignTask" class="hidden">Un-Assign</button></span>
					<?php } ?>
				</div>
				
				<div class="problemDetail">
					
					<div class = "taskInfo">
						<p>Task ID: </p>
						<span id="task-id">N/A</span>
					</div>
					
					<div class = "taskInfo">
						<p>Bowser ID: </p>
						<span id="bowser-id">N/A</span>
					</div>
					
					<div class = "taskInfo">
						<p>Priority: </p>
						<span id="task-priority">N/A</span>
					</div>
					
					<div class = "taskInfo">
						<p>Distance: </p>
						<span id="task-distance">N/A</span>
					</div>
					
					<div class = "taskInfo">
						<p>Size: </p>
						<span id="task-size">N/A</span>
					</div>
					
					<div class = "taskInfo">
						<p>Action: </p>
						<span id="task-action">N/A</span>
					</div>
					
					<div class ="taskDetails">
						<p>Details: </p>
						<div id="task-problem">Select task from list to view details</div>
					</div>
					
					<div class="taskDetails">
						<p>Additional information about problem from council employee: </p>
						<div id="task-details">N/A</div>
					</div>
				</div>
			</div>
		</div>
	</section>
@stop


<!-- Page content -->
@section('content')
	<?php if( Auth::user()->user_type == 'C' ) { ?>
			@include("includes.introTable")
	<?php } ?>
	
	@include("includes.swapTable")
@stop

