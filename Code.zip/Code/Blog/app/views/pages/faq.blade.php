<!-- Author: Nicolas Euliarte Veliez -->
<!-- Purpose: Faq page -->

<!-- Check homeLayout.blade.php for the section titles and meanings -->
@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/FAQ/faqStyles.css"/>
@stop

@section('title')
    FAQ
@stop

@section('breadcrumb')
    / <a href="/">Home</a> / <a href="/faq">FAQ</a> /
@stop
          
@section('uppercontents')
        <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
@stop

<!-- Main Html code: body-->
@section('maincontents')
            <div id="container" style="padding-top: 15px;">
                <div class="accordion">
					<!-- FAQ List -->
                    <div class="accordion-item" id="question1">
                        <a class="accordion-link" href="#question1">
                            How Do I report an Issue?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                To report an issue please use the report system to report any issues. Please follow:
								<br>
								<a href="https://ct5038group2-ct5038.uogs.co.uk/contact">Contact<a>
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question2">
                        <a class="accordion-link" href="#question2">
                            How do I find bowsers near my location?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                The Bowsers Near Me page can be accessed here: 
								<br>
								<a href="https://ct5038group2-ct5038.uogs.co.uk/bowserNearMe">Bowser Near Me Link<a>
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question3">
                        <a class="accordion-link" href="#question3">
                            When are the bowser getting refilled?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                To see refilling schedules please see the refilling page or you can use the Bowser location page to find more information:
								<br>
								<a href="https://ct5038group2-ct5038.uogs.co.uk">Home, under 'Refill Time Table'</a>
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question4">
                        <a class="accordion-link" href="#question4">
                            What to do if the bowser is empty?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                Please use the report form to notify us of the empty Bowsers:
								<br>
								<a href="https://ct5038group2-ct5038.uogs.co.uk/contact">Contact</a>
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question5">
                        <a class="accordion-link" href="#question5">
                            What to do if there is no bowser nearby?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                Please notify us via email: 
								<br> WaterCapitol@Bowsers.co.uk
								<br> Or call us:
								<br> 0321 452 5632
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question6">
                        <a class="accordion-link" href="#question6">
                            What should I do in an emergency?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                The worse thing to do is panic.
								<br> If you have an emergency are in immediate danger please call 999.
								<br> Alternatively call 101 or 111 to ask for advice.
								<br> Any urgent bowser issues please call us on 0321 452 5632. 
								<br> Or 24/7 number if out of 9 - 17 hours is 0324 256 2463.
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question7">
                        <a class="accordion-link" href="#question7">
                            What bowsers does Water Capitol use?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                We use 2000 Litres Water and Drinking Bowsers. 
								<br> This is to utilise the maximum room of water for the most people in a given radius. 
                            </p>
                        </div>
                    </div>
                    <div class="accordion-item" id="question8">
                        <a class="accordion-link" href="#question8">
                            How to do I use the Bowsers?
                            <ion-icon class ="ion ion-md-add" name="add"></ion-icon>
                            <ion-icon class ="ion ion-md-remove" name="remove"></ion-icon>
                        </a>
                        <div class="answer">
                            <p>
                                By using the valve located at the bottom of the bowser the water will be dispensed.
								<br> Please ensure you turn the valve off as soon as you’re done to reduce the waste of water.  
                            </p>
                        </div>
                    </div>
                </div>
            </div>
@stop

@include('layouts.homeLayout')















