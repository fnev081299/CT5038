<?php

/*
########################################################
# Author: Luke Gassmann
# Purpose: This allows admin users to view employees
########################################################

*/


?>

@extends('layouts.adminLayout')

@section('title')
    Admin Employees
@stop



@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminEmployeeView/adminemployeeviewstyles.css"/>
        
    <?php 

include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminEmployeeView/adminemployeeviewmobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
	    <!-- provide the csrf token -->
	    <meta name="_token" content="{{csrf_token()}}" />

        <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


        <script src="Resources/Pages/AdminEmployeeView/adminemployeeviewanimate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
         
        // Drop down
        $(".optionDropDownStatus").click(function(){
            $(".constituencyButtonStatus").attr("statusvalue", $(this).attr("statusvalue"));
            $(".constituencyButtonStatus").html($(this).html() + '<span class="caret"></span>');
            $(".constituencyStatusInformation").val($(this).attr("statusvalue"));
        })
        
        
        // Display Employees Graph
        <?php 
            if ($_GET["user_account"] != "new"){
                $user_account = $information["user_account"];
                
                // Get user type
                $user_type = $user_account["user_type"];
                
                // Get all users tasks
                $user_task_numbers = $user_account["reporter_details"]["user_number"];

                // Adjust depending on job
                if ($user_type == "C"){
                    $other_task_numbers = $user_account["reporter_details"]["other_number"];
                    $other_print = "All other tasks";
                    $chartTitle = "Submitted Tasks";
                }
                else{
                    $other_task_numbers = $user_account["reporter_details"]["available"];
                    $other_print = "Available Tasks";
                    $chartTitle = "Accepted Maintenance Tasks";
                }
                
                // Get average employee completion rate
                $all_tasks = $user_account["reporter_details"]["all"];

                $all_tasks_divide = array();
                if ($user_type == "M"){
                    $value = "UserID";
                }
                else{
                    $value = "ReporterID";
                }
                
                foreach ($all_tasks as $task){
                    if (!isset($all_tasks_divide[$task[$value]])){
                        $all_tasks_divide[$task[$value]] = 1;
                    }
                    else{
                        $all_tasks_divide[$task[$value]] += 1;
                    }
                }


                $total = 0;
                foreach ($all_tasks_divide as $user){
                    $total += $user;
                }

                $average_task_numbers = $total / sizeof($all_tasks_divide);


            ?>
            
            // Create datafor graph 
            data = {
                datasets: [{
                    data: [<?php echo $average_task_numbers; ?>,
                           <?php echo $user_task_numbers; ?>,
                           <?php echo $other_task_numbers; ?>
                          ],
                    backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(182, 3, 252, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(182, 3, 252, 1)'
                        ],
                        borderWidth: 1

                }],

                // These labels appear in the legend and in the tooltips when hovering different arcs
                labels: [
                    'Average Employee',
                    "<?php echo $user_account["name"];?>",
                    "<?php echo $other_print; ?>"
                ]
            };

            // Create graph
            var detailsChart = document.getElementById('detailsChart');

            var myDoughnutChart = new Chart(detailsChart, {
                type: 'doughnut',
                data: data,
                options:{
                    title:{
                        display: true,
                        text: "<?php echo $chartTitle ?>"
                    }
                }
            });
        
        
            
        // Select the Map Div and focus on this location
        var mainMap = new google.maps.Map(document.getElementById('map'), {
            center: {lat: {{$user_account["constituency_data"]["latitude"]}}, lng: {{$user_account["constituency_data"]["longitude"]}}},
            zoom: 13,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        
        
        // Create Map of Bowsers within the users constituency
        @foreach($information["user_account"]["bowser_data"] as $bowser)
            <?php
        
            // Bowser Data
            $bowserInfo = $bowser["attributes"];
            $bowserlon = $bowserInfo["longitude"];
            $bowserlat = $bowserInfo["latitude"];
            $bowserID = $bowserInfo["BowserID"];
            $bowserStatus = $bowserInfo["bowserStatus"];
            $bowserAddress = $bowserInfo["bowserAddress"];
            $bowserRadius = $bowserInfo["size"];
            ?> 
        
            // Set icon and position for bowser
            var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});

            var icon = {

                url: @if($bowserStatus == 0)         
                        "Resources/Images/waterMap.png"
                    @elseif ($bowserStatus == 1)
                        "Resources/Images/tools.png"
                    @elseif ($bowserStatus == 2)
                        "Resources/Images/waterMap.gif"
                    @elseif ($bowserStatus == 3)
                        "Resources/Images/waterMapDeploy.png"
					@else
						"Resources/Images/waterMap.png"
                    @endif,
                scaledSize: new google.maps.Size(50, 50), // scaled size
            };
            
        // Create marker and radius
            var marker{{$bowserID}} = new google.maps.Marker({
                position: myLatlng,
                title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
                map: mainMap,
                icon: icon
            });

            // Add circle overlay and bind to marker
            var circle = new google.maps.Circle({
              map: mainMap,
              radius: {{$bowserInfo["size"]}}/10,    // 10k Liter = 1km
              fillColor: '#AA0000',
                strokeColor: '#6600AA',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#6600AA',
                fillOpacity: 0.35,
            });
            circle.bindTo('center', marker{{$bowserID}}, 'position');
        

        @endforeach
        
            window.onload = main(<?php echo $user_account["id"]; ?>);

        
        
        
        <?php } else {
        ?>
            window.onload = mainCreate("<?php echo $_GET['type']; ?>");
        <?php } ?>
        
        
    })
</script>

@stop


@section('breadcrumb')
    / <a href="/adminEmployees">Admin Employees</a> / <a href="/adminEmployeeView?user_account=<?php echo $_GET['user_account']; ?>"><?php 
        
        if ($_GET['user_account'] == "new"){
            if ($_GET['user_account_type'] == "C"){
                echo "New Council Employee";
            }
            elseif ($_GET['user_account_type'] == "M"){
                echo "New Maintenance Employee";
            }
        }
        else{
            echo $information['user_account']["name"] . "'s Account";
        }
        
        
        ?></a>
@stop

@section('introtabletitle')
    <?php 
        
        if ($_GET['user_account'] == "new"){
            echo "New Employee";
        }
        else{
            echo $information['user_account']["name"] . "'s Account";
        }
        
        
        ?>
@stop

@section('breadcrumbRoot')
    <a href="/adminHome">Home</a>
@stop

@section('introtableusertype')
    Administrator
@stop


<?php

    if ($_GET['user_account'] == "new"){
        $information['user_account']["name"] = "New User";
        $information['user_account']["picture"] = "../userDefault.png";
    }

?>

    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')
@include('includes.alertSuccess')
    <table class="mainTableContent">
        <tr>
            <td width=75%>
                @include('includes.introTable')
            </td>
            <!--
################################################################################
    Contents: Users Image
################################################################################
    -->
            <td>
                <div class="users_account_image" style="background-image:url(/Resources/Images/Saved/<?php echo $information['user_account']["picture"] ?> )">
                    
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <div class="centered">
                    <table class="detailsRowTable">
                        <tr>
                            
                            <!--
################################################################################
    Contents: New User Form
################################################################################
    -->
                            <td width=20% <?php if ($_GET['user_account'] == "new"){echo "colspan='2'";} ?>>
                                <?php if ($_GET['user_account'] != "new"){?>
                                    <canvas id="detailsChart" width="400" height="400"></canvas>
                                <?php } else { ?>
                                
                                <input name="type" id="type" style="display:none" value="<?php echo $_GET["user_account_type"]; ?>">
                                <table class="createUserTable">
                                    <tr>
                                        <td>
                                            <div class="inputDetails">
                                                <input name="name" id="name" type="text" placeholder="Name" autocomplete="off" required>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="inputDetails">
                                                <input name="email" id="email" type="email" placeholder="Email" autocomplete="off" required>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php if ($_GET["user_account_type"] == "C"){?>
                                    <tr>
                                        <td>
                                            
                                            <div class="dropdown constituencySegments">
                                                <button statusvalue="" id="constituency" class="btn btn-primary dropdown-toggle constituencyButtonStatus" type="button" data-toggle="dropdown">
                                                    
                                                    Select Constituency
                                                    
                                                <span class="caret"></span></button>
                                                <ul class="dropdown-menu constituencySegments">
                                                    
                                                    <?php foreach($information["constituencies"] as $constituency){ ?>
                                                        <li><a statusValue="<?php echo $constituency['ConstituencyID']; ?>" class="optionDropDownStatus"><?php echo  $constituency['ConstituencyID'] . ": " . $constituency['constituencyName']; ?></a></li>
                                                    <?php } ?>
                                                </ul>
                                              </div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                    <tr>
                                        <td>
                                            <button id="createAccount" class="optionButton">Create Account</button>
                                        </td>
                                    </tr>
                                </table>
                                
                                <?php } ?>

                            </td>
                            
                            <!--
################################################################################
    Contents: Existing User information
################################################################################
    -->
                            <?php if ($_GET['user_account'] != "new"){?>
                            <td width=80% style="vertical-align: top;">
                                
                                <table class="detailsTable">
                                    <tr>
                                        <td colspan="2">
                                            <p class="detailsHeading">Account Details</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="detailsKey">Account Number: </p>
                                        </td>
                                        <td>
                                            <p class="detailsValue"><?php echo $_GET["user_account"]; ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="detailsKey">Name: </p>
                                        </td>
                                        <td>
                                            <p class="detailsValue"><?php echo $user_account["name"]; ?></p>
                                        </td>
                                    </tr>
                                    <?php if ($user_type == "C"){?>
                                    <tr>
                                        <td>
                                            <p class="detailsKey">Constituency: </p>
                                        </td>
                                        <td>
                                            <p class="detailsValue"><?php echo $user_account["constituency_data"]["constituencyName"]; ?></p>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                    <tr>
                                        <td>
                                            <p class="detailsKey">User Type: </p>
                                        </td>
                                        <td>
                                            <p class="detailsValue"><?php if ($user_type == "M"){
                                                                            echo "Maintenance Worker";
                                                                         } else{
                                                                            echo "Council Member";
                                                                         }   ?></p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <p class="detailsHeading">Actions</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <p id="resetPasswordAccount" class="optionButton">Reset Password</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <p id="deleteAccount" class="optionButton">Delete Account</p>
                                        </td>
                                    </tr>
                                </table>
                                
                            </td>
                            <?php } ?>
                        </tr>
                        
                        <!--
################################################################################
    Contents: Users Map
################################################################################
    -->
                            <?php if ($_GET['user_account'] != "new"){ ?>
                            <tr>
                                <td colspan="2">
                                    <div id="map"></div>
                                </td>
                            </tr>
                            <?php } ?>
                    </table>
                </div>
            </td>
        </tr>
    </table>
@stop

