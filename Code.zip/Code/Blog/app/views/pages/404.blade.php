<!DOCTYPE html>

<!--
######################################################################
 Author : Josh
 Description : 404 page - basic page to show when the page is not found
######################################################################
-->

<html>
    
    <head>
	    <link rel="stylesheet" type="text/css" href="Resources/CSS/fonts.css"/>
	    
		<style>
			body {
				width: 100vw;
				height: 100vh;
				margin: 0;
			}
			
			.align {
				text-align: center;
				position: fixed;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
			}
			
			img {
				height: auto;
				width: 15vw;
			}
			
			h1 {
			    font-family: caviar;
			    font-size: 5vw;
			    line-height: 20px;
			}
			
			p {
			    font-family: mainRegular;
			    font-size: 2vw;
			}
		</style>
    </head>
    
    
    <body>
		
		<div class="align">
			<h1>Oops!</h1>
			<p>404 - PAGE NOT FOUND</p>
			 <img src="Resources/Images/spiltWater.png" alt="spilt water">
		</div>
		
    </body>
</html>

