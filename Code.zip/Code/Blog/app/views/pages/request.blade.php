<!-- Author: Nicolas Euliarte Veliez -->
<!-- Purpose: Dynamically adapting the public request -->

<?php

	// Check if this page is opened on a mobile
    require "Resources/PHP/mobileCheck.php";

?>

@section('preLoad')
    <!-- provide the csrf token -->
    <meta name="_token" content="{{csrf_token()}}" />
    
	<link href="Resources/CSS/bootstrap-4.3.1.css" rel="stylesheet">
@stop

@section('pageJS')
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap"></script>
        <script src="Resources/Pages/Home/homeAnimate.js"></script>
		<script src="Resources/JS/request.js" type="text/javascript"></script>
        <script type="text/javascript"> $(document).ready(function(){window.onload = mainRequest()});</script>
        @stop

@section('upperbackground')
    @include('includes.slideShow')
    @yield('slideShow')
@stop
      
<!-- upper content of the page -->
@section('uppercontents')
<div class="slideShowTitleSector" border="0">
    <titleSector>
        <p>Public Request</p>
    </titleSector>
    <p>
        "Help us find and fix any possible problems that may occur durring this disaster"
    </p>
</div>
@stop

<!-- main constents of the page -->
@section('maincontents')
	<form class="form-group" name="requestForm" id = "form" onsubmit="newRequest(); return false" >
		<div class="boxWrapper">
            <div class="dropDown">
                <label for="drop-down">Type of Problem</label>
                <br><br>
                <select name="dropdown" id="dropdown" class="dropdown" style="width: 250px; height: 25px">
                    <option>Refill</option>
                    <option>Flooded Area</option>
                    <option>Leaking</option> 
                    <option>Vandilism</option>
                    <option>Observation</option>
				</select>
                <br><br>
                <div class="description" style="width: 250px; height: 300px">
                    <label for="desc">Description</label>
                    <br><br>
                    <textarea name="description" id="desc" class="description-text" style="width: 250px; height: 250px"></textarea>
                    <br><br>
                </div>
                <div class="emailAdder">
                    <label for="eml">Email - If necessary</label>
                    <br><br>
                    <input name="emailAdder" id="eml" class="email-text" style="width: 250px">
                    <br><br>
                </div>
                <div class="sender">
                    <button name="sender" type="submit" class="send-button" onclick = "Confirm()" style="width: 250px">Send</button>
                </div>
            </div>
            <div class="map" id="map">
                map here
            </div>
        </div>
	</form>

<script>
	
function Confirm() {
	alert("Your inquiry has been sent. Thank you for your feedback");
}
</script>
@stop

<!-- css locations -->
@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Home/homeStyles.css"/>
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Request/request.css"/>
<?php
	// If this page is in mobile load the mobile CSS as well
    if(isMobile()){
        ?>
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Home/homeStylesMobile.css"/>
<?php } ?>
@stop

@include('layouts.homeLayout')










