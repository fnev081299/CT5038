
<?php

/*
########################################################
# Author: Luke Gassmann
# Purpose: This allows admin users to view constituency
#          information
########################################################

*/


?>


@extends('layouts.adminLayout')

@section('title')
    Admin Employees
@stop



@section('pageCSS')
<!-- page CSS -->
        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminConstituencies/adminconstituenciesstyles.css"/>
        
    <?php 

//if on mobile, use the mobiles styles sheet as well
include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminConstituencies/adminconstituenciesmobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
		<!-- include the javascript files -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


        <script src="Resources/Pages/AdminConstituencies/adminconstituenciesanimate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
        
        
        // Select the Map Div and focus on this location
        var mainMap = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 54.209607, lng: -2.228938},
            zoom: 5,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        
        // For each consituency load in data
        @foreach($information["constituencies"] as $constituency)
            <?php
            $bowserInfo = $constituency["attributes"];
            $bowserlon = $bowserInfo["longitude"];
            $bowserlat = $bowserInfo["latitude"];
            $bowserID = $bowserInfo["ConstituencyID"];
            $bowserAddress = $bowserInfo["constituencyName"];
            $bowserRadius = $bowserInfo["radius"];
            ?>
        
            // Set icon and location
            var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});

            var icon = {

                url: "Resources/Images/building.png",
                scaledSize: new google.maps.Size(30, 30), // scaled size
            };
            
            // Create marker and radius
            var marker{{$bowserID}} = new google.maps.Marker({
                position: myLatlng,
                title:"<?php echo "Constituency ID: " . $bowserID . " - " . $bowserAddress; ?>",
                map: mainMap,
                icon: icon
            });

            // Add circle overlay and bind to marker
            var circle = new google.maps.Circle({
              map: mainMap,
              radius: {{$bowserInfo["radius"]}}/10,    // 10k Liter = 1km
              fillColor: '#AA0000',
                strokeColor: '#6600AA',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#6600AA',
                fillOpacity: 0.35,
            });
            circle.bindTo('center', marker{{$bowserID}}, 'position');
            
            // Event Listener for future use
            google.maps.event.addListener(marker{{$bowserID}}, 'click', function() {
                
            });

        @endforeach
    })
</script>

@stop


@section('breadcrumb')
    / <a href="/adminConstituencies">Constituencies</a>
@stop

@section('introtabletitle')
    Constituencies
@stop

@section('breadcrumbRoot')
    <a href="/adminHome">Home</a>
@stop

@section('introtableusertype')
    Administrator
@stop



@section('bbih1heading')
    Number of Constituencies
@stop

@section('bbih2heading')
    Area
@stop

@section('bbih3heading')
    Total Value
@stop



@section('bbih1number')
    {{sizeof($information["constituencies"])}}
@stop

@section('bbih2number')
    UK
@stop

@section('bbih3number')
    {{sizeof($information["constituencies"])}}
@stop


    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')
@include('includes.alertSuccess')
    <table class="mainTableContent">
        <tr>
            <td width=75%>
                @include('includes.introTable')
            </td>
            <td>
                @include('includes.bowserBasicsDiv')
            </td>
        </tr>
        <!--
################################################################################
    Contents: Map
################################################################################
    -->
        <tr>
            <td colspan="2">
                <div class="centered">
                    <div id="map"></div>
                </div>
            </td>
        </tr>
        <!--
################################################################################
    Contents: Constituency Data
################################################################################
    -->
        <tr>
            <td colspan="2">
                <div class="centered">
                <div id="resultsTable">
                        <table>
                            <tr>
                                <td>
                                    <p>Name</p>
                                </td>
                                <td>
                                    <p>Postcode</p>
                                </td>
                                <td>
                                    <p>Radius</p>
                                </td>
                                <td>
                                    <p>Logitude</p>
                                </td>
                                <td>
                                    <p>Latitude</p>
                                </td>
                            </tr>
                            
                            <?php 
                            	//display the contents of the table 
                                function display_table_contents($constituencies){
                                    foreach($constituencies as $constituency){
                                    
                                    ?>
                                        <tr>
                                            <td>
                                                <?php echo $constituency["constituencyName"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $constituency["constituencyPostcode"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $constituency["radius"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $constituency["longitude"]; ?>
                                            </td>
                                            <td>
                                                <?php echo $constituency["latitude"]; ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                                                
                                
                                $constituencies = $information["constituencies"];
                                display_table_contents($constituencies);
                                ?>
                                
                            
                        </table>
                    </div>
                </div>
            </td>
        </tr>
    </table>
@stop

