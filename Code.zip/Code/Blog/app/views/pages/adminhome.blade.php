<?php

/*
########################################################
# Author: Luke Gassmann
# Purpose: This allows admin to see statistics
########################################################

*/


?>
@extends('layouts.adminLayout')

@section('title')
    Admin Statistics
@stop



<?php 
    
    // Get all bowser data
    $active_bowsers = array();
    $repair_bowsers = array();
    $refill_bowsers = array();
    $deploy_bowsers = array();
    $minimal_repair_bowsers = array();
    $aesthetic_repair_bowsers = array();
    $observation_bowsers = array();

    // Format bowser data
    foreach ($information["bowserData"] as $bowser){
        if ($bowser['bowserStatus'] == 0){
            array_push($active_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 1){
            array_push($repair_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 2){
            array_push($refill_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 3){
            array_push($deploy_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 4){
            array_push($minimal_repair_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 5){
            array_push($aesthetic_repair_bowsers, $bowser);
        }
        elseif ($bowser['bowserStatus'] == 6){
            array_push($observation_bowsers, $bowser);
        }
    }
    
    
?>


@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminHome/adminhomestyles.css"/>
        
    <?php 

include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminHome/adminhomemobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
        <script src="Resources/Pages/AdminHome/adminhomeanimate.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
        
        
        
        // Select the Map Div and focus on this location
        var mainMap = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 51.8994, lng: -2.0783},
            zoom: 8,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }); 
        
        
        // Create data for chart
        data = {
            datasets: [{
                data: [<?php echo sizeof($information["maintenanceTasks"]["complete"]); ?>,
                      <?php echo sizeof($information["maintenanceTasks"]["uncomplete"]); ?>
                      ],
                backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)'
                    ],
                    borderWidth: 1
                
            }],

            // These labels appear in the legend and in the tooltips when hovering different arcs
            labels: [
                'Completed',
                'Uncompleted'
            ]
        };
        
        
        // Create doughnut chart
        var maintenanceChart = document.getElementById('maintenanceChart');
        
        var myDoughnutChart = new Chart(maintenanceChart, {
            type: 'doughnut',
            data: data
        });
        
        
        // Create bar chart
        var ctx = document.getElementById('bowserStatusChart');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Active', 'Repair', 'Refilling', 'Deploying', 'Observation'],
                datasets: [{
                    label: 'Bowser Status',
                    data: [<?php echo sizeof($active_bowsers) ?>,
                           <?php echo (sizeof($repair_bowsers) + sizeof($minimal_repair_bowsers) + sizeof($aesthetic_repair_bowsers)) ?>,
                           <?php echo sizeof($refill_bowsers) ?>,
                           <?php echo sizeof($deploy_bowsers) ?>,
                           <?php echo sizeof($observation_bowsers) ?>
                          ],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
        
        
        
        @foreach($information["bowserData"] as $bowser)
            <?php
    
            // For each bowser data
            $bowserInfo = $bowser["attributes"];
            $bowserlon = $bowserInfo["longitude"];
            $bowserlat = $bowserInfo["latitude"];
            $bowserID = $bowserInfo["BowserID"];
            $bowserStatus = $bowserInfo["bowserStatus"];
            $bowserAddress = $bowserInfo["bowserAddress"];
            $bowserRadius = $bowserInfo["size"];
            ?>
        
            // Set position and icon
            var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});

            var icon = {

                url: @if($bowserStatus == 0)         
                        "Resources/Images/waterMap.png"
                    @elseif ($bowserStatus == 1)
                        "Resources/Images/tools.png"
                    @elseif ($bowserStatus == 2)
                        "Resources/Images/waterMap.gif"
                    @elseif ($bowserStatus == 3)
                        "Resources/Images/waterMapDeploy.png"
					@else
						"Resources/Images/waterMap.png"
                    @endif,
                scaledSize: new google.maps.Size(50, 50), // scaled size
            };

            // Set marker and radius
            var marker{{$bowserID}} = new google.maps.Marker({
                position: myLatlng,
                title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
                map: mainMap,
                icon: icon
            });

            // Add circle overlay and bind to marker
            var circle = new google.maps.Circle({
              map: mainMap,
              radius: {{$bowserInfo["size"]}}/10,    // 10k Liter = 1km
              fillColor: '#AA0000',
                strokeColor: '#6600AA',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#6600AA',
                fillOpacity: 0.35,
            });
            circle.bindTo('center', marker{{$bowserID}}, 'position');


        @endforeach
        
        
        window.onload = main();
    })
</script>

@stop


@section('breadcrumb')
    / <a href="/adminHome">Statistics</a>
@stop

@section('introtabletitle')
    Admin Statistics
@stop

@section('breadcrumbRoot')
    <a href="/adminHome">Home</a>
@stop

@section('introtableusertype')
    Administrator
@stop




@section('bbih1heading')
    Total Live Bowsers
@stop



@section('bbih1number')
    {{sizeof($information["bowserLiveData"])}}
@stop

@section('bbih2number')
    {{sizeof($information["bowserData"])}}
@stop

@section('bbih3number')
    {{sizeof($information["bowserOfflineData"])}}
@stop

    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')       
    <table class="mainTableContent">
        <tr>
            <td>
                @include('includes.introTable')
            </td>
            <td>
                @include('includes.bowserBasicsDiv')
            </td>
        </tr>
        
        <!--
################################################################################
    Contents: Bowser Data
################################################################################
    -->
        <tr>
            <td style="background-color: rgba(230, 230, 250, 0.5)" colspan="2">
                <div class="centered">
                    <table class="chartTable">
                        <tr>
                            <td width=40%>
                                <canvas id="bowserStatusChart" width="400" height="400"></canvas>
                            </td>
                            <td class="chartDataP">
                                <p>
                                The following chart shows data regarding the status of all Bowsers across the country.
                                The Bowser status is adjusted and created by Council Members and confirmed by maintenance workers who undertake a Job. Data regarding accepted maintenance tasks can be found on this page.<br>
                                
                                    <br>
                                    <br>
                                    The following details explain what each Status means...<br>
                                <br>
                                </p>
                                <table style="text-align: left; width: 90%; margin: auto;">
                                <?php
                                
                                    foreach ($information["bowserTypes"] as $type){
                                        echo "<tr><td width=30%><b>" . $type['name'] . ":</td><td></b> " . $type['description'] . "<br></td></tr>";
                                    }
                                
                                
                                ?>
                                </table>
                                <p>
                                <br>
                                A break down of this data can be found via a Council Log In of that constituency.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
        
        <!--
################################################################################
    Contents: Maintenance Data
################################################################################
    -->
        <tr>
            <td colspan="2">
                <div class="centered">
                    <table class="chartTable">
                    
                        <tr>
                            
                            <td class="chartDataP">
                                <p>
                                    The following chart shows data regarding the status of all maintenance tasks submitted by Council Members and Constituents.
                                    The Maintenance Tasks are submitted and filtered according to their type and then maintenance workers select work based on their location and type.<br><br>
                                    In the event that work is not set maintenance workers can select work for themselves or council members may submit work to maintenance workers via the Edit Bowser Page.
                                    It is recommended that workers who do not collect work be repremanded according to company guidelines. Uncompleted work will remain on the database until completed or removed via the database linked to the companies server.<br><br>
                                    An overall justification of work can only be completed once the status of the job is affected by the maintenance worker. The worker can change the status once complete, or further observations of the work can be set by council members to monitor and ongoing situation.
                                </p>
                            </td>
                            
                            <td width=40%>
                                <canvas id="maintenanceChart" width="400" height="400"></canvas>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
        
        <!--
################################################################################
    Contents: Map
################################################################################
    -->
        <tr>
            <td colspan="2">
                <div id="map">
                </div>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
                <div class="centered">
                    
                </div>
            </td>
        </tr>
    </table>
@stop

