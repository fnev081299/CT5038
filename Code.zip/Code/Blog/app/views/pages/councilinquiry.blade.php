<!-- Written by: Joseph Lloyd & Nicolas E.V. & Josh Walker -->
<!-- Purpose: Dynamically adapt the website for the contacts page -->

<!-- Check homeLayout.blade.php for the section titles and meanings -->

<!-- Get JS -->
@extends('layouts.default')

@section('title')
    Council Inquiry
@stop

@section('preLoad')
	@include('includes.alertSuccess')
@stop

@section('pageCSS')
    <link rel="stylesheet" type="text/css" href="Resources/Pages/CouncilInquiry/councilinquirystyles.css"/>
    <?php
	include "Resources/PHP/mobileCheck.php";
	if( isMobile() ){
	?>
        <link rel="stylesheet" type="text/css" href="Resources/Pages/CouncilInquiry/councilinquirymobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
    <script src="Resources/Pages/CouncilInquiry/councilInquiry.js"></script>
    
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap"></script>
@stop


    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

@section('swapTableTitle1')
	Categories
@stop
@section('swapTableTitle2')
	Reports
@stop

@section('swapTableArea1')
	<!-- Summary of inquiry catagories -->
	<div class="col col2">
		<table class="tasksTable">
			
			<tr>
				<th width="50%" class="taskHeader">
					Type
				</th>
				<th width="30%" class="taskHeader" style="padding-left: 10%;">
					Count
				</th>
				<th width="20%" class="taskHeader" style="padding-right: 10%;">
				</th>
			</tr>

			@if(isset($repairsCount))
			@foreach($repairsCount as $type => $count)
			<tr>
				<td width="50%" class="taskRow">
					{{$type}}
				</td>
				<td width="30%" class="taskColumn" style="padding-left: 10%; border-right: none;">
					{{$count}}
				</td>
				<td width="20%" class="taskRow" style="padding-right: 10%;">
					<button onclick="showDetails( '{{str_replace(' ', '_', $type)}}' )">Show</button>
				</td>
			</tr>
			@endforeach
			@endif

		</table>
	</div>
@stop
@section('swapTableArea2')
	<!-- Details of inquiries -->
	<div class="col">
		<table class="taskListTable">
			<tr>
				<th width=20% class="taskHeader">
					Type
				</th>
				<th width=50% class="taskHeader">
					Description
				</th>
				<th width=30% class="taskHeader">
					Action
				</th>
			</tr>
			@if(isset($inqueries))
			@foreach($inqueries as $inquery)
			<tr class="taskRow rowOf {{str_replace(' ', '_', $inquery['type'])}}">
				@if($inquery['sendID'] == -1)
				<td >
					<p name="type">{{$inquery["type"]}}</p>
				</td>
				<td >
					BowserID: {{$inquery["bowserID"]}}<br/>
					<br/>
					{{$inquery["address"]}}
				</td>
				<td style="text-align: center;">
					Reports: {{$inquery["count"]}}<br/>
					<br/>
					<button style="display: inline; width: 44%; margin: 2%;" onclick="createTask({{$inquery['bowserID']}}, '{{$inquery['type']}}')">Create Task</button>
					<button style="display: inline; width: 44%; margin: 2%;" onclick="closeInquiries({{$inquery['bowserID']}}, {{$inquery['reportID']}}, '{{$inquery['type']}}', {{$inquery['count']}})">Close Inquiries</button>
				</td>
				@else
				<td >
					<p style="text-align: center;">&#x21B3</p>
				</td>
				<td >
					<p class="description" id="description">{{$inquery['description']}}</p>
				</td>
				<td style="text-align: center;">
					<button onclick="createEmail({{$inquery['sendID']}}, '{{$inquery['description']}}')">Send Reply</button>
				</td>
				@endif
			</tr>
			@endforeach
			@endif
		</table>
	</div>
@stop


@section('breadcrumb')
    / <a href="/Inquiries">Public Inquiries</a>
@stop

@section('introtabletitle')
    Public Inquiries
@stop

@section('introtableusertype')
    Council Member
@stop


<!-- Page content -->
@section('content')

	
	<br>
	@include("includes.introTable")
	<br>
	<br>
	@include("includes.swapTable")
	<br>
	<br>
	
	<!-- form to compose email -->
	<div id="emailForm" class="hidden">
		<input type="hidden" id="emailReportID"/>
		
		<p>
			Hello,<br/>
			<br/>
			In regards to your message: <span id="emailText"></span><br/>
			<br/>
			<textarea id="emailMessage"></textarea><br>
			<br/>
			Regards,<br/>
			{{Auth::user()->name}}<br/>
			{{$constituency}} Council
		</p> <br/>
		
		<button id="emailBtn" onclick="sendEmail()">
			<h3>Send Email</h3>
		</button>
	</div>

@stop

