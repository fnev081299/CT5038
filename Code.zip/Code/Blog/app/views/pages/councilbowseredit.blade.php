
<?php 
// #################################################################
//  Author: Luke Gassmann
//  Purpose: To allow Council members to edit and create new bowsers
// #################################################################
?>

@extends('layouts.default')

@section('title')
    Bowser Edit
@stop



<?php

    $userID = $information["userID"];

    $urgencyTypes = $information["urgencyTypes"];
    $bowserTypes = $information['bowserStatusTypes'];
    
    $constituencyID = $information["constituency"]["ConstituencyID"];

    // Get all new bowser data
    $bowserID = $information["bowser_data"]["BowserID"];
    $bowserAddress = $information["bowser_data"]["bowserAddress"];
    $bowserStatus = $information["bowser_data"]["bowserStatus"];
    $bowserAdditionalNotes = $information["bowser_data"]["AdditionalNotes"];
    $bowserConstituencyID = $information["bowser_data"]["ConstituencyID"];
    $bowserLat = $information["bowser_data"]["latitude"];
    $bowserLong = $information["bowser_data"]["longitude"];
    $bowserCreationDate = $information["bowser_data"]["creation_date"];
    $bowserSize = $information["bowser_data"]["size"];

    $bowserStatusText = $bowserTypes[$bowserStatus]['name'];

?>


@section('pageCSS')
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="Resources/Pages/EditBowser/bowsereditstyles.css"/>
    <?php 

include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/EditBowser/bowsereditmobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')

        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script src="Resources/Pages/EditBowser/bowsereditanimate.js"></script>
        
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
        
        $clickMove = <?php if($bowserID == "N/A"){ echo "true"; } else{ echo "false"; } ?>;
    
        $(".clickCheckBox").change(function(event){
            var checked = $(".clickCheckBox:checked").length;
            checked = checked != 0;

            console.log("Click " + checked)

            if (checked){
                $clickMove = true
            }
            else{
                $clickMove = false
            }
        })
        
        // Select the Map Div and focus on this location
        var mainMap = new google.maps.Map(document.getElementById('map'), {
            center: {lat: {{$bowserLat}}, lng: {{$bowserLong}}},
            zoom: 13,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }); 
        
        // Create an appropriate Icon
        var icon = {
            
            url: '<?php echo $bowserTypes[$bowserStatus]['image']; ?>',
            scaledSize: new google.maps.Size(50, 50), // scaled size
        };
        
        
        // Create a position
        var myLatlng = new google.maps.LatLng({{$bowserLat}},{{$bowserLong}});
        
        // Create a marker
        var marker = new google.maps.Marker({
            position: myLatlng,
            title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
            map: mainMap,
            icon: icon
        });
    
        // Add circle overlay and bind to marker
        var circle = new google.maps.Circle({
          map: mainMap,
          radius: {{$bowserSize}}/10,    // 10k Liter = 1km
          fillColor: '#AA0000',
            strokeColor: '#6600AA',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#6600AA',
            fillOpacity: 0.35,
        });
        circle.bindTo('center', marker, 'position');
        
        
        // Set event listener on the google maps div
        google.maps.event.addListener(mainMap, 'click', function(e){
            if ($clickMove){
                // Remove the previous marker
                marker.setMap(null);

                // Create a new marker with the new position
                marker = new google.maps.Marker({
                    position: e.latLng,
                    map: mainMap,
                    icon: icon,
                    title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>"
                });
                mainMap.setCenter(e.latLng);

                // Add the circle
                circle.bindTo('center', marker, 'position');

                // Create a reverse geocoder object
                var geocoder = new google.maps.Geocoder;

                lat = e.latLng.lat();
                lng = e.latLng.lng();

                var latlng2 = {lat: lat, lng: lng};

                // Get the Street name of the longitude and latitude
                geocoder.geocode({'location': latlng2}, function(results, status) {
                if (status === 'OK') {
                    if (results[0]) {

                        // Update the street data with the new information
                        destination = results[0].formatted_address;
                        console.log(results);
                        $(".bowserAddressEdit").html(destination.split(",").join(",<br>"));

                        $(".bowserLatSub").html(lat);
                        $(".bowserLongSub").html(lng);

                        $(".mapInformationSubAddress").html(destination.split(",").join(",<br>"))

                    } else {
                      window.alert('No results found');
                    }
                  } else {
                    window.alert('Geocoder failed due to: ' + status);
                  }
                });

            }
        })
        
        // Update the circle with new bowser sizes
        $(".bowserSizeInput").hover(function(){}, function(){
            $size = $(".bowserSizeInput input").val();
            circle.setOptions({radius: $size/10})
        })
        
        // Update drop down menu place holders
        $(".optionDropDownWorker").click(function(){
            $("#maintenanceWorkerChosenID").val($(this).attr("workerID"));
            $(".workerButtonStatus").html($(this).html() + '<span class="caret"></span>');
        })
        
        $(".optionDropDownUrgency").click(function(){
            $(".urgencyButtonStatus").attr("urgencyType", $(this).attr("urgencyValue"));
            $(".urgencyButtonStatus").html($(this).html() + '<span class="caret"></span>');
        })
        
        
        
        
        
        $(".optionDropDownStatus").click(function(){
            
            $thisStatus = $(this).attr('statusValue');
            
            $bowserTypeList = { 
                
                <?php foreach($bowserTypes as $bowserType){?>
                "<?php echo $bowserType['id']; ?>": ["<?php echo $bowserType['name']; ?>", "<?php echo $bowserType['image']; ?>", "<?php echo $bowserType['id']; ?>"],
                <?php } ?>
            
            }
            
            $(".bowserButtonStatus").html($bowserTypeList[$thisStatus][0] + '<span class="caret"></span>');

            icon = {
                url: $bowserTypeList[$thisStatus][1],
                scaledSize: new google.maps.Size(50, 50), // scaled size
            };
                
            $("#bowserStatusInformation").val($thisStatus);
            marker.setOptions({'icon': icon})
        })
        
        
        $(".optionDropDownJob").click(function(){
            $thisJobStatus = $(this).attr("statusValue");
            
            $bowserTypeList = { 
                
                <?php foreach($bowserTypes as $bowserType){?>
                "<?php echo $bowserType['id']; ?>": ["<?php echo $bowserType['name']; ?>", "<?php echo $bowserType['description']; ?>"],
                <?php } ?>
            
            }
            
            
            $name = $bowserTypeList[$thisJobStatus][0];
            $description = $bowserTypeList[$thisJobStatus][1];
            
            
            $("#jobTypeDescription").text($description);
            $("#jobTypeDescriptionRow").show();
            $(".jobButtonStatus").attr("jobType", $thisJobStatus);
            $(".jobButtonStatus").html($name + '<span class="caret"></span>');

        })
        
        
        
        var formData = {'constituency_id': {{$constituencyID}}};

        console.log(formData);
        
        $additional_markers = [];
        $additional_circles = [];

        $.ajax({
            type        : 'POST',
            url         : 'get_constituency_bowsers',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {
            if(data.success) {
                $returnedData = data['value'];
                $returnedData.forEach(function(item, index){
                    
                    // Bowser Id is N/A for new bowsers... This is to trick the if statement
                    N = -9
                    A = 1
                    
                    if (item['BowserID'] != {{$bowserID}}){
                        $b_id = item['BowserID']
                        $b_address = item['bowserAddress']
                        $b_lat = item['latitude']
                        $b_lon = item['longitude']
                        $b_size = item['size']

                        // Create a position
                        var newLatlng = new google.maps.LatLng($b_lat, $b_lon);

                        var icon = {
                            url: "Resources/Images/waterMapCompass.png",
                            scaledSize: new google.maps.Size(40, 40)
                        };

                        var marker = new google.maps.Marker({
                            position: newLatlng,
                            title: "Bowser ID: " + $b_id + " - " + $b_address,
                            map: mainMap,
                            icon: icon,
                            id: $b_id
                        });
                        
                        google.maps.event.addListener(marker, 'click', function() {
                            window.location.href = '/bowseredit?BowserID='+this.id;
                        })

                        var circle = new google.maps.Circle({
                          map: mainMap,
                          radius: $b_size/10,    // 10k Liter = 1km
                            strokeColor: '#7a96c4',
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                            fillColor: '#7ac4c4',
                            fillOpacity: 0.35,
                        });
                        circle.bindTo('center', marker, 'position');

                        $additional_markers.push(marker);
                        $additional_circles.push(circle);
                    }
                })
            }
        });
    
        
        
        $(".showAllCheckBox").change(function(event){
            var checked = $(".showAllCheckBox:checked").length;
            checked = checked != 0;

            console.log(checked)

            if (checked){
                $additional_markers.forEach(function(item, index){
                    item.setOptions({'opacity': 1.0});
                })
                $additional_circles.forEach(function(item, index){
                    item.setOptions({'strokeOpacity': 0.8, 'fillOpacity': 0.35});
                })
            }
            else{
                $additional_markers.forEach(function(item, index){
                    item.setOptions({'opacity': 0.0});
                })
                $additional_circles.forEach(function(item, index){
                    item.setOptions({'strokeOpacity': 0.0, 'fillOpacity': 0.0});
                })
            }
        })
        
        main(<?php if($bowserID != 'N/A'){echo $bowserID;} else{echo -1;}?>, {{$constituencyID}}, {{$userID}})
    })
</script>

@stop



    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')  

    @include('includes.alertSuccess')

    <!-- Page Created by Luke Gassmann --> 
    <table class="mainTableContent">
        <tr class="topRowDetails">
            <td class="bowserEditTitle">
                <p ><?php if($bowserStatus == -1){ echo "Create a New "; }else{echo "Edit";} ?> Bowser</p>
                <div class="searchForBowser">
                    <form name="bowserIDForm" action="/bowseredit" method="get">
                        <input name="BowserID" class="searchBox" type="text" placeholder="Search for existing Bowsers (ID)" autocomplete="off" autofocus="off">
                        <input style="display: none;" type="submit">
                    </form>
                </div>
				
				<?php if($bowserStatus != -1){?><a class="saveDataInformationButton createNewBowserButton" href="/bowseredit?BowserID=new">Create a New Bowser</a><?php } ?>
            </td>
        </tr>
        <tr class="topRowDetails">
            <td>
                <div class="centered">
                    <table class="editBowserMapTable">
                        <tr>
                            <td width=100%>
                                
                                <!-- Map Section --> 
                                
                                <div class="mapContainerCell">
                                <div id="map" class="map">
                                </div>
                                </div>
                            </td>
                            <td width=1%>
                                
                                <!-- Bowser Basic Data --> 
                                
                                <div class="mapInformationDiv">
                                    <table class="mapTableInformation" border="0">
	                                    <p style="display: none;" class="bowserLatSub"></p>
	                                    <p style="display: none;" class="bowserLongSub"></p>
                                        <tr>
                                            <td>
                                                <p class="mapInformationHeading">ID: <span class="mapInformationSub"><?php echo $bowserID; ?></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p class="mapInformationHeading">Address: </p>
                                                <p class="mapInformationSub mapInformationSubAddress"><?php echo $bowserAddress; ?></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p class="mapInformationHeading">Status: <span class="mapInformationSub"><?php echo $bowserStatusText; ?></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                                                                <!-- Default checked -->
                                                <div class="custom-control custom-checkbox">
                                                  <input type="checkbox" class="custom-control-input showAllCheckBox" id="defaultChecked2" checked>
                                                  <label class="custom-control-label" for="defaultChecked2">Show all</label>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                                                                <!-- Default checked -->
                                                <div class="custom-control custom-checkbox">
                                                  <input type="checkbox" class="custom-control-input clickCheckBox" id="defaultChecked3" <?php if($bowserID == "N/A"){ echo "checked"; } ?> >
                                                  <label class="custom-control-label" for="defaultChecked3">Click Move</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div class="centered">
                    <table class="bowserLowerInformationTable" border="0">
                        <tr>
                            <td width=50% style="vertical-align: top;">
                                <div class="editInformationDiv">
                                    
                                    
                                    <!-- Form for submission --> 
                                    
                                    <form id="bowserDataInformation" name="bowserDataInformation">
                                        <input style="display:none" name="id" type="text" value="<?php echo $bowserID; ?>">
                                        <input style="display:none" name="size" type="text">
                                    </form>
                                    
                                    <!-- Editable Bowser Data --> 
                                    <table class="bowserInformationEditTable">
                                        <tr>
                                            <td colspan="2">
                                                <p class="informationTitle">Bowser Information</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Bowser ID: </p>
                                            </td>
                                            <td>
                                                <p class="editSub bowserIDEdit"><?php echo $bowserID;?></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Size (Litres): </p>
                                            </td>
                                            <td>
                                                
                                                <div>
                                                    <div class="row bowserSizeInput">
                                                            <div class="input-group number-spinner">
                                                                <span class="input-group-btn">
                                                                    <button class="btn btn-default" data-dir="dwn"><span class="glyphicon glyphicon-minus"></span></button>
                                                                </span>
                                                                <input type="text" class="form-control text-center" min="0" value="<?php echo $bowserSize;?>">
                                                                <span class="input-group-btn">
                                                                    <button class="btn btn-default" data-dir="up"><span class="glyphicon glyphicon-plus"></span></button>
                                                                </span>
                                                            </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Address: </p>
                                            </td>
                                            <td>
                                                <p contentEditable="true" class="editSub bowserAddressEdit"><?php echo $bowserAddress;?></p>
                                            </td>
                                        </tr>
										
                                        <!--

										Removed because of Sprint Meeting 2
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Latitude: </p>
                                            </td>
                                            <td>
                                                <p class="editSub bowserLatSub"><?php echo $bowserLat; ?></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Longitude: </p>
                                            </td>
                                            <td>
                                                <p class="editSub bowserLongSub"><?php echo $bowserLong; ?></p>
                                            </td>
                                        </tr>
-->

<!--
										Removed to streamline interaction
										
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading jobTypeRowSegments">Status: </p>
                                            </td>
                                            <td style="text-align: center">
                                                <!- https://getbootstrap.com/docs/4.4/components/dropdowns/ ->
                                                <div class="dropdown jobTypeRowSegments">
                                                    <input id="bowserStatusInformation" style="display: none" type="number" value="<?php echo $bowserStatus; ?>" >
                                                    <button class="btn btn-primary dropdown-toggle bowserButtonStatus" type="button" data-toggle="dropdown">
                                                        
                                                        {{$bowserStatusText}}
                                                        
                                                    <span class="caret"></span></button>
                                                    <ul class="dropdown-menu jobSegments">
                                                        
                                                        <?php foreach($bowserTypes as $bowserType){ if ($bowserType['name'] != "Creating"){?>
                                                            <li><a statusValue="<?php echo $bowserType['id']; ?>" class="optionDropDownStatus" href="#"><?php echo $bowserType['name']; ?></a></li>
                                                        <?php }} ?>
                                                    </ul>
                                                  </div>
                                            </td>
                                        </tr>
-->
                                        <tr>
                                            <td colspan="2">
                                                <div id="bowserInformationSave" class="saveDataInformationButton">Save Data</div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                            <td width=50% style="vertical-align: top;">
                                <div class="editInformationDiv">
                                    
                                    <!-- Form for Submission --> 
                                    <form id="maintenanceDataInformation" name="maintenanceDataInformation">
                                        <input style="display:none" name="id" type="text" value="<?php echo $bowserID; ?>">
                                        <input style="display:none" name="contactNumber" type="text">
                                    </form>
                                    
                                    
                                    <!-- Maintenance Worker Submission --> 
                                    <table class="bowserInformationEditTable">
                                        <tr>
                                            <td colspan="2">
                                                <p class="informationTitle">Maintenance Job Form</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Worker ID: </p>
                                            </td>
                                            <td>
                                                <input type="num" val=-1 id="maintenanceWorkerChosenID" style="display: none">
                                                <div class="dropdown">
                                                    <button class="btn btn-primary dropdown-toggle workerButtonStatus" type="button" data-toggle="dropdown">Choose Worker 
                                                    <span class="caret"></span></button>
                                                    <ul class="dropdown-menu jobSegments">
                                                        <?php foreach($information["maintenance"] as $key => $worker){ ?>
                                                            <li><a class="optionDropDownWorker" href="#" workerID="<?php echo $key; ?>" ><?php echo $worker; ?></a> </li>
                                                        <?php } ?>
                                                    </ul>
                                                  </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading">Report Ref: </p>
                                            </td>
                                            <td>
	<div class="row" id="reportRefNumber">
			<div class="input-group number-spinner">
				<span class="input-group-btn">
					<button class="btn btn-default" data-dir="dwn"><span class="glyphicon glyphicon-minus"></span></button>
				</span>
				<input type="text" class="form-control text-center" value="<?php if(isset($_GET['reportID'])){echo $_GET('reportID') . '"';} else {echo 'N/A';}?>">
				<span class="input-group-btn">
					<button class="btn btn-default" data-dir="up"><span class="glyphicon glyphicon-plus"></span></button>
				</span>
			</div>
	</div>
                                                <!--
                                                <input type="num" class="editSub maintenanceContactEdit" >
-->
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading jobTypeRowSegments">Priority: </p>
                                            </td>
                                            <td style="text-align: center">
                                                <!-- https://getbootstrap.com/docs/4.4/components/dropdowns/ -->
                                                <div class="dropdown urgencyTypeRowSegments">
                                                    <button urgencyType="<?php echo -1; ?>" class="btn btn-primary dropdown-toggle urgencyButtonStatus" type="button" data-toggle="dropdown">Urgency
                                                    <span class="caret"></span></button>
                                                    <ul class="dropdown-menu jobSegments">
                                                        
                                                        <?php foreach($urgencyTypes as $urgencyType){?>
                                                            <li><a urgencyValue="<?php echo $urgencyType['id']; ?>" class="optionDropDownUrgency" href="#"><?php echo $urgencyType['name']; ?></a></li>
                                                        <?php } ?>
                                                        
                                                    </ul>
                                                  </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=35%>
                                                <p class="editHeading jobTypeRowSegments">Job Type: </p>
                                            </td>
                                            <td style="text-align: center">
                                                <!-- https://getbootstrap.com/docs/4.4/components/dropdowns/ -->
                                                <div class="dropdown jobTypeRowSegments">
                                                    <button jobType="<?php echo -1; ?>" class="btn btn-primary dropdown-toggle jobButtonStatus" type="button" data-toggle="dropdown">Job Type 
                                                    <span class="caret"></span></button>
                                                    <ul class="dropdown-menu jobSegments">
                                                        
                                                        <?php foreach($bowserTypes as $bowserType){ if ($bowserType['name'] != "Creating" && $bowserType['name'] != "Active"){?>
                                                            <li><a statusValue="<?php echo $bowserType['id']; ?>" class="optionDropDownJob" href="#"><?php echo $bowserType['name']; ?></a></li>
                                                        <?php }} ?>
                                                        
                                                    </ul>
                                                  </div>
                                            </td>
                                        </tr>
                                        <tr id="jobTypeDescriptionRow" style="display:none">
                                            <td colspan="2">
                                                <p class="basicDescriptionType">Basic Description</p>
                                                <p class="descriptionType" id="jobTypeDescription"></p>
                                            </td>
                                        </tr>
                                        <tr class="notesRow">
                                            <td width=35% colspan="2">
                                                <p class="editHeading">Job Notes: </p>
                                            </td>
                                        </tr>
                                        <tr class="notesRow">
                                            <td colspan="2">
                                                <p contentEditable="true" class="editSub maintenanceNotesEdit">Aa</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">
                                                <div id="maintenanceSubmission" class="saveDataInformationButton">Save Data</div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div class="centered">
                    <div  class="additionalNotesDiv">
                        <div class="notesTitle">
                            Additional Notes
                        </div>
                        <div contentEditable="true" class="notesSectionText">
                            <?php echo $bowserAdditionalNotes; ?>
                        </div>
                        <div id="additionalNotesButton" class="saveDataInformationButton additionalNotesButton">Save Data</div>
                    </div>
                </div>
            </td>
        </tr>
    </table>
@stop


















