<!-- Author: Nicolas Euliarte Veliez -->
<!-- Purpose: Home landing page for the public -->


<?php

	// Check if this page is opened on a mobile
    require "Resources/PHP/mobileCheck.php";

?>

<!-- scrtipts used -->
@section('pageJS')
        <script src="Resources/Pages/Home/homeAnimate.js" type="text/javascript"></script>
		<script type="text/javascript"> $(document).ready(function(){window.onload = mainMap()});</script>
        <script type="text/javascript"> window.onload = main();</script>
@stop


<!-- slide shows -->
@section('upperbackground')
    @include('includes.slideShow')
    @yield('slideShow')
@stop
      
<!-- main upper section -->
@section('uppercontents')
<div class="slideShowTitleSector" border="0">
    <titleSector>
        <p>Help Us Deliver Water to You</p>
    </titleSector>
	
    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
	<div class="elfsight-app-bdfc3bce-258d-444d-805a-d9fd2eb41eaa"></div>

    <button class="button logInButton">
        <p>Council Log In</p>
    </button>
</div>
@stop

<!-- main contens of the page -->
@section('maincontents')
<form name="homeForm">
            <div class="bg">
                <div class="content">
<!-- 	                Bowsers near me link -->
                    <div class="col">
                        <div class="at">
                            <img src="Resources/Images/waterMap.png">
                        </div>
                        <div class="it" >
                            <h2> <a href="https://ct5038group2-ct5038.uogs.co.uk/bowserNearMe" class = "x">Bowsers Near Me ? </a> </h2>
                        </div>
						<div class="ba">
							@include('includes.map')
						</div>
						
                    </div>
<!--                     Refill times information -->
                    <div class="col">
                        <div class="at">
                            <img src="Resources/Images/waterMap.gif">
                        </div>
						
                        <div class="it">
                            <h2>Refill Times</h2>
                        </div>
                        <div class="ba">
                            <p class="details"> Monday to Friday
                                <br> 06:00 - 07:00 
                                <br> Weekend
                                <br> 08:00 - 09:00
                                
                            </p>
                        </div>
                    </div>
<!-- 					FAQ page link -->
                    <div class="col">
                        <div class="at">
                            <img src="Resources/Images/Logo/Medium/logo_basic_white_circle.png">
                        </div>
                        <div class="it">
                            <h2>Questions?</h2>
                        </div>
                        <div class="ba">
                            <p class="details">Contact us here:
                                <br>
									<a href="https://ct5038group2-ct5038.uogs.co.uk/contact" class="x">Contact</a>
                                <br>Frequently asked Questions:
                                <br>
									<a href="https://ct5038group2-ct5038.uogs.co.uk/faq" class="x">Questions</a>
                                <br>
                            </p>
                        </div>
                    </div>

                </div>
					
            </div>
</form>

@stop

<!-- page styling and php for mobile -->
@section('pageCSS')
		<link rel="stylesheet" type="text/css" href="/Resources/Pages/Home/homeStyleAdditional.css">
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Home/homeStyles.css"/>
        
<?php
	// If this page is in mobile load the mobile CSS as well
    if(isMobile()){
        ?>
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Home/homeStylesMobile.css"/>
<?php } ?>
@stop

@include('layouts.homeLayout')