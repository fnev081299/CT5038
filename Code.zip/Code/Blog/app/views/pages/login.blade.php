<!--
######################################################################
 Author : Luke
 Description : Login Page
######################################################################
-->

@extends('layouts.default')

@section('title')
    Log In
@stop
@section('preLoad')
    <!-- provide the csrf token -->
    <meta name="_token" content="{{csrf_token()}}" />
@stop
@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/Login/styles.css"/>
        
    <?php 

include "Resources/PHP/mobileCheck.php";
if(!isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/Login/stylesDesktopLogin.css"/>
    <?php }

else{?>
    <style>
        .mobileOverflowOuter{
            overflow-y: hidden !important;
        }
        .button{
            font-size: 0.8em;
        }
        
        .loginMain{
            font-size: 2em;
        }
        
        #elipsis, .burgerMenu{
            display: none;
        }
        
    </style>
<?php }?>
@stop
@section('pageJS')
        <script src="Resources/Pages/Login/animate.js"></script>
        <script src="Resources/Pages/Login/login.js"></script>
        <script type="text/javascript"> window.onload = main();</script>

@stop

@section('header')
@stop
    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')       
                    <!-- Login Sector -->
                    <table class="loginMain" border="0">
                        <tr>
                            <form id="loginForm" name="loginForm" onsubmit="login(); return false" >
                                
                                <td class=loginFormCol>
                                    
                                    <!-- Login Details Section -->
                                    <table class=loginFormTable border="0">
                                        
                                        <!-- Title and Text -->
                                        <tr height=2em>
                                            <td>
                                                <img class="loginFormLogo" src="../Resources/Images/Logo/Medium/logo_basic.png">
                                            </td>
                                        </tr>
                                        <tr height=2em>
                                            <td>
                                                <p class="titleForm"><span class="waterTitle">WATER</span> <span class="capitolTitle">CAPITOL</span></p>
                                            </td>
                                        </tr>
                                        <tr height=2em>
                                            <td >
                                                <p class="signInText">Sign In to access your account</p>
                                            </td>
                                        </tr>
                                        <tr height=10%>
                                        </tr>
                                        
                                        <!-- Email Input -->
                                        <tr height=18%>
                                            <td>
                                                <div class=inputDiv>
                                                    <input name="email" type="email" placeholder="Email" type="text" autocomplete="off">
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Password Input -->
                                        <tr height=18%>
                                            <td>
                                                <div class=inputDiv>
                                                    <input type="password" name="password" placeholder="Password" type="text" autocomplete="off">
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <!-- Submit Button -->
                                        <tr>
                                            <td>
                                                <button type="submit" class="button">
                                                    <p>Log In</p>
                                                </button>
                                            </td>
                                        </tr>
                                    </table>
                                
                                </td>
                            </form>
                            
                            <!-- Decorative Section -->
                            <td class=loginSideImage>
                                <div class="sideImageCover">
                                    <table class="loginTextTable" border="0">
                                        <tr>
                                            <td>
                                                <p class="header">Helping Those in need.</p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                            <p class="paragraph">Focusing on water shortages, our system combines both effective water shortage managerial tools, with modern front-end technology to allow both the public and council confidence in responding to unpredicted circumstances.</p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </table>
    @stop

