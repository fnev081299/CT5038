<!-- Written by: Joseph Lloyd -->
<!-- Purpose: Dynamically adapt the website for the contacts page -->

<!-- Check homeLayout.blade.php for the section titles and meanings -->

<!-- Get JS -->
@section('pageJS')
	<script>
		function copyDetails(text) { //function to copy contents to clipboard
		    var field = document.getElementById("copyField"); //create an input (must be copied from)
		    console.log(text);
		    field.value = text; //fill in the dummy value with text entered
		    console.log(field);
		    field.select(); //select it
			field.setSelectionRange(0, 99999);
		    document.execCommand("copy"); //copy it
			alert("COPIED");
		}
	</script>
@stop

<!-- Get CSS (check of mobile - test by reloading page when in a mobile mode) - update mobile style -->
@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="/Resources/Pages/Contact/contactStyles.css"/>

		<?php 

			include "Resources/PHP/mobileCheck.php";
			if(isMobile()){?>

				<link rel="stylesheet" type="text/css" href="/Resources/Pages/Contact/contactMobileStyles.css"/>
	   <?php  } ?>
@stop
	
	
<!-- Change Title section (tab name) -->
@section('title')
    Contact Information
@stop

<!-- Create breadcrumb -->
@section('breadcrumb')
    <a href="/">Home</a> / <a href="/contact">Contact</a>
@stop


<!-- Update page title -->                    
@section('pagetitle')
	<h1 id="titleHomeText" class="title">Contact Information </h1>
@stop

<!-- Update Subtitle for extra information -->
@section('subtitlesection')
	<p id="subtitleSection" class="subtitleClass">Contact us directly with the information below </p>
@Stop

<!-- Show the content for this page -->
@section('maincontents')
<form class="f">
	<input id="copyField"/>
	<div class = "mainContentsClass">
		<br>
		<p id="content">For more information or any questions you may have, contact us at one of the following (Click papers to copy): </p>
		<div class="Container">
			<p class="infoText" id="email">Email: WaterCapitol@Bowsers.co.uk</p> <input type="button" class="buttons" onclick=copyDetails("WaterCapitol@Bowsers.co.uk")>
		</div>
		<div class="Container">
			<p class="infoText" id="phone">Phone: 0321 452 5632</p> <input type="button" class="buttons" onclick=copyDetails("03214525632")>
		</div>
		<br>
	</div>
</form>
@stop

<!-- include the homeLayout template -->
@include('layouts.homeLayout')















