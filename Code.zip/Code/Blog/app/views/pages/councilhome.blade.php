
<?php 
// #################################################################
//  Author: Luke Gassmann
//  Purpose: This is the council home page
// #################################################################
?>


@extends('layouts.default')

@section('title')
    Council Home
@stop


@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/CouncilHomePage/councilstyles.css"/>
        
    <?php 

include "Resources/PHP/mobileCheck.php";
if(isMobile()){?>

        <link rel="stylesheet" type="text/css" href="Resources/Pages/CouncilHomePage/councilmobilestyles.css"/>
    <?php }?>
@stop
@section('pageJS')
        <script src="Resources/Pages/CouncilHomePage/councilanimate.js"></script>
        
        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
        
        
        // Select the Map Div and focus on this location
        var mainMap = new google.maps.Map(document.getElementById('mapDiv'), {
            center: {lat: {{$information["constituencyData"]["latitude"]}}, lng: {{$information["constituencyData"]["longitude"]}}},
            zoom: 13,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }); 

        var statsMap = new google.maps.Map(document.getElementById('statsMap'), {
            center: {lat: {{$information["constituencyData"]["latitude"]}}, lng: {{$information["constituencyData"]["longitude"]}}},
            zoom: 13,
            disableDefaultUI: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
    
        // For the stats Map
        function statsData(){
            
            var searchInput = $("#searchBarBowser").val();
            var bowserData = {{$information["bowserData"]}};
            
            // Search each bowser
            for ($index in bowserData){            
                $bowserFocus = bowserData[$index];
                
                // If this is the searched bowser
                console.log("Data: " + $bowserFocus["BowserID"] + " - " + searchInput);
                if ($bowserFocus["BowserID"] == searchInput){
                    
                    console.log("Resetting map");
                    
                    // Check status
                    $(".statsSize").text($bowserFocus["size"] + "L of Water");
                    $(".statsLocation").text($bowserFocus["bowserAddress"] + ", <?php echo $information["constituencyData"]["constituencyName"]; ?>, " + $bowserFocus["bowserAddress"]);
                    
                    var statusData = "Active";
                    if ($bowserFocus["bowserStatus"] == 1 || $bowserFocus["bowserStatus"] == 4 || $bowserFocus["bowserStatus"] == 5){
                        statusData = "Under Repair";
                    }
                    else if ($bowserFocus["bowserStatus"] == 2){
                        statusData = "Refilling";
                    }
                    else if ($bowserFocus["bowserStatus"] == 3){
                        statusData = "Deploying";
                    }
                    else if ($bowserFocus["bowserStatus"] == 6){
                        statusData = "Under Observation";
                    }
                    
                    // Create Map
                    $(".statsStatus").text(statusData);
                    $(".bowserStatsID").text("Boswer ID: " + $bowserFocus["BowserID"]);
                    
                    statsMap = new google.maps.Map(document.getElementById('statsMap'), {
                        center: {lat: $bowserFocus["latitude"], lng: $bowserFocus["longitude"]},
                        zoom: 12,
                        disableDefaultUI: true,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    });
                    
                    
                    // Set icons
                    var iconAddress = "Resources/Images/waterMap.png";
                    if ($bowserFocus["bowserStatus"]==1 || $bowserFocus["bowserStatus"] == 4 || $bowserFocus["bowserStatus"] == 5){
                        iconAddress = "Resources/Images/tools.png";
                    }
                    else if ($bowserFocus["bowserStatus"]==2){
                        iconAddress = "Resources/Images/waterMap.gif";
                    }
                    else if ($bowserFocus["bowserStatus"]==3){
                        iconAddress = "Resources/Images/waterMapDeploy.png";
                    }
                    
                    
                    // Create icon object
                    var icon = {
                        url: iconAddress,
                        scaledSize: new google.maps.Size(50, 50), // scaled size
                    };
                    
                    // Position and create Marker
                    var myLatlng = new google.maps.LatLng($bowserFocus["latitude"], $bowserFocus["longitude"]);

                    var marker = new google.maps.Marker({
                        position: myLatlng,
                        title: "Bowser ID: " + $bowserFocus["BowserID"] + " - " + $bowserFocus["bowserAddress"],
                        map: statsMap,
                        icon: icon
                    });

                    // Add circle overlay and bind to marker
                    var circle = new google.maps.Circle({
                      map: statsMap,
                      radius: $bowserFocus["size"]/10,    // 10k Liter = 1km
                      fillColor: '#AA0000',
                        strokeColor: '#6600AA',
                        strokeOpacity: 0.8,
                        strokeWeight: 2,
                        fillColor: '#6600AA',
                        fillOpacity: 0.35,
                    });
                    circle.bindTo('center', marker, 'position');
                    
                    $(".statsButton").click(function(){
                        window.location.href = "/bowseredit?BowserID=" + searchInput;
                    })
                    
                    
                }
            }
        }
        
        $(".searchButtonStats").click(statsData)
        
        // Create Individual bowsers for main map
        @foreach($information["bowserData"] as $bowser)
        <?php
        $bowserInfo = $bowser["attributes"];
        $bowserlon = $bowserInfo["longitude"];
        $bowserlat = $bowserInfo["latitude"];
        $bowserID = $bowserInfo["BowserID"];
        $bowserStatus = $bowserInfo["bowserStatus"];
        $bowserAddress = $bowserInfo["bowserAddress"];
        $bowserRadius = $bowserInfo["size"];
        ?>
    
        // Set position and Icons
        var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});

        var icon = {
            
            url: @if ($bowserStatus == 1 || $bowserStatus == 4 || $bowserStatus == 5)
                    "Resources/Images/tools.png"
                @elseif ($bowserStatus == 2)
                    "Resources/Images/waterMap.gif"
                @elseif ($bowserStatus == 3)
                    "Resources/Images/waterMapDeploy.png"
                @else        
                    "Resources/Images/waterMap.png"
                @endif,
            scaledSize: new google.maps.Size(50, 50), // scaled size
        };
        
        // Create marker and radius 
        var marker{{$bowserID}} = new google.maps.Marker({
            position: myLatlng,
            title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
            map: mainMap,
            icon: icon
        });
    
        // Add circle overlay and bind to marker
        var circle = new google.maps.Circle({
          map: mainMap,
          radius: {{$bowserInfo["size"]}}/10,    // 10k Liter = 1km
          fillColor: '#AA0000',
            strokeColor: '#6600AA',
            strokeOpacity: 0.8,
            strokeWeight: 2,
            fillColor: '#6600AA',
            fillOpacity: 0.35,
        });
        circle.bindTo('center', marker{{$bowserID}}, 'position');
        
        // on click event 
        google.maps.event.addListener(marker{{$bowserID}}, 'click', function() {
            $(".mainContentsSwipeTable").css("left", "-100%");
            $(".mapBackground").css("opacity", "0");
            $(".mapBackground").css("pointer-events", "none");
            $(".statsDiv").css("opacity", "1");
            $(".statsDiv").css("pointer-events", "auto")
            $(".bowserStatsButton p").addClass("focusedTabButton")
            $(".mapCoverageButton p").removeClass("focusedTabButton");
            
            $("#searchBarBowser").val({{$bowserID}});
            statsData();
        });
    
        @endforeach
        
        
        // Main section
        window.onload = main();
    })
</script>

@stop

@section('bbih1number')
    {{sizeof($information["bowserLiveData"])}}
@stop

@section('bbih2number')
    {{sizeof($information["bowserData"])}}
@stop

@section('bbih3number')
    {{sizeof($information["bowserData"]) - sizeof($information["bowserLiveData"])}}
@stop

    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')       
    <table class="mainTableContent">
        <tr class="topRowDetails">
            <td>
                @include('includes.introTable')
            </td>
            <td>
                @include('includes.bowserBasicsDiv')
            </td>
        </tr>
        <tr>
            <td class="changableContentsTD" colspan="2">
                <div class="changableContents">
                    <table class="mainSwapContentTable" border=0>
                        <tr height=1%>
                            <td width=50%>
                                <div class="tabButton mapCoverageButton">
                                    <p class="tabButtonText">
                                        Map Coverage
                                    </p>
                                </div>
                            </td>
                            <td>
                                <div class="tabButton bowserStatsButton">
                                    <p class="tabButtonText">
                                        Bowser Statistics
                                    </p>
                                </div>
                            </td>
                        </tr>
                        <tr height=100%>
                            <td colspan="2">
                                <table class="mainContentsSwipeTable" border=0>
                                    <tr>
                                        <td width=50%>
                                            <div class="backgroundCover mapBackground">
                                                <div id="mapDiv" class="map">

                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="statsDiv">
                                                <table class="statsTableHolder" border="0">
                                                    <tr height=1%>
                                                        <td colspan="5">
                                                            <table class="searchBarTable">
                                                                <tr>
                                                                    <td class="searchBarCell">
                                                                        <div class="searchBar">
                                                                            <input type="text" id="searchBarBowser" class="searchBarInput" placeholder="Search Bowsers ID">
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <img src="/Resources/Images/next.png" class="searchButtonStats">
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr height=100%>
                                                        <td width=50%>
                                                            <div id="statsMap" class="map">

                                                            </div>
                                                        </td>
                                                        <?php if(isMobile()){?>
                                                    </tr>
                                                    <tr>
                                                        <?php } ?>
                                                        <td>
                                                            <table class="bowserInfoStats" border=0>
                                                                <tr>
                                                                    <td height="1%" width=1% colspan="2">
                                                                        <p class="bowserStatsID"></p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="1%" width=1% colspan="2">
                                                                        <p class="bowserStatsSingularInfo">The following information in accordance to previous updates concerns the Bowser's Maximum Water Content, it's Global Position and it's current Status </p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width=1%>
                                                                        <img class="statsIcon" src="/Resources/Images/drop.png">
                                                                    </td>
                                                                    <td width=100%>
                                                                        <p class="statsSize statsInfoSingular"></p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width=1%>
                                                                        <img class="statsIcon" src="/Resources/Images/world.png">
                                                                    </td>
                                                                    <td width=100%>
                                                                        <p class="statsLocation statsInfoSingular"></p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width=1%>
                                                                        <img class="statsIcon" src="/Resources/Images/hammer.png">
                                                                    </td>
                                                                    <td width=100%>
                                                                        <p class="statsStatus statsInfoSingular"></p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <div class="statsButton">
                                                                            <p>More Info</p>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <p class="heading">
                    Live Bowsers
                </p>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <table class="liveBowsersTable">
                    <tr>
                        <td width=20%>
                            <p class="headerBarLiveBowsers">Date</p>
                        </td>
                        <td width=20%>
                            <p class="headerBarLiveBowsers">ID</p>
                        </td>
                        <td width=20%>
                            <p class="headerBarLiveBowsers">Status</p>
                        </td>
                        <td width=20%>
                            <p class="headerBarLiveBowsers">Location</p>
                        </td>
                        <td width=20%>
                            <p class="headerBarLiveBowsers">Size</p>
                        </td>
                    </tr>
                    @foreach($information["bowserData"] as $bowser)
                    <?php
                    
                    // Create Bowser Table
                    $bowserInfo = $bowser["attributes"];
                    $bowserID = $bowserInfo["BowserID"];
                    $bowserStatus = $bowserInfo["bowserStatus"];
                    $bowserSize = $bowserInfo["size"];
                    $bowserDate = $bowserInfo["creation_date"];
                    $bowserDate = date("d-m-Y", strtotime($bowserDate));
                    $bowserAddress = $bowserInfo["bowserAddress"];
                    ?>
                    <tr class="liveBowserRow">
                        <td width=20%>
                            <p>{{$bowserDate}}</p>
                        </td>
                        <td width=10%>
                            <p>{{$bowserID}}</p>
                        </td>
                        <td width=10%>
                            <p>@if($bowserStatus == 0)         
                                    Active
                                @elseif ($bowserStatus == 1)
                                    Repair
                                @elseif ($bowserStatus == 2)
                                    Refill
                                @elseif ($bowserStatus == 3)
                                    Deploying
                                @elseif ($bowserStatus == 4)
                                    Minimal Repair
                                @elseif ($bowserStatus == 5)
                                    Aesthetic Refill
                                @elseif ($bowserStatus == 6)
                                    Observation
                                @endif</p>
                        </td>
                        <td width=30%>
                            <p>{{$bowserAddress}}</p>
                        </td>
                        <td width=20%>
                            <p>
                                {{$bowserSize}}
                            </p>
                        </td>
                    </tr>
                    @endforeach
                </table>
            </td>
        </tr>
    </table>
@stop

