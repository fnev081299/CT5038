<?php
/*
###########################################################
Author: Luke Gassmann
Purpose: Allows the user to send messages to other council
         members
###########################################################
*/
?>

<!-- Use layout based on user type -->
<?php
	$layout = 'layouts.default';
	
	if( Auth::user()->user_type == 'M' ) {
		
		$layout = 'layouts.maintenanceLayout';
		
	} else if( Auth::user()->user_type == 'A' ) {
		
		$layout = 'layouts.adminLayout';
		
	}
?>

@extends($layout)



@section('breadcrumb')
    / <a>Discussions</a>
@stop

@section('introtabletitle')
    Discussions
@stop



@section('title')
    Messaging
@stop



<?php
/*
###########################################################
Purpose: Page's CSS
###########################################################
*/
?>

@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/MessageDesktop/messageDesktopStyles.css"/>
        <?php 
        
        include "Resources/PHP/mobileCheck.php";
        if(isMobile()){?>
             

            <link rel="stylesheet" type="text/css" href="Resources/Pages/MessageDesktop/messageMobileStyles.css"/>
        <?php }?>

@stop
@section('pageJS')

        <script
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU&callback=initMap">
        </script>
        <script src="Resources/Pages/MessageDesktop/messageDesktopAnimate.js"></script>
        

<script type="text/javascript"> 
    
    /*
    Function to run on start
    */
    $(document).ready(function() {
        
        // Get friends fast variables
        
        friend_selected = <?php 
            if (isset($_GET["friend"])){
                echo $_GET["friend"];
            }
            else{
                echo -1;
            }
            ?>
        
            // Run start
        main({{$information["user_id"]}}, friend_selected, <?php echo isMobile(); ?>);
        
        
    })
</script>

@stop


    
    <!--
################################################################################
    Type: Body
    Contents: Creates the main body
################################################################################
    -->

<!-- Page content -->
@section('content')


    <table class="mainTableContent">
        <tr class="topRowDetails">
            <td width=50%>
                
                
                <!--
################################################################################
    Contents: Search Users
################################################################################
    -->
                
                <div class="searchUsersDiv">
                    <table class="outerHoldingTable">
                        <tr height=10%>
                            <td class="titleCell">
                                <div class="searchUsersBar">
                                    <input type="text" placeholder="Search Users">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top" class="accountSearchTD">
                                <img class='searchUsers' src='Resources/Images/searchUsers.png'>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
            <td>
                
                
                <!--
################################################################################
    Contents: Display Messages
################################################################################
    -->
                
                <div class="messagesDiv">
                    <table class="outerHoldingTable">
                        <tr height=10%>
                            <td class="titleCell">
                                <p>Your Messages</p>
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align:top">
                                <div class="messageHolderOverflow">
                                    <table class="messagesTable">
                                        
                                    </table>
                                </div>
                            </td>
                        </tr>
                        
                        <!--
################################################################################
    Contents: Messaging Bar
################################################################################
    -->
                        <tr height=10%>
                            <td class="messagingTD">
                                <form id="photoForm">
                                    <input name="photoPicked" id="photoPicked" type="file" accept="image/x-png,image/gif,image/jpeg" >
                                </form>
                                <img id="takePhoto" class="messageIcon" src="/Resources/Images/camera.png">
                                <img id="takeMap" class="messageIcon" src="/Resources/Images/map_place.png">
                                <div class="messagingBox">
                                    <input type="text" placeholder="Aa">
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                
            </td>
        </tr>
        <!--
################################################################################
    Contents: Back options
################################################################################
    -->
        <?php if (isMobile()){?>
        <tr>
            <td>
            </td>
            <td>
                
                <img class="backImage" src="/Resources/Images/next.png">
                <p class="refresh">Refresh for New Messages</p>
                
            </td>
        </tr>
        <?php } ?>
    </table>
    

<!--
################################################################################
    Contents: Google map sending
################################################################################
    -->

    <div class="googleMapsDisplay">
        <div class="map_create" id="map_create">
        </div>
        <p id="useMyLocation">Use my Location</p>
        <p id="cancelMap">Cancel</p>
        <p id="sendMap">Send</p>
    </div>
    
@stop





























