
<!--
######################################################################
 Author : Josh
 Description : Password reset page
######################################################################
-->

<!-- Page layout used -->
@extends('layouts.default')


<!-- Additional css & js -->
@section('preLoad')
    <!-- provide the csrf token -->
    <meta name="_token" content="{{csrf_token()}}" />
    
	<link href="Resources/CSS/bootstrap-4.3.1.css" rel="stylesheet">
@stop
@section('pageCSS')
	<link href="Resources/Pages/Reset/styles.css" rel="stylesheet">
@stop
@section('postLoad')
	<script src="https://cdnjs.cloudflare.com/ajax/libs/zxcvbn/4.2.0/zxcvbn.js"></script>
@stop
@section('pageJS')
	<script src="Resources/Pages/Reset/reset.js" type="text/javascript"></script>
@stop


<!-- Page items -->
@section('title')
    Change Password
@stop

@section('header')
	<header class="headerText">
		Update Password
	</header>
@stop


<!-- Page content -->
@section('content')

	<form class="form-group" name="passwordForm" onsubmit="updatePassword(); return false" >
		
		<!-- Hidden input to store token -->
		<input name="Token" type="text" style="display:none" value="{{$token}}">
		
		<p class="password-req">
			Passwords must:<br/>
			- be 10 characters or longer<br/>
			- have a strength of "Good" or "Strong"<br/>
			- not be in the known list of hacked passwords<br/>
			<br/>
			For strong passwords it is recommended to use several unrelated words<br/>
			See <a href="https://xkcd.com/936/">XKCD comic 936</a>
		</p> <br/>
		
		<input class="form-control rounded-0" name="Password" type="password" placeholder="password" onkeyup="checkComplexity()" required>
		<meter max="4" id="password-strength-meter"></meter>
		<p id="password-strength-text">Strength: Worst</p>
	
		<input class="form-control rounded-0" name="ConfirmPassword" type="password" placeholder="confirm password" required> <br/>
		
		<p id="textout-password">
			Password is not 10 characters or longer
			<br>
			<br>
			Passwords are checked against the haveibeenpwned.com database
			<br>
		</p>
		
		<button type="submit" class="button">
            <p>Update</p>
        </button>
	</form>
@stop

