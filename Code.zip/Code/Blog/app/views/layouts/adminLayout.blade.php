
<!--
######################################################################
 Author : Luke
 Description : Default Layout for Admin Pages
######################################################################
-->


<?php require "Resources/PHP/mobileCheck.php"; ?>

@extends('layouts.default')

@section('extendedLayoutCSS')
    <link rel="stylesheet" type="text/css" href="Resources/Pages/AdminLayout/adminlayoutstyles.css"/>
@stop




<!--
######################################################################
	Breadcrumb
######################################################################
-->
@section('breadcrumbRoot')
    <a href="/adminHome">Home</a>
@stop

@section('introtableusertype')
    Administrator
@stop




<!--
######################################################################
	Links
######################################################################
-->
@section('link1')
	<a href="/adminHome" class="homeLink link">Statistics</a>
@stop
@section('link2')
<a href="/adminEmployees" class="reportsLink link">Employees</a>
@stop
@section('link3')
	<a href="/adminConstituencies" class="inquiriesLink link">Constituencies</a>
@stop
@section('link4')
	<a href="/messageDesktop" class="liveBowsersLink link">Discussions</a>
@stop
@section('link5')
	<a href="/logout" class="otherBowsersLink link">Log Out</a>
@stop

@section('linkList')
    <td width=20%>
        <a class="link">@yield('link1')</a>
    </td>
    <td width=20%>
        <a class="link">@yield('link2')</a>
    </td>
    <td width=20%>
        <a class="link">@yield('link3')</a>
    </td>
    <td width=20%>
        <a class="link">@yield('link4')</a>
    </td>
    <td width=20%>
        <a class="link">@yield('link5')</a>
    </td>
@stop






<!--
######################################################################
	Links and Images
######################################################################
-->
@section('burgermenu1text')
    <a class="burgerlink" href="/adminHome">Statistics</a>
@stop

@section('burgermenu1image')
    /Resources/Images/BurgerMenuCouncil/user.png
@stop


@section('burgermenu2text')
    <a class="burgerlink" href="/adminEmployees">Employees</a>
@stop

@section('burgermenu2image')
    /Resources/Images/BurgerMenuCouncil/statistics.png
@stop


@section('burgermenu3text')
    <a class="burgerlink" href="/adminConstituencies">Constituencies</a>
@stop

@section('burgermenu3image')
    /Resources/Images/BurgerMenuCouncil/research.png
@stop


@section('burgermenu4text')
    <a class="burgerlink" href="/messageDesktop">Discussions</a>
@stop

@section('burgermenu4image')
    /Resources/Images/BurgerMenuCouncil/wifi.png
@stop


@section('burgermenu5text')
    <a class="burgerlink" href="/logout">Log Out</a>
@stop

@section('burgermenu5image')
    /Resources/Images/BurgerMenuCouncil/logout.png
@stop


