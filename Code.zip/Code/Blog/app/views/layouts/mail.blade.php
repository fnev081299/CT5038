<!DOCTYPE html>

<!--
######################################################################
 Author : Josh
 Description : Default layout for emails
######################################################################
-->

<html>
    
    <head>
	    
        @yield('preLoad')
        
		<style>
			
			/* fonts */
			@font-face {
			    font-family: 'mainRegular';
			    src: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Fonts/Quicksand-Regular.ttf'); 
			    font-weight: normal;
			    font-style: normal;
			}
			
			@font-face {
			    font-family: 'mainLight';
			    src: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Fonts/Quicksand-Light.ttf'); 
			    font-weight: normal;
			    font-style: normal;
			}
			
			@font-face {
			    font-family: 'mainBold';
			    src: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Fonts/Quicksand-Bold.ttf'); 
			    font-weight: normal;
			    font-style: normal;
			}
			
			@font-face {
			    font-family: 'bebas';
			    src: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Fonts/Bebas.ttf'); 
			    font-weight: normal;
			    font-style: normal;
			}
			
			@font-face {
			    font-family: 'caviar';
			    src: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Fonts/Caviar.ttf'); 
			    font-weight: normal;
			    font-style: normal;
			}
			
			
			/* page layout css */
			*{
			    margin: 0;
				border-collapse: collapse;
			}
			
			html {
				overflow: hidden;
				background-image: linear-gradient(45deg, #7F7FD5, #86A8E7, #91EAE4);
				height: 100%;
				
				font-size: 20px;
			}
			
			
			/* Tabori, V. (2017). background-size: cover not working on iOS. [online] Stack Overflow. Available at: https://stackoverflow.com/a/43058483 [Accessed 13 Dec. 2019]. */
			body {
				overflow-y: scroll;
				content:"";
				margin: 0;
				z-index:-1; /* needed to keep in the background */
			    background: url('https://ct5038group2-ct5038.uogs.co.uk/Resources/Images/background.jpg') no-repeat center center fixed;
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
				background-attachment: scroll;
			}
			
			main{
				min-height: 100%;
				
				max-width: 90%;
			    width: 1120px;
			    
			    margin: 15vh auto 15vh auto;
			    
			    box-shadow: 16px 16px rgba(255, 255, 255, 0.3);
			    background-color: white;
			}
			
			article{
				text-align: center;
				
				padding: 10%;
				
				min-height: 320px;
				
				
			    font-family: mainRegular;
			    font-weight: 500;
			}
		
			button{
			    margin: 16px;
			    margin-top: 32px;
			    padding: 8px;
			    
			    border: solid 3.2px #5F86A0;
			    border-top-width: 0.8px;
			    border-bottom-width: 0.8px;
			    background-color: white;
			    color: #5F86A0;
			    transition: 0.4s;
			    
			    font-family: caviar;
			    font-size: 1.25em;
			    line-height: 24px;
				font-weight: 700;
			}
			
			button:hover{
			    background-color: #5F86A0;
			    color: white;
			}
			
			a{
				color: inherit;
				text-decoration: none;
				margin: 8px;
			}
			
			.backup {
				display: none;
			}
		</style>
		
        @yield('pageCSS')
        
    </head>
    
    
    <body>
        <main>
	        
			<!-- Header with css inlinded to improve on less capable email clients -->
		    <header style="margin: 0;border-collapse: collapse;background-image: linear-gradient(90deg, rgb(245, 245, 245), rgb(250, 250, 250));padding-top: 16px;padding-bottom: 16px;padding-left: 20px;padding-right: 20px;">
                <table class="titleHeaderImgSector" style="margin: 16px auto;border-collapse: collapse;">
                    <tr style="margin: 0;border-collapse: collapse;">
                        <td style="margin: 0;border-collapse: collapse;">
                            <img class="titleHeaderImg" src="https://ct5038group2-ct5038.uogs.co.uk/Resources/Images/Logo/Medium/logo_basic_white_blue_circle.png" style="margin: 0;border-collapse: collapse;width: 64px;">
                        </td>
                        <td style="margin: 0;border-collapse: collapse;">
                            <p class="titleHeaderParagraph" style="margin: 0;border-collapse: collapse;margin-left: 12px;font-family: caviar;font-size: 36px;font-weight: 700;letter-spacing: 3.6px;">
                                <span class="waterTitle" style="margin: 0;border-collapse: collapse;color: cadetblue;">WATER</span>
                                <span class="capitolTitle" style="margin: 0;border-collapse: collapse;color: #5F86A0;">CAPITOL</span>
                            </p>
                        </td>
                    </tr>
                </table>
			</header>

            <article>
		        
		        @yield('content')
	
            </article>
            
        </main>
    </body>
</html>
