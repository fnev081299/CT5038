
<!--
######################################################################
 Author : Luke
 Description : Default Layout for public pages
######################################################################
-->

<!-- Tab Title -->
@section('title')
    Water Capitol
@stop


@section('user')
    Log In
@stop

@section('userImage')
    /Resources/Images/lock.png
@stop

<!-- Tabs on nav bar -->



@section('link1')
<a href="/">Home</a>
@stop

@section('link5')
<a href="/contact">Contact Us</a>
@stop

@section('link4')
    <a href="/faq">FAQs</a>
@stop

@section('link2')
    <a href="/bowserNearMe">Find Bowsers</a>
@stop


@section('link3')
    <a href="/request">Request</a>
@stop

@section('link6')
    <a href="/login">Log In</a>
	<style>
		.headerLinkRow td:last-child{
			display:none;
		}
	</style>
@stop

<!-- Link to the page (breadcrumb) -->
@section('breadcrumb')
/ <a href="/">Home</a> /
@stop

<!-- title of the page (goes in top section) -->
@section('pagetitle')
    Insert Title
@stop

<!-- add extra information below -->
@section('subtitlesection')
    Insert text for brief description only if wanted or necessary
@stop

@section('elipsies')

    <img id="elipsis" class="elipsis" src="/Resources/Images/elipsis.png">

@stop

@section('upperbackground')
    <div class="backdropImage">
		
    </div>
@stop

<!-- Defines the elements shown in upper background section -->
@section('uppercontents')
    <div class="upperBackgroundSection">
        <p class="breadcrumb">@yield('breadcrumb')</p>
        <p class="titleHomeText">@yield('pagetitle')</p>
        <p class="subTitleHomeText">@yield('subtitlesection')</p>
        @yield('additionaluppercontents')
    </div>
@stop

<!-- contents of the page -->
@section('maincontents')
        
        <div class="mainContents">
            <br>
            <br>
            <br>
            <br>
            <br>
            <p style="text-align: center">This is where you can insert information by overriding this section</p>
        </div>
@stop


<?php
    require "Resources/PHP/mobileCheck.php";
?>

<html>
    <head>
        
        <style>
	        html {
		        background-image: none !important;
		        background-color: rgb(230, 240, 255);
	        }
	        body {
		        background: none !important;
	        }
	        body:after {
		        background: none !important;
	        }
        </style>
        @yield('preload')
        @include('includes.preLoad')
        @yield('pageCSS')
        @yield('postLoad')
        @include('includes.postLoad')
        @yield('pageDefaultJS')
        
        <link rel="stylesheet" type="text/css" href="Resources/Pages/HomeLayout/homeLayoutStyles.css"/>
        
        <?php
            if(isMobile()){
        ?>
        <link rel="stylesheet" type="text/css" href="Resources/Pages/HomeLayout/homeLayoutMobileStyles.css"/>
        <?php } ?>
        
        <script src="Resources/Pages/HomeLayout/homeLayoutAnimate.js"></script>
        <script type="text/javascript"> window.onload = main();</script>
    </head>
    <body>
        
        
        <table class="mainTable" border="0">
			<!-- Page Header -->
            <tr height=10%>
                <td class="titleBar">
                    @yield('upperbackground')
                    
                    <table class="topSection">
                        <?php
                            if (isMobile()){
                        ?>
                        <tr class="dumbyRow">
                            <td>
                            </td>
                        </tr>
                        <?php } ?>
                        <tr>
                            <td class="headingRow">
                                
                                <?php
                                    if (isMobile()){
                                ?>
                                
                                    @yield('elipsies')
                                
                                    @include('includes.burgermenu')
                                
                                <?php } ?>
                                <div class="centered">
                                    @include('includes.header')
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <div class="centered">
                                @yield('uppercontents')
                                </div>
                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
			<!--  Page Content  -->
            <tr height=100%>
                <td class="mainContentsCell">
                    <div class="centered mainContentsHolder">
                        @yield('maincontents')
                    </div>
                </td>
            </tr>
			<!--  Page Footer -->
            <tr height=1% class="footerCell">
                <td class="footerCell">
                    <div class="footer">
                        @include('includes.footer')
						
						<a style="font-family: mainRegular;
								  font-weight: 700;
								  padding-right: 1em;
								  float: right;" href="/login">Log In</a>
						
                    </div>
                </td>
            </tr>
            
        </table>
        
        @yield('pageJS')
    </body>
</html>

















