
<!--
######################################################################
 Author : Luke & Josh
 Description : Default layout for council members
######################################################################
-->

<?php require "Resources/PHP/mobileCheck.php"; ?>

@section('elipsies')

    <img id="elipsis" class="elipsis" src="/Resources/Images/elipsis.png">

@stop


<!--
######################################################################
	Links and Images
######################################################################
-->
@section('burgermenu1text')
    <a class="burgerlink" href="/councilhome">Your Page</a>
@stop

@section('burgermenu1image')
    /Resources/Images/BurgerMenuCouncil/user.png
@stop


@section('burgermenu2text')
    <a class="burgerlink" href="/bowseredit">Bowser New/Edit</a>
@stop

@section('burgermenu2image')
    /Resources/Images/BurgerMenuCouncil/edit.png
@stop


@section('burgermenu3text')
    <a class="burgerlink" href="/taskList">Tasks</a>
@stop

@section('burgermenu3image')
    /Resources/Images/BurgerMenuCouncil/statistics.png
@stop


@section('burgermenu4text')
    <a class="burgerlink" href="/Inquiries">Inquiries</a>
@stop

@section('burgermenu4image')
    /Resources/Images/BurgerMenuCouncil/research.png
@stop


@section('burgermenu5text')
    <a class="burgerlink" href="/messageDesktop">Discussions</a>
@stop

@section('burgermenu5image')
    /Resources/Images/BurgerMenuCouncil/wifi.png
@stop


@section('burgermenu6text')
    <a class="burgerlink" href="/logout">Log Out</a>
@stop

@section('burgermenu6image')
    /Resources/Images/BurgerMenuCouncil/logout.png
@stop


<!-- Page content -->
@section('main')
	@yield('content')
@stop



<!DOCTYPE html>
<html>
    
    <head>
        @yield('preLoad')
        @include('includes.preLoad')
        @yield('pageCSS')
		@yield('extendedLayoutCSS')
    </head>
    
    
    <body>
		<!-- Page contents area -->
	    <div class="fill">
	        <main>
		        <?php if(isMobile()) { ?>
		        	
                	<div class="dumbyContainer"></div>
                	
                <?php } ?>
                	
					<!--  Page Header -->
		        	@include('includes.header')
		        	
	            <?php if(isMobile()) { ?>
	            	
                    @yield('elipsies')
					
                    @include('includes.burgermenu')
					
                <?php } ?>
                
	            <div class="mobileOverflowOuter">
		            <div class="mobileOverflowInner">
			            <article>
							
							<!-- Page contents -->
					        @yield('main')
					            
			            </article>
                    </div>
	            </div>
	        </main>
			
			<!-- Desktop Page footer -->
	        <footer class="mobileHide">
	            @include('includes.footer')
	        </footer>
	    </div>
        
        
        @yield('postLoad')
        @include('includes.postLoad')
        @yield('pageJS')
		
		<!-- Mobile Page footer -->
        <?php if(isMobile()) { ?>
            <link rel="stylesheet" type="text/css" href="Resources/CSS/stylesMobile.css"/>
            
            <script type="text/javascript"> 
	            
                $(document).ready(function() {
                    var burgerMenuOnScreen = false;
                    $(document).on('click', '#elipsis', function(){

                        if (!burgerMenuOnScreen){
                            $(".burgerMenu").css("left", "0");
                            burgerMenuOnScreen = true;
                        }
                        else{
                            $(".burgerMenu").css("left", "-80%");
                            burgerMenuOnScreen = false;
                        }
                    })
                })
                
            </script>
        <?php } ?>
        
    </body>
</html>
