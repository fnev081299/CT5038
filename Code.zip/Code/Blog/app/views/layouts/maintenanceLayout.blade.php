
<!--
######################################################################
 Author : Josh
 Description : Default Layout for maintenance users
######################################################################
-->

<!-- Page layout used -->
@extends('layouts.default')



<!--
######################################################################
	Breadcrumb
######################################################################
-->
@section('breadcrumbRoot')
    <a href="/taskList">Task List</a>
@stop
@section('introtableusertype')
    Maintenance Personnel
@stop



<!--
######################################################################
	Menu Links and Images
######################################################################
-->
@section('burgermenu1text')
    <a class="burgerlink" href="/taskList">Task List</a>
@stop
@section('burgermenu1image')
    /Resources/Images/BurgerMenuCouncil/statistics.png
@stop

@section('burgermenu2text')
    <a class="burgerlink" href="/messageDesktop">Discussions</a>
@stop
@section('burgermenu2image')
    /Resources/Images/BurgerMenuCouncil/wifi.png
@stop

@section('burgermenu2text')
    <a class="burgerlink" href="/logout">Log Out</a>
@stop
@section('burgermenu2image')
    /Resources/Images/BurgerMenuCouncil/logout.png
@stop




<!--
######################################################################
	Header Links
######################################################################
-->
@section('link1')
	<a href="/taskList" class="reportsLink link">Task List</a>
@stop
@section('link2')
	<a href="/messageDesktop" class="liveBowsersLink link">Discussions</a>
@stop
@section('link3')
	<a href="/logout" class="otherBowsersLink link">Log Out</a>
@stop

@section('linkList')
    <td width=33%>
        <a class="link">@yield('link1')</a>
    </td>
    <td width=33%>
        <a class="link">@yield('link2')</a>
    </td>
    <td width=33%>
        <a class="link">@yield('link3')</a>
    </td>
@stop



<!-- Page content -->
@section('main')
	@include('includes.introTable')
	
	@yield('content')
@stop

