
<!--
######################################################################
 Author : Josh
 Description : This page displays the email for council members to reply to the public
######################################################################
-->

<!-- Page layout used -->
@extends('layouts.mail')


<!-- Additional css & js -->
@section('preLoad')
	
@stop

@section('pageCSS')
	<style>
		p{
			text-align: left;
		}
	</style>
@stop


<!-- Page content -->
@section('content')
	
	<p>
		Hello,<br/>
		<br/>
		In regards to your message: {{$inquiry}}<br/>
		<br/>
		{{$reply}}<br/>
		<br/>
		Regards,<br/>
		{{$user}}<br/>
		{{$county}} Council
	</p>
	
@stop