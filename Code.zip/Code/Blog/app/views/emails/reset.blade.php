
<!--
######################################################################
 Author : Josh
 Description : This page displays the password reset email
######################################################################
-->

<!-- Page layout used -->
@extends('layouts.mail')


<!-- Additional css & js -->
@section('preLoad')
	
@stop

@section('pageCSS')
	<style>
		
	</style>
@stop


<!-- Page content -->
@section('content')
	
	<p>
		{{$name}}<br/>
		<br/>
		<br/>
		A password reset has been requested for your account<br/>
		<br/>
		<br/>
		You will not be able to access your account until you set a new password<br/>
		
		
		<button>
			<a href="https://ct5038group2-ct5038.uogs.co.uk/reset?token={{$token}}">Click here to change your password</a>
		</button>
		
		<br/>
		If the email does not display properly you can access your account here:<br/>
		<br/>
		https://ct5038group2-ct5038.uogs.co.uk/reset?token={{$token}}<br/>
	</p>
	
@stop