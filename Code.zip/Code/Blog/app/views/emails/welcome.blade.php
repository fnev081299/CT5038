
<!--
######################################################################
 Author : Josh
 Description : This page displays the new user welcolm email
######################################################################
-->

<!-- Page layout used -->
@extends('layouts.mail')


<!-- Additional css & js -->
@section('preLoad')
	
@stop

@section('pageCSS')
	<style>
		.welcome{
			font-weight: 900;
			font-size: 26px;
			padding-bottom: 16px;
		}
	</style>
@stop


<!-- Page content -->
@section('content')

	<div class="welcome">Welcome!</div>
	
	<p>
		{{$name}}<br/>
		<br/>
		<br/>
		A {{$county}} {{$type}} account has been created for you<br/>
		<br/>
		<br/>
		You will need to set your password before you can access your account<br/>
		
		<button>
			<a href="https://ct5038group2-ct5038.uogs.co.uk/reset?token={{$token}}">Click here to get started</a>
		</button>
		
		<br/>
		If the email does not display properly you can access your account here:<br/>
		<br/>
		https://ct5038group2-ct5038.uogs.co.uk/reset?token={{$token}}<br/>
	</p>
	
@stop