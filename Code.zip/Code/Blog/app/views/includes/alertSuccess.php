
<!--
######################################################################
 Author : 
 Description : 
######################################################################
-->


<style>
    .alertSuccessDiv{
        position: fixed;
        top: 2em;
        left: 0;
        right: 0;
        margin: 0 auto;
        width: 35em;
        min-height: 7em;
        background-color: #6C41B3;
        border-radius: 1em;
        z-index: 1000;
        display: none;
        opacity: 0;
        transition: 0.6s;
        padding-right: 0.5em;
    }
    
    .alertSuccessDivInner{
        position: relative;
        width: 34em;
        min-height: 6em;
        border: white solid 0.2em;
        border-radius: 1em;
        margin: 0.5em;
    }
    
    .alertSuccessTable{
        width: 90%;
        min-height: 5em;
        margin: 0.5em;
        padding-top: 1.5em;
        padding-bottom: 1.5em;
    }
    
    .alertSuccessTable p{
        font-size: 1.4em;
        color: white;
        font-family: mainRegular;
        font-weight: 700;
        line-height: 2em;
    }
    
    .alertSuccessDiv img{
        position: relative;
        top: -0.5em;
        width: 5em;
    }
</style>

<script>
    
    function alertDetailed(information, background_colour, image){
        $(".thumbsUpGif").attr('src', image);
        $(".alertSuccessTable p").text(information);
        $(".alertSuccessDiv").css("background-color", background_colour);
        
        $(".alertSuccessDiv").css("display", "block");
        
        $(".alertSuccessDiv").css("opacity", "1");
        
        setTimeout(function(){
            $(".alertSuccessDiv").css("opacity", "0");
            
            setTimeout(function(){
                $(".alertSuccessDiv").css("display", "none");
            }, 500)
        }, 2000)
    }
    
    function failAlertDetailed(information, background_colour){
        alertDetailed(information, background_colour, "/Resources/Images/thumbsdown.gif");
    }
    
    function failAlert(information){
        failAlertDetailed(information, "#9c2a61");
    }
    
    
    function successAlertDetailed(information, background_colour){
        alertDetailed(information, background_colour, "/Resources/Images/thumbsup.gif");
    }
    
    function successAlert(information){
        
        successAlertDetailed(information, "#6C41B3");
    }
</script>

<div class="alertSuccessDiv">
    <div class="alertSuccessDivInner">
        <table class="alertSuccessTable">
            <tr>
                <td width=1%>
                    <img src="/Resources/Images/thumbsup.gif" class="thumbsUpGif">
                </td>
                <td>
                    <p>Insert Text Here</p>
                </td>
            </tr>
        </table>
    </div>
</div>






















