
<?php 
// #################################################################
//  Author: Luke Gassmann
//  Purpose: This is the swappable table widget
// #################################################################
?>


<style>
    
    .changableContentsTD{
        text-align: center;
    }

    .changableContents{
        width: 90%;
        height: 40em;
        background-color: rgb(240, 240, 240);
        box-shadow: 0.25em 0.25em rgba(30, 0, 190, 0.2);
        margin: auto;
    }

    .mainSwapContentTable{
        position: relative;
        width: 100%;
        height: 100%;
        overflow: hidden;
    }
    

    /*
    ##################
    Tabs
    ##################
    */
    .tabButton{
        background-color: white;
        width: 85%;
        margin: auto;
        margin-top: 0.5em;
        margin-bottom: 0.5em;
        height: 3em;
        line-height: 3em;
        text-align: center;
        cursor: pointer;
    }

    .tabButtonText{
        font-family: caviar;
        font-size: 1.5em;
        cursor: pointer;
        font-weight: 500;
        color: grey;
        transition: 0.4s;
    }
    .focusedTabButton{
        color: black;
    }

    .tabButton:hover .tabButtonText{
        color: black;
        text-decoration: underline;
    }
    
    /*
    ##################
    Swap section
    ##################
    */

    .mainContentsSwipeTable{
        position: relative;
        width: 200%;
        height: 100%;
        left: 0;
        transition: 0.7s;
    }


</style>

<script>
    
    $(document).ready(function(){
        // Animate
        // $(".mapCoverageButton p").addClass("focusedTabButton")

        // Move in and out of screen when necessary
        $(".sideTableButton2").click(function(){
            $(".mainContentsSwipeTable").css("left", "-100%");
        })

        $(".sideTableButton1").click(function(){
            $(".mainContentsSwipeTable").css("left", "0");
        })
    })
    
    
</script>

@section('swapTableTitle1')
Area 1
@stop
@section('swapTableTitle2')
Area 2
@stop

@section('swapTableArea1')
<div>
    <p>Insert here for area 1 contents</p>
</div>
@stop

@section('swapTableArea2')
<div>
    <p>Insert here for area 2 contents</p>
</div>
@stop


<div class="changableContents">
    <table class="mainSwapContentTable" border=0>
        <tr height=1%>
            <td width=50%>
                <div class="tabButton sideTableButton1">
                    <p class="tabButtonText ">
                        @yield('swapTableTitle1')
                    </p>
                </div>
            </td>
            <td>
                <div class="tabButton sideTableButton2">
                    <p class="tabButtonText">
                        @yield('swapTableTitle2')
                    </p>
                </div>
            </td>
        </tr>
        <tr height=100%>
            <td class="mainContentsSwipeTableOuter" colspan="2">
                <table class="mainContentsSwipeTable" border=0>
                    <tr>
                        <td width=50%>
                            @yield('swapTableArea1')
                        </td>
                        <td>
                            @yield('swapTableArea2')
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>

