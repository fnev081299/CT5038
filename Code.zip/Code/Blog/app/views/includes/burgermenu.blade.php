
<!--
######################################################################
 Author : Luke Gassmann
 Description : This page hold all necessary contents to style and load
			   the menu bar for mobile
######################################################################
-->


<!--
######################################################################
	Style
######################################################################
-->
<style>
    .burgerMenuTable{
        width: 100%;
        font-size: 2.8em; 
        font-family: mainRegular;
    }
    
    .burgerMenuTable tr:not(:last-child){
        border-bottom: cadetblue solid 0.1em;
    }
    
    .burgerMenuTable p{
        padding: 1em;
    }
    
    .burgerMenu{
        position: absolute;
        top: 8.4em;
        left: -80%;
        width: 80%;
        background-color: #d8e6eb;
        transition: 0.4s;
        z-index: 100;
    }
    
    .burgerMenu tr td:first-child{
        text-align: center;
    }
    
    .burgerlink{
        color: #5F86A0;
        font-weight: 700;
		text-decoration: none;
    }
	
	.burgerlink:hover{
		text-decoration: underline;
    }
    
    
</style>



<!--
######################################################################
	Links and Images
######################################################################
-->
@section('burgermenu1text')
    <a class="burgerlink" href="/">Home</a>
@stop

@section('burgermenu1image')
    /Resources/Images/burgerMenu/home.png
@stop


@section('burgermenu2text')
    <a class="burgerlink" href="/bowserNearMe">Find Bowser</a>
@stop

@section('burgermenu2image')
    /Resources/Images/burgerMenu/find.png
@stop


@section('burgermenu3text')
    <a class="burgerlink" href="/request">Request</a>
@stop

@section('burgermenu3image')
    /Resources/Images/burgerMenu/candy.png
@stop


@section('burgermenu4text')
    <a class="burgerlink" href="/faq">FAQs</a>
@stop

@section('burgermenu4image')
    /Resources/Images/burgerMenu/question.png
@stop


@section('burgermenu5text')
    <a class="burgerlink" href="/contact">Contact Us</a>
@stop

@section('burgermenu5image')
    /Resources/Images/burgerMenu/call.png
@stop


@section('burgermenu6text')
    <a class="burgerlink" href="/logout">Logout</a>
@stop

@section('burgermenu6image')
    /Resources/Images/burgerMenuCouncil/logout.png
@stop



<!--
######################################################################
	HTML Design
######################################################################
-->
<div class="burgerMenu">
    <table class="burgerMenuTable" border="0">
        <tr >
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu1image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu1text')</p>
            </td>
        </tr>
        <tr>
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu2image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu2text')</p>
            </td>
        </tr>
        <tr>
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu3image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu3text')</p>
            </td>
        </tr>
        <tr>
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu4image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu4text')</p>
            </td>
        </tr>
        <tr>
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu5image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu5text')</p>
            </td>
        </tr>
        <tr>
            <td>
                <img class="burgerMenuIcons" src="@yield('burgermenu6image')">
            </td>
            <td>
                <p class="burgerMenuText">@yield('burgermenu6text')</p>
            </td>
        </tr>
    </table>
</div>

