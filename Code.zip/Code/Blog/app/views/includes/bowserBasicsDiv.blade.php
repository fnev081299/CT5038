
<!--
######################################################################
 Author : 
 Description : 
######################################################################
-->



<style>
    
.bowserBasicDiv{
    float: right;
    margin-right: 2em;
}


.bowserBasicDiv{
    background-color: rgb(240, 240, 240);
    width: 22em;
    margin-top: 2em;
}

.bowserBasicInfo{
    width: 100%;
    border-collapse: collapse;
        text-align: center;

}

.bowserBasicInfo tr td{
    padding-bottom: 0.75em;
    padding-top: 0.75em;
}

.bowserBasicInfo tr:not(:last-child) td{
    border-bottom: lightgrey solid 0.1em;
}

.bowserBasicInfoResult{
    width: 3em;
    height: 3em;
    margin-right: 0.5em;
    background-color: white;
    box-shadow: 0.25em 0.25em rgba(30, 0, 190, 0.2);
}

.bowserBasicInfoResultP{
    font-size: 1.2em;
    height: 100%;
    line-height: 2.5em;
    font-family: mainRegular;
}

.bowserBasicInfoHeading{
    text-align: left;
    font-family: mainRegular;
    padding-left: 1.5em;
    font-size: 1.1em;
}

</style>


@section('bbih1heading')
    Number of Live Bowsers
@stop

@section('bbih2heading')
    Total Areas Covered
@stop

@section('bbih3heading')
    Total Bowsers Under Repair
@stop


@section('bbih1number')
    1
@stop

@section('bbih2number')
    1
@stop

@section('bbih3number')
    1
@stop


<div class="bowserBasicDiv">
    <table class="bowserBasicInfo">
        <tr>
            <td>
                <p class="bowserBasicInfoHeading">@yield('bbih1heading')</p>
            </td>
            <td>
                <div class="bowserBasicInfoResult">
                    <p class="bowserBasicInfoResultP">@yield('bbih1number')</p>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <p class="bowserBasicInfoHeading">@yield('bbih2heading')</p>
            </td>
            <td>
                <div class="bowserBasicInfoResult">
                    <p class="bowserBasicInfoResultP">@yield('bbih2number')</p>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <p class="bowserBasicInfoHeading">@yield('bbih3heading')</p>
            </td>
            <td>
                <div class="bowserBasicInfoResult">
                    <p class="bowserBasicInfoResultP">@yield('bbih3number')</p>
                </div>
            </td>
        </tr>
    </table>
</div>





















