
<!--
######################################################################
 Author : Luke Gassmann
 Description : This include holds the default js to load after the page
######################################################################
-->

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="/Resources/JavaScript/slideShow.js"></script>