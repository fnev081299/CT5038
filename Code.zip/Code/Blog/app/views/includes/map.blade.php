
<!--
######################################################################
 Author : Luke & Josh
 Description : This include contains the shared google map implementation
######################################################################
-->

<?php if(!isset( $mapChar )) {$mapChar = '';} ?>

<!-- Google map -->
<div class="mapContainer">
	<div id="map{{$mapChar}}" class="map"></div>
	<p id="mapInfo{{$mapChar}}" class="mapInfo text-center"></p>
</div>


	<?php
		global $mapLoaded;
	?>
@if(!isset( $mapLoaded ))
	<?php
		$mapLoaded = 1;
	?>
	<link href="Resources/CSS/map.css" rel="stylesheet">
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD5Xc19v5rFKH1cXxyQoLxC_rEESDDMlJU"></script>	
@endif


<script type="text/javascript">

		// global values
		var map{{$mapChar}};
		var markers{{$mapChar}} = [];
		var circles{{$mapChar}} = [];
		var userLocation;
		
		// define map
		const createMap{{$mapChar}} = () => {
			
			var mapOptions = {
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				draggable: true,
				scrollwheel: true,
				navigationControl: true,
				mapTypeControl: true,
				scaleControl: true,
				zoom: 15,
				zoomControl: true,
				streetViewControl: true
			};
			
			map{{$mapChar}} = new google.maps.Map(document.getElementById('map{{$mapChar}}'), mapOptions);
			
			
			// add bowsers to map
			@if(isset(${"mapData" . $mapChar}["bowsers"]))
			    @foreach(${"mapData" . $mapChar}["bowsers"] as $bowser)
			        <?php
			        $bowserInfo = $bowser["attributes"];
			        $bowserlon = $bowserInfo["longitude"];
			        $bowserlat = $bowserInfo["latitude"];
			        $bowserID = $bowserInfo["BowserID"];
			        $bowserStatus = $bowserInfo["bowserStatus"];
			        $bowserAddress = $bowserInfo["bowserAddress"];
			        $bowserRadius = $bowserInfo["size"];
			        ?>
			        var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});
			
			        var icon = {
			            
			            url:  @if ($bowserStatus == 1 || $bowserStatus == 4 || $bowserStatus == 5)
			                    "Resources/Images/tools.png"
			                @elseif ($bowserStatus == 2)
			                    "Resources/Images/waterMap.gif"
			                @elseif ($bowserStatus == 3)
			                    "Resources/Images/waterMapDeploy.png"
			                @else        
			                    "Resources/Images/waterMap.png"
			                @endif,
			            scaledSize: new google.maps.Size(50, 50), // scaled size
			        };
			    
			        var marker{{$bowserID}} = new google.maps.Marker({
			            position: myLatlng,
			            title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
			            map: map{{$mapChar}},
			            icon: icon
			        });
					markers{{$mapChar}}['{{$bowserID}}'] = marker{{$bowserID}};
					
					
			        // Add circle overlay and bind to marker
			        var circle = new google.maps.Circle({
						map: map{{$mapChar}},
						radius: {{$bowserInfo["size"]}}/10,    // 10k Liter = 1km
						fillColor: '#AA0000',
			            strokeColor: '#6600AA',
			            strokeOpacity: 0.8,
			            strokeWeight: 2,
			            fillColor: '#6600AA',
			            fillOpacity: 0.35,
			        });
			        circle.bindTo('center', marker{{$bowserID}}, 'position');
					circles{{$mapChar}}['{{$bowserID}}'] = circle;
			
			        google.maps.event.addListener(marker{{$bowserID}}, 'click', function() {
			            $(".mainContentsSwipeTable").css("left", "-100%");
			            $(".mapBackground").css("opacity", "0");
			            $(".mapBackground").css("pointer-events", "none");
			            $(".statsDiv").css("opacity", "1");
			            $(".statsDiv").css("pointer-events", "auto")
			            $(".bowserStatsButton p").addClass("focusedTabButton")
			            $(".mapCoverageButton p").removeClass("focusedTabButton");
			            
			            $("#searchBarBowser").val({{$bowserID}});
			            statsData();
			        });
			    
			    @endforeach
			@endif
			
			return map{{$mapChar}};
		};
		
		
		// track positon on map
		@if(isset(${"mapData" . $mapChar}["track"]))
			@if(${"mapData" . $mapChar}["track"])
				
				// user location marker
				const createMarker{{$mapChar}} = ({ map, position }) => {
				  return new google.maps.Marker({ map, position });
				}
				
				// Track user location
				const trackLocation{{$mapChar}} = ({ onSuccess, onError = () => { } }) => {
				  if ('geolocation' in navigator === false) {
				    return onError(new Error('Geolocation is not supported by your browser.'));
				  }
				
				  return navigator.geolocation.watchPosition(onSuccess, onError, {
				    enableHighAccuracy: true,
				    timeout: 5000,
				    maximumAge: 0
				  });
				}
				
				// Define error messages
				const getPositionErrorMessage{{$mapChar}} = code => {
				  switch (code) {
				    case 1:
				      return 'Permission denied.';
				    case 2:
				      return 'Position unavailable.';
				    case 3:
				      return 'Timeout reached.';
				  }
				}
				
			@endif
		@endif
		
		
		// set initial map position
		function init{{$mapChar}}() {
			var first = true;
			
			@if(isset(${"mapData" . $mapChar}["track"]))
			
				@if(${"mapData" . $mapChar}["track"])
					const initialPosition = { lat: 0, lng: 0 };
				@elseif( isset(${"mapData" . $mapChar}["lat"]) && isset(${"mapData" . $mapChar}["lng"]) )
					const initialPosition = { lat: {{${"mapData" . $mapChar}["lat"]}}, lng: {{${"mapData" . $mapChar}["lng"]}} };
				@else
					const initialPosition = { lat: 0, lng: 0 };
				@endif
				
			@elseif( isset(${"mapData" . $mapChar}["lat"]) && isset(${"mapData" . $mapChar}["lng"]) )
				const initialPosition = { lat: {{${"mapData" . $mapChar}["lat"]}}, lng: {{${"mapData" . $mapChar}["lng"]}} };
			@else
				const initialPosition = { lat: 0, lng: 0 };
			@endif
			
			const map = createMap{{$mapChar}}();
			
			@if(isset(${"mapData" . $mapChar}["track"]))
				@if(${"mapData" . $mapChar}["track"])
				
					const userMarker{{$mapChar}} = createMarker{{$mapChar}}({ map, position: initialPosition });
					const $info = document.getElementById('mapInfo{{$mapChar}}');
					var first = true;
					
					let watchId = trackLocation{{$mapChar}}({
						onSuccess: ({ coords: { latitude: lat, longitude: lng } }) => {
							userLocation = { lat: lat, lng: lng };
							userMarker{{$mapChar}}.setPosition({ lat, lng });
							if(first) {
								map.panTo({ lat, lng });
								first = false;
							}
							$info.classList.remove('error');
						},
						onError: err => {
							console.log($info);
							$info.textContent = `Error: ${err.message || getPositionErrorMessage{{$mapChar}}(err.code)}`;
							$info.classList.add('error');
						}
					});
					
				@else
					map.panTo( initialPosition );
				@endif
			@else
				map.panTo( initialPosition );
			@endif
			
		}
		window.onload = init{{$mapChar}}();
</script>