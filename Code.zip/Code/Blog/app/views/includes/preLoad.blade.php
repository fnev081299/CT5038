
<!--
######################################################################
 Author : Luke
 Description : The include contains the dafault css to load before the page
######################################################################
-->

<title>@yield('title')</title>
<link rel="stylesheet" type="text/css" href="Resources/CSS/fonts.css"/>

<!-- Get the tab Image -->
<link rel="shortcut icon" href="Resources/Images/favicon.ico" />

<!-- SLIDESHOW CSS JS LINK -->
<link rel="stylesheet" type="text/css" href="Resources/CSS/slideShow.css"/>

<!-- ALL WIDGETS CSS JS LINK -->
<link rel="stylesheet" type="text/css" href="Resources/CSS/widgets.css"/>


<link rel="stylesheet" type="text/css" href="Resources/CSS/styles.css"/>