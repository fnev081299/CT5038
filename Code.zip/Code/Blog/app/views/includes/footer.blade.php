
<!--
######################################################################
 Author : Luke Gassmann
 Description : This include containg the default footer text
######################################################################
-->

<p>Powered by <b>Fr-Agile inc.</b></p>