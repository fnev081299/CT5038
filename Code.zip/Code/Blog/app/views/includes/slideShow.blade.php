
<!--
######################################################################
 Author : Luke Gassmann
 Description : Slideshow HTML
######################################################################
-->

<!-- BASIC SLIDESHOW -->

<div class="slideshow">
    <table class="slideshowTable" border="0">
        <tr>
            <td class="slide" id="slide1Slide">
            </td>
            <td class="slide" id="slide2Slide">
            </td>
            <td class="slide" id="slide3Slide">
            </td>
        </tr>
    </table>
</div>


<!--

FANCY SLIDESHOW

<div class="slideshow">
    
    <table class="slideshowTable" border="0">
        <tr>
            <td class="slide" id="slide1Slide">
                <div class="imgCover"></div>
            </td>
            <td class="slide" id="slide2Slide">
                <div class="imgCover"></div>
            </td>
            <td class="slide" id="slide3Slide">
                <div class="imgCover"></div>
            </td>
        </tr>
    </table>
</div>


-->

