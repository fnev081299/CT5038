<?php require "Resources/PHP/mobileCheck.php"; ?>

<!--
######################################################################
 Author : Luke Gassmann
 Description : This displays the default header bar for all pages
######################################################################
-->

<!--
######################################################################
	Links
######################################################################
-->
@section('link1')
	<a href="/councilhome" class="homeLink link">Your Page</a>
@stop
@section('link2')
	<a href="/bowseredit?BowserID=new" class="bowserEditLink link">Bowser New/Edit</a>
@stop
@section('link3')
	<a href="/taskList" class="reportsLink link">Tasks</a>
@stop
@section('link4')
	<a href="/Inquiries" class="inquiriesLink link">Inquiries</a>
@stop
@section('link5')
	<a href="/messageDesktop" class="liveBowsersLink link">Discussions</a>
@stop
@section('link6')
	<a href="/logout" class="otherBowsersLink link">Log Out</a>
@stop

@section('linkList')
    <td width=16.6667%>
        <a class="link">@yield('link1')</a>
    </td>
    <td width=16.6667%>
        <a class="link">@yield('link2')</a>
    </td>
    <td width=16.6667%>
        <a class="link">@yield('link3')</a>
    </td>
    <td width=16.6667%>
        <a class="link">@yield('link4')</a>
    </td>
    <td width=16.6667%>
        <a class="link">@yield('link5')</a>
    </td>
    <td width=16.6667%>
        <a class="link">@yield('link6')</a>
    </td>
@stop


<!--
######################################################################
	HTML Design
######################################################################
-->
@section('header')

	<header>
	    <table class="headerTable" border="0">
	        <tr>
	            <td colspan=6>
	                <table class="headerUpperTable" border="0">
	                    <tr>
							<!--
							######################################################################
							 Title Section
							######################################################################
							-->
	                        <td width=50%>
	                            <table class="titleHeaderImgSector">
	                                <tr>
	                                    <td>
	                                        <img class="titleHeaderImg" src="Resources/Images/Logo/Medium/logo_basic_white_blue_circle.png">
	                                    </td>
	                                    <td>
	                                        <p class="titleHeaderParagraph">
	                                            <span class="waterTitle">WATER</span>
	                                            <span class="capitolTitle">CAPITOL</span></p>
	                                    </td>
	                                </tr>
	                            </table>
	                        </td>
							<?php if (isMobile()){ ?>
						</tr>
						<tr class="mobileCouncilOnly">
							<?php } ?>
	                        <td>
	                            <table class="titleHeaderProfileSector">
	                                <tr>										<!--
										######################################################################
											User Name and Profile Picture
										######################################################################
										-->
										<?php if (!isMobile()){ ?>
	                                    <td>
	                                        <p class="titleHeaderParagraph titleProfileParagraph">
	                                            <span class="capitolTitle">
	                                            	<?php if (Auth::check()) { echo Auth::user()->name; } ?>
	                                            </span>
	                                        </p>
	                                    </td>
										<?php } ?>
	                                    <td>
	                                        <div class="titleHeaderProfileImg" style="background-image: url('Resources/Images/userDefault.png' )"></div>
	                                    </td>
	                                </tr>
	                            </table>
	                            
	                        </td>
							
	                    </tr>
	                </table>
	                
	            </td>
	        </tr>
			
			<!--
			######################################################################
				Links
			######################################################################
			-->
	        <tr class="headerLinkRow">
		        @yield('linkList')
	        </tr>
	    </table>
	</header>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script type="text/javascript"> 
    
    $(document).ready(function() {
		
		$(".bowserEditLink").click(function(){
			window.location.href = "/bowseredit?BowserID=new"; 
		})
	})

</script>
@show
