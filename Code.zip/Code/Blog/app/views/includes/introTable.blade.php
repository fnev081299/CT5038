
<!--
######################################################################
 Author : 
 Description : 
######################################################################
-->


<style>
    
    .introTable{
    	margin: 20px;
    }

    .introTable tr td{
        padding: 1em;
        text-align: left;
    }

    .titlePageName{
        font-family: caviar;
        color: grey;
        font-size: 3.5em;
    }

    a{
        text-decoration: none;
        color: rgb(0, 0, 90);
    }

    a:hover{
        text-decoration: underline;
    }

    .breadcrumbText{
        font-family: mainRegular;
    }

    .accessType{
        font-family: caviar;
        font-size: 1.2em;
        color: darkgrey;
        transition: 0.4s;
        cursor: default;
    }

    .accessType:hover{
        color: dimgrey;
    }
    
</style>


@section('breadcrumbRoot')
    <a href="councilhome">Home</a>
@stop

@section('breadcrumb')
    
@stop

@section('introtabletitle')
    My Page
@stop

@section('introtableusertype')
    Council Member
@stop


<table class="introTable">
    <tr>
        <td>
            <p class="titlePageName">@yield('introtabletitle')</p>
        </td>
    </tr>
    <tr>
        <td class="breadcrumbText">
            @yield('breadcrumbRoot') @yield('breadcrumb')
        </td>
    </tr>
    <tr>
        <td>
            <p class="accessType">Access: @yield('introtableusertype')</p>
        </td>
    </tr>
</table>





















