<?php
/**
Purpose: model access the tblBowserInformation table
Authors: Joe Lloyd, Josh Walker
*/


use Illuminate\Database\Eloquent\Model;		// import the model class

class TblBowserInformationModel extends Model {  //define class and inherit from the imported model class


	//set the table being accessed
	protected $table = 'tblBowserInformation';
	
	
	// disable timestamp requirements in table for updating/setting values
	public $timestamps = false;
	
	//get all bowsers under the given constituency ID
	public function getConstituencyBowser($constituency_id){
		$bowserData = TblBowserInformationModel::where('ConstituencyID', '=', $constituency_id)->get();
		return $bowserData;
	}
	
	//get the bowser record from the ID
    public function getLiveBowsersUnderBowserID($bowserID) {
		$bowserData = TblBowserInformationModel::where('BowserID', '=', $bowserID)->get();
		return $bowserData;
	}
	
	//get the bowsers considered live based on the ID and the bowser status represening live statuses
	public function getLiveBowsersUnderConstituencyID($constituencyID) {
		$bowserData = TblBowserInformationModel::where('ConstituencyID', '=', $constituencyID)
			->where('bowserStatus', '=', '0')
			->orwhere('bowserStatus', '=', '4')
			->orwhere('bowserStatus', '=', '5')
			->orwhere('bowserStatus', '=', '6')->get();
		return $bowserData;
	}
	
	//get the bowsers under a constituency ID
	public function getBowsersUnderConstituencyID($constituencyID) {
		$bowserData = TblBowserInformationModel::where('ConstituencyID', '=', $constituencyID)->get();
		return $bowserData;
	}
	
	// get all live bowsers
	public function getAllLiveBowsers() {
		$bowserData = TblBowserInformationModel::where('bowserStatus', '=', '0')->get();
		return $bowserData;
	}
	
	//get the addresses of all bowsers
	public function getAddresses() {
		$data = TblBowserInformationModel::select('bowserAddress')->get();

		return $data;
	}
	
	// get all the bowser entries
	public function getAllBowsers() {
		$bowserData = TblBowserInformationModel::all();
		return $bowserData;
	}
	
	// get bowsers considered offline by their bowser status
	public function getAllOfflineBowsers() {
		$bowserData = TblBowserInformationModel::where('bowserStatus', '=', '1')
			->orWhere('bowserStatus', '=', '2')
			->orWhere('bowserStatus', '=', '3')
			->get();
		return $bowserData;
	}
	
	
	//set new values for an individual bowser based on bowserID
	public function setBowserIndividual($bowserID, $values) {
		$success = TblBowserInformationModel::where('BowserID', '=', $bowserID)->update($values);

		return $success;
	}
	
	//add a new bowser to the table
	public function createNewBowser($values) {
		$success = DB::table('tblBowserInformation')->insertGetId($values);

		return $success;
	}
}


