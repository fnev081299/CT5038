<?php
/**
Purpose: access tblUserProfilePicture table through a model
Authors: Luke Gassmann
*/

use Illuminate\Database\Eloquent\Model;		// import the model class


class TblUserProfilePictureModel extends Model { //define class and inherit from the imported model class


	//define the table used
	protected $table = 'tblUserProfilePicture';
	
	
	
	// get profile picture file location based on the user ID
	public function getProfilePicture($userID) {
		$profilePicture = TblUserProfilePictureModel::where('id', '=', $userID)->get(array("picture_location"));
		
		if (!isset($profilePicture[0]["attributes"]["picture_location"])){ //return a default picture if there is not a location set
			$profilePicture = array(0=>array("attributes"=>array("picture_location"=>"../userDefault.png")));
		}
		
		return $profilePicture;
	}
	
	// get profile picture file location based on the user ID in a more explicit way
	public function getProfilePictureLive($userID) {
		$profilePicture = TblUserProfilePictureModel::where('id', '=', $userID)->get(array("picture_location"));
		
		if (!isset($profilePicture[0]["attributes"]["picture_location"])){
			$profilePicture = "../userDefault.png";
		}
		else{
			$profilePicture = $profilePicture[0]["attributes"]["picture_location"];
		}
		
		return $profilePicture;
	}
	
}


