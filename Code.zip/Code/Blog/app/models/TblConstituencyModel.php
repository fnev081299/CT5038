
<?php
//namespace Bowser;

use Illuminate\Database\Eloquent\Model;		// if database access only

//use Illuminate\Auth\UserTrait; 			// if user should be logged in and database access is needed
//use Illuminate\Auth\UserInterface; 		// if user should be logged in and database access is needed


	// note if you get errors like "Call to undefined method" there are two likely reasons
	// first laravel has cached the files before you created the new one - if so enter the commans from the following
	//		https://stackoverflow.com/questions/45474010/laravel-call-to-undefined-method-which-only-happens-in-production
	//
	// second you are using a name of an already existing class eg Password - if so try another name or change the namespace
//INSERT INTO `tblBowserInformaiton`(`bowserAddress`, `bowserPostcode`, `bowserStatus`, `AdditionalNotes`, `ConstituencyID`) VALUES ("Hatherley Ln", "GL51 6PN", "repair", "This is a test", 1)

class TblConstituencyModel extends Model {


	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'tblConstituency';		// if database table needs loading as properties of class for js access (js access because of controller's "return View::Make('/pages/password')->with('password', $pass);" )

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
//	protected $hidden = array('Password', 'ResetToken');		// if loaded values need to not be sent to js
	
	
	// class all() already exists
	
	
	
	
	// get name
	public function getConstituency($constituencyID) {
		$constituencyData = TblConstituencyModel::where('ConstituencyID', '=', $constituencyID)->get();
		return $constituencyData;
	}
	
	public function getAll(){
		return TblConstituencyModel::all();
	}
}


