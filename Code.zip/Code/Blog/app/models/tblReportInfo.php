<?php
/**
Purpose: model to access tblReportInfo table
Authors: Joe Lloyd
*/


use Illuminate\Database\Eloquent\Model;		// import the model class



class tblReportInfo extends Model { //define class and inherit from the imported model class


	protected $table = 'tblReportInfo';		//contains the name of the table

	
	public $timestamps = false; //prevents need to parse time stamp when adding to the table

	// get the entire record depending on the ID entered
	public function getReport($ID) { 
		$taskData =tblReportInfo::where('ReportID', '=', $ID)->get();
		return $taskData;
	}
	
	//used to add a new report to the table
		public function addReport($problem){
		$success = DB::table('tblPublicRequests')->insert($problem);

		return $success;
	}
	
	//get all reports from the database
	public function getAllReports() {
		$data = tblReportInfo::all();
		
		return $data;
	}
		
	
	
}
?>



