<?php
/**
Purpose: Controller for creating emails
Authors: Josh
*/

// Sending email behaviour is done like database access (in Model-View-Presenter) but requires controller
class EmailModel extends \BaseController {
	
	
	// send welcome email and return success
	public static function sendWelcome( $email, $name, $constituency, $accountType, $passwordToken ) {
		
		$data = [
			'name'		=> $name,
		    'county'	=> $constituency,
		    'type'		=> $accountType,
		    'token'		=> $passwordToken
		];
		
	    
	    Mail::send('emails.welcome', $data, function($send) use ($email)
		{
		    $send->subject('Water Capitol Welcome');
		    $send->from('WaterCapitol@gmail.com', 'Water Capitol');
		    $send->to($email);
		});
		
		
		$success = ( count(Mail::failures()) == 0 );
		
		return $success;
	}
	
	
	// send reset email and return success
	public static function sendReset( $email, $name, $passwordToken ) {
		
		$data = [
			'name'		=> $name,
		    'token'		=> $passwordToken
		];
		
	    
	    Mail::send('emails.reset', $data, function($send) use ($email)
		{
		    $send->subject('Water Capitol Password Reset');
		    $send->from('WaterCapitol@gmail.com', 'Water Capitol');
		    $send->to($email);
		});
		
		
		$success = ( count(Mail::failures()) == 0 );
		
		return $success;
	}
	
	
	// send reply email and return success
	public static function sendReply( $email, $userName, $constituency, $inquery, $reply ) {
		
		$data = [
			'user'		=> $userName,
		    'county'	=> $constituency,
		    'inquiry'	=> $inquery,
		    'reply'		=> $reply
		];
		
	    
	    Mail::send('emails.reply', $data, function($send) use ($email)
		{
		    $send->subject('Water Capitol Inquiry Reply');
		    $send->from('WaterCapitol@gmail.com', 'Water Capitol');
		    $send->to($email);
		});
		
		
		$success = ( count(Mail::failures()) == 0 );
		
		return $success;
	}
}


