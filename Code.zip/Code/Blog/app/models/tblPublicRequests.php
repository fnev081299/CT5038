<?php
/**
Purpose: model to access the tblPublicRequests table
Authors: Joe Lloyd and Nicolas Euliarte Veliez
*/

use Illuminate\Database\Eloquent\Model;		// import the model class


class tblPublicRequests extends Model {  //define class and inherit from the imported model class


	//define the table being used and remove the need for timestamps
	protected $table = 'tblPublicRequests';
	
	public $timestamps = false;
	
    
	//get all requests from the table
	public function getRequests() {
		$taskData = tblPublicRequests::all();
		return $taskData;
	}
	
	//get a specific record from the table based on the ID
	public function getFromID($ID) {
		$Data = DB::table("tblPublicRequests")->where('sendID', $ID)->first();
		return $Data;
	}
	
	//used to remove requests if their ID and type are the same to help prevent duplicate entries to the database
	public function removeByIDandType($ID, $type) {
		$success = tblPublicRequests::where('sendID', $ID)->where('type', $type)->delete();
		return $success;
	}

}


