<?php
/**
Purpose: model to access the tblTaskType table in the database
Authors: Joe Lloyd
*/

//use the predone model file
use Illuminate\Database\Eloquent\Model;		// import the model class


class TblTaskType extends Model {  //define class and inherit from the imported model class


	protected $table = 'tblTaskType';	//store the name of the table being used in this model	
	
	public $timestamps = false; //prevent the need to include time stamps

    
	 //will return the entire row based on the ID entered
	public function getTaskType($ID) {
		$taskData =tblTaskType::where('ID', '=', $ID)->get();
		return $taskData;
	}
}
?>


