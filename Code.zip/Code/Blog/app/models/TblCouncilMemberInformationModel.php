<?php
/**
Purpose: access tblCouncilMemberInformation via a model
Authors: Luke Gassmann
*/


use Illuminate\Database\Eloquent\Model;		// import the model class

class TblCouncilMemberInformationModel extends Model { //define class and inherit from the imported model class


	//define the table being used
	protected $table = 'CouncilMemberInformation';
	
	
	//get the constituency IDs a council member is responsible for
	public function getCouncilMemberConstituency($userID) {
		$constituencyID = TblCouncilMemberInformationModel::where('UserID', '=', $userID)->get(array("ConstituencyID"));
		        
		return $constituencyID;
	}
}


