<?php
/**
Purpose: model to access the tblMaintenanceTasks table
Authors: Josh Walker
*/

use Illuminate\Database\Eloquent\Model;		// import the model class


class TblMaintenanceTasks extends Model { //define class and inherit from the imported model class


	//table used by the model and remove the requirement of timestamps
	protected $table = 'tblMaintananceTask';
	
	public $timestamps = false;

	
    
	//function to write a new task record to the database 
    public function createTask($values) {
		$success = DB::table('tblMaintananceTask')->insert($values);

		return $success;
	}
	
	//used to assign a task to a maintenance user
	public function assignMaintenance($Task, $User) {
		$success = DB::table('tblMaintananceTask')->where('TaskID', $Task)->update(array('UserID' => $User));
		
		return $success;
	}
	
	//used to unassign a task if taken by a maintenance user
	public function unassignMaintenance($Task) {
		$success = DB::table('tblMaintananceTask')->where('TaskID', $Task)->update(array('UserID' => 0));
		
		return $success;
	}
	
	//update the done column to be 1 if the task is completed
	public function finishTask($Task) {
		$success = DB::table('tblMaintananceTask')->where('TaskID', $Task)->update(array('Done' => 1));
		
		return $success;
	}
	
	//get a specific record by the unique taskID
	public function getTask($ID) {
		$taskData =TblMaintenanceTasks::where('TaskID', '=', $ID)->get();
		
		return $taskData;
	}
	
	//used to compare the stats of maintanance users. Used by council users. 
	public function getComparisonStatsReporter($userID){
		$user_number = sizeof(TblMaintenanceTasks::where('ReporterID', '=', $userID)->get());
		$other_number = sizeof(TblMaintenanceTasks::where('ReporterID', '!=', $userID)->get());

		$all = TblMaintenanceTasks::all();
		
		return array("user_number" => $user_number, "other_number" => $other_number, "all" => $all);
	}
	
	//used by council users to compare statistics between the maintenance users
	public function getComparisonStatsMaintenance($userID){
		$user_number = sizeof(TblMaintenanceTasks::where('UserID', '=', $userID)->get());
		$other_number = sizeof(TblMaintenanceTasks::where('UserID', '!=', $userID)->get());
		$available = sizeof(TblMaintenanceTasks::where('Done', '=', '0')
							->where('UserID', '=', '0')
							->get());
		$all = TblMaintenanceTasks::all();
		
		return array("user_number" => $user_number, "other_number" => $other_number, "all" => $all, "available" => $available);
	}
	
	//get all completed tasks from the database
	public function getAllComplete(){
		$success = DB::table('tblMaintananceTask')->where('Done', 1)->get();
		return $success;
	}
	
	//get all NOT completed tasks from the database
	public function getAllNotComplete(){
		$success = DB::table('tblMaintananceTask')->where('Done', 0)->get();
		return $success;
	}
}


