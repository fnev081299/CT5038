<?php

namespace Bowser;

use Illumincate\Database\eloquent\model; //for database usage

    class tblFAQModel extends Eloquent { //class used to store functions relating to the table
        protect $table = 'tblFAQ'; //set table as the FAQ table
        
        
        public function getByID($id) { //allows  getting questions by ID (they auto-incriment)
            $Question = faq::where('faqNumber', '=', $id)->get();
            
            return $Question;
        }
        
    }
    
?>