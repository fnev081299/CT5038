<?php
/**
Purpose: access the tblUserInformation table through a model
Authors: Luke Gassmann and Josh Walker
*/

use Illuminate\Database\Eloquent\Model;		// import the model class


class TblUserInformationModel extends Model { //define class and inherit from the imported model class
	
	
	// Properties //
	
	private static $hashCost = [		// define hashing cost
		'cost' => 13,
	    'memory_cost' => 1024,
	    'time_cost' => 200,
	    'threads' => 2
	];
	
	
	//define the table being used
	protected $table = 'tblUserInfo';
	
	
	
	// disable timestamp requirements in table for updating/setting values
	public $timestamps = false;
	
	//remove a record from the database to delete a user
	public function deleteUser($id){		
		$value = TblUserInformationModel::where('id', '=', $id)->delete();
		$value = DB::table('tblUserProfilePicture')->where('id', '=', $id)->delete();
		return $value;

	}
	
	//get user information from the type of user (eg: maintenance returns all maintenance workers)
	public function getUserInformationFromType($type) {
		$name = TblUserInformationModel::where('user_type', '=', $type)->get(array("name", "id", "user_type", "email"));
		return $name;
	}
	
	
	// get user based on their email
	public function getUserByEmail($email) {
		$user = TblUserInformationModel::where('email', '=', $email)->first();
		return $user;
	}
	
	
	// get user based on their ID
	public function getUserByID($id) {
		$user = TblUserInformationModel::where('id', '=', $id)->first();
		return $user;
	}
	
	
	// get user searched for based on their email
	public function getSearchedUsers($search, $searcher_id) {
		$users = TblUserInformationModel::where('email', 'like', '%' . $search . '%')
			->where('id', '!=', $searcher_id)
			->orderBy('name', 'ASC')
			->get(array('name', 'id', 'user_type', 'email'));
		return $users;
	}
	
	
	// add user
	public function addUser($name, $email, $type) {
		
		// create random password
		$hash = TblUserInformationModel::hashPassword( TblUserInformationModel::generateToken() );
		
		// create random reset token
		$token = TblUserInformationModel::generateToken();
		
		$success = DB::table((new TblUserInformationModel)->getTable())->insert(array("name"=>$name, "password"=>$hash, "email"=>$email, "user_type"=>$type, 'resetToken' => $token));
		
		return array( 'success' => $success, 'token' => $token );
	}
	
	
	//check which user is logged in
	public function checkLogin($email, $password) {
		
		$user = TblUserInformationModel::getUserByEmail($email);
		
		if( empty($user) ) {
			$success = false;
		} else {
			// username matches: check password
		
			$result = TblUserInformationModel::checkHash( $password, $user->password );
			
			$success = $result['valid'];
			
			// update hash if out of date
			if( $result['rehash'] ) {
				
				TblUserInformationModel::where('email', '=', $email)->update(array('password' => $result['hash']));
			}
		}
		
		return $success;
	}
	
	
	// get name based on the ID
	public function getUserInformaiton($userID) {
		$name = TblUserInformationModel::where('id', '=', $userID)->get(array("name", "user_type"));
		        
		return $name;
	}
	
	
	// reset password
	public function resetPasswordbyEmail($email) {
		
		// create random password
		$hash = TblUserInformationModel::hashPassword( TblUserInformationModel::generateToken() );
		
		// create random reset token
		$token = TblUserInformationModel::generateToken();
		
		$success = TblUserInformationModel::where('email', '=', $email)->update(array('password' => $hash, 'resetToken' => $token));
		
		return array( 'success' => $success, 'token' => $token );
	}
	
	
	// update passowrd for a user
	public function setPasswordByToken($password, $token) {
		
		$hash = TblUserInformationModel::hashPassword( $password );
		
		$success = TblUserInformationModel::where('resetToken', '=', $token)->update(array('password' => $hash, 'resetToken' => Null));
		
		return $success;
	}
	
	
	// generate random 32-byte resetToken
	public static function generateToken() {
		
        $token = bin2hex(random_bytes(32));
        
		return $token;
	}
	
	
	// hash password using defined cost settings
	public static function hashPassword( $password ) {
		
        $hash = password_hash($password, PASSWORD_DEFAULT, self::$hashCost);
        
		return $hash;
	}
	
	
	// check if password hash matches and if it should be updated
	public static function checkHash( $password, $hash ) {
		
		$result = array(
		   'valid' => false,
		   'rehash' => false
		);
		
		// Verify stored hash against plain-text password
		if (password_verify($password, $hash)) {
			
		    // Check if a newer hashing algorithm is available or the cost has changed
		    if (password_needs_rehash($hash, PASSWORD_DEFAULT, self::$hashCost)) {
			    
		        // If so, create a new hash, and replace the old one
		        $newHash = password_hash($password, PASSWORD_DEFAULT, self::$hashCost);
		        
		        // hash should change
		        $result['rehash'] = true;
		        $result['hash'] = $newHash;
		    }
			
			// success
			$result['valid'] = true;
			
		}
		
		return $result;
	}
}


