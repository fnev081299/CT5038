<?php
/**
Purpose: 
Authors: 
*/

use Illuminate\Database\Eloquent\Model;		// if database access only


class TblReportInfo extends Model {


	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'tblReportInfo';		

	
	public $timestamps = false;

	
	public function getReport($ID) {
		$taskData =TblReportInfoModel::where('ReportID', '=', $ID)->get();
		return $taskData;
	}
}
?>


