<?php
/**
Purpose: modelto access tblUrgency 
Authors: Luke Gassmann
*/

use Illuminate\Database\Eloquent\Model;		// import the model class


class TblUrgencyModel extends Model {  //define class and inherit from the imported model class


	//define the table being used
	protected $table = 'tblUrgency';
	
	
	//get all entries in the table
    public function getUrgencyList() {
		$bowserData = TblUrgencyModel::all();
		return $bowserData;
	}
}


