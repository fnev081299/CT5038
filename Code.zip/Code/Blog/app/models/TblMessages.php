<?php
/**
Purpose: used to access tblMessages in the database
Authors: Luke Gassmann
*/


use Illuminate\Database\Eloquent\Model;		// import the model class


class TblMessages extends Model { //define class and inherit from the imported model class


	//set the table being accessed and remove the need for time stamps
	protected $table = 'tblMessages';
    
	public $timestamps = false;
	
    //get a specific record based on the ID
    public function get_messages($id) {
		$messages = TblMessages::where('thread_id', '=', $id)
			->orderBy('date_sent', 'ASC') //order them by the date sent in ascending order
			->get(array("date_sent", "message_type", "sender_id", "contents"));
		return $messages;
	}
	
	
	//used to insert a new entry to the database. This will be done when a message is sent
	public function sendMessage($values){
		$success = DB::table('tblMessages')->insert($values);

		return $success;
	}
}


