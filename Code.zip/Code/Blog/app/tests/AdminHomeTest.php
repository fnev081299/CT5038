<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AdminHomeTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/adminHome');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/adminHome');

        $response->assertRedirect('/councilhome');
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/adminHome');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/adminHome');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
	
	public function testLinkMenuStats()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminHome')
	         ->click('Statistics')
	         ->seePageIs('/adminHome');
	}
	
	public function testLinkMenuUsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminHome')
	         ->click('Employees')
	         ->seePageIs('/adminEmployees');
	}
	
	public function testLinkMenuAreas()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminHome')
	         ->click('Constituencies')
	         ->seePageIs('/adminConstituencies');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminHome')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminHome')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
