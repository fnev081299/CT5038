<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ResetTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/reset');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/reset');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/reset');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/reset');

		$response->assertResponseOk();
    }

}
