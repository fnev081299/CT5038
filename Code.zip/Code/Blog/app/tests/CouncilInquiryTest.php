<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CouncilInquiryTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/Inquiries');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/Inquiries');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/Inquiries');

        $response->assertRedirect('/adminHome');
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/Inquiries');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
	
	public function testLinkMenuHome()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Your Page')
	         ->seePageIs('/councilhome');
	}
	
	public function testLinkMenuBowsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Bowser New/Edit')
	         ->seePageIs('/bowseredit?BowserID=new');
	}
	
	public function testLinkMenuTasks()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Tasks')
	         ->seePageIs('/taskList');
	}
	
	public function testLinkMenuInquiries()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Inquiries')
	         ->seePageIs('/Inquiries');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/Inquiries')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
