<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ContactTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/contact');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/contact');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/contact');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/contact');

		$response->assertResponseOk();
    }
    
    
    
    
	
	public function testLinkMenuHome()
	{
	    $this->visit('/contact')
	         ->click('Home')
	         ->seePageIs('/');
	}
	
	public function testLinkMenuFind()
	{
	    $this->visit('/contact')
	         ->click('Find Bowsers')
	         ->seePageIs('/bowserNearMe');
	}
	
	public function testLinkMenuRequest()
	{
	    $this->visit('/contact')
	         ->click('Request')
	         ->seePageIs('/request');
	}
	
	public function testLinkMenuFAQ()
	{
	    $this->visit('/contact')
	         ->click('FAQ')
	         ->seePageIs('/faq');
	}
	
	public function testLinkMenuContact()
	{
	    $this->visit('/contact')
	         ->click('Contact Us')
	         ->seePageIs('/contact');
	}
	
	public function testLinkLogin()
	{
	    $this->visit('/contact')
	         ->click('Log In')
	         ->seePageIs('/login');
	}

}
