<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class BowserNearMeTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/bowserNearMe');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/bowserNearMe');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/bowserNearMe');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/bowserNearMe');

		$response->assertResponseOk();
    }
    
    
    
    
	
	public function testLinkMenuHome()
	{
	    $this->visit('/bowserNearMe')
	         ->click('Home')
	         ->seePageIs('/');
	}
	
	public function testLinkMenuFind()
	{
	    $this->visit('/bowserNearMe')
	         ->click('Find Bowsers')
	         ->seePageIs('/bowserNearMe');
	}
	
	public function testLinkMenuRequest()
	{
	    $this->visit('/bowserNearMe')
	         ->click('Request')
	         ->seePageIs('/request');
	}
	
	public function testLinkMenuFAQ()
	{
	    $this->visit('/bowserNearMe')
	         ->click('FAQ')
	         ->seePageIs('/faq');
	}
	
	public function testLinkMenuContact()
	{
	    $this->visit('/bowserNearMe')
	         ->click('Contact Us')
	         ->seePageIs('/contact');
	}
	
	public function testLinkLogin()
	{
	    $this->visit('/bowserNearMe')
	         ->click('Log In')
	         ->seePageIs('/login');
	}

}
