<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class LoginTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/login');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/login');

        $response->assertRedirect('/councilhome');
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/login');

        $response->assertRedirect('/adminHome');
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/login');

        $response->assertRedirect('/taskList');
    }
    
    public function testCouncilLogin()
    {
	    $password = '1234';
        $user = factory(User::class)->create([
            'user_type' => 'C',
            'password' => bcrypt($password),
        ]);

        $response = $this->from('/login')->post('/login_submit', [
            'email' => $user->email,
            'password' => $password,
        ]);

        $response->assertRedirect('/councilhome');
        
        $this->assertAuthenticatedAs($user);
    }
    
    public function testAdminLogin()
    {
	    $password = '1234';
        $user = factory(User::class)->create([
            'user_type' => 'A',
            'password' => bcrypt($password),
        ]);

        $response = $this->from('/login')->post('/login_submit', [
            'email' => $user->email,
            'password' => $password,
        ]);

        $response->assertRedirect('/adminHome');
        
        $this->assertAuthenticatedAs($user);
    }
    
    public function testMaintenanceLogin()
    {
	    $password = '1234';
        $user = factory(User::class)->create([
            'user_type' => 'M',
            'password' => bcrypt($password),
        ]);

        $response = $this->from('/login')->post('/login_submit', [
            'email' => $user->email,
            'password' => $password,
        ]);

        $response->assertRedirect('/taskList');
        
        $this->assertAuthenticatedAs($user);
    }
    
    public function testInvalidLogin()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
            'password' => bcrypt('1234'),
        ]);

        $response = $this->from('/login')->post('/login_submit', [
            'email' => $user->email,
            'password' => 'abcd',
        ]);
        
        $response->assertRedirect('/login');
        
        $this->assertGuest();
    }

}
