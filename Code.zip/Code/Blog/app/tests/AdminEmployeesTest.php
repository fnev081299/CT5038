<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AdminEmployeesTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/adminEmployees');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployees');

        $response->assertRedirect('/councilhome');
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployees');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployees');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
	
	public function testLinkMenuStats()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Statistics')
	         ->seePageIs('/adminHome');
	}
	
	public function testLinkMenuUsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Employees')
	         ->seePageIs('/adminEmployees');
	}
	
	public function testLinkMenuAreas()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Constituencies')
	         ->seePageIs('/adminConstituencies');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}
	
	
	
	
	
	public function testLinkCouncilAdd()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Council Member')
	         ->seePageIs('/adminEmployeeView?type=C');
	}
	
	public function testLinkMaintenanceAdd()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployees')
	         ->click('Maintenance Worker')
	         ->seePageIs('/adminEmployeeView?type=M');
	}

}
