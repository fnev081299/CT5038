<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class FAQTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/faq');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/faq');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/faq');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/faq');

		$response->assertResponseOk();
    }
    
    
    
    
	
	public function testLinkMenuHome()
	{
	    $this->visit('/faq')
	         ->click('Home')
	         ->seePageIs('/');
	}
	
	public function testLinkMenuFind()
	{
	    $this->visit('/faq')
	         ->click('Find Bowsers')
	         ->seePageIs('/bowserNearMe');
	}
	
	public function testLinkMenuRequest()
	{
	    $this->visit('/faq')
	         ->click('Request')
	         ->seePageIs('/request');
	}
	
	public function testLinkMenuFAQ()
	{
	    $this->visit('/faq')
	         ->click('FAQ')
	         ->seePageIs('/faq');
	}
	
	public function testLinkMenuContact()
	{
	    $this->visit('/faq')
	         ->click('Contact Us')
	         ->seePageIs('/contact');
	}
	
	public function testLinkLogin()
	{
	    $this->visit('/faq')
	         ->click('Log In')
	         ->seePageIs('/login');
	}

}
