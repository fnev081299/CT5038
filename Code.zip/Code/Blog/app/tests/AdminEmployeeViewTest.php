<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AdminEmployeeViewTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/adminEmployeeView?type=C');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployeeView?type=C');

        $response->assertRedirect('/councilhome');
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployeeView?type=C');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployeeView?type=C');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
    public function testMaintenanceUserType()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/adminEmployeeView?type=M');

		$response->assertResponseOk();
    }
    
    
    
    
    
	
	public function testLinkMenuStats()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployeeView?type=C')
	         ->click('Statistics')
	         ->seePageIs('/adminHome');
	}
	
	public function testLinkMenuUsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployeeView?type=C')
	         ->click('Employees')
	         ->seePageIs('/adminEmployees');
	}
	
	public function testLinkMenuAreas()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployeeView?type=C')
	         ->click('Constituencies')
	         ->seePageIs('/adminConstituencies');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployeeView?type=C')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminEmployeeView?type=C')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
