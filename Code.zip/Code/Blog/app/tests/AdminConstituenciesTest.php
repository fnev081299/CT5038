<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AdminConstituenciesTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/adminConstituencies');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/adminConstituencies');

        $response->assertRedirect('/councilhome');
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/adminConstituencies');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/adminConstituencies');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
	
	public function testLinkMenuStats()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminConstituencies')
	         ->click('Statistics')
	         ->seePageIs('/adminHome');
	}
	
	public function testLinkMenuUsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminConstituencies')
	         ->click('Employees')
	         ->seePageIs('/adminEmployees');
	}
	
	public function testLinkMenuAreas()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminConstituencies')
	         ->click('Constituencies')
	         ->seePageIs('/adminConstituencies');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminConstituencies')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/adminConstituencies')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
