<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RequestTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/request');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/request');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/request');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/request');

		$response->assertResponseOk();
    }
    
    
    
    
	
	public function testLinkMenuHome()
	{
	    $this->visit('/request')
	         ->click('Home')
	         ->seePageIs('/');
	}
	
	public function testLinkMenuFind()
	{
	    $this->visit('/request')
	         ->click('Find Bowsers')
	         ->seePageIs('/bowserNearMe');
	}
	
	public function testLinkMenuRequest()
	{
	    $this->visit('/request')
	         ->click('Request')
	         ->seePageIs('/request');
	}
	
	public function testLinkMenuFAQ()
	{
	    $this->visit('/request')
	         ->click('FAQ')
	         ->seePageIs('/faq');
	}
	
	public function testLinkMenuContact()
	{
	    $this->visit('/request')
	         ->click('Contact Us')
	         ->seePageIs('/contact');
	}
	
	public function testLinkLogin()
	{
	    $this->visit('/request')
	         ->click('Log In')
	         ->seePageIs('/login');
	}

}
