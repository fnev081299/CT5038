<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class LogoutTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/logout');

        $response->assertRedirect('/');

        $this->assertGuest();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/logout');

        $response->assertRedirect('/');

        $this->assertGuest();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/logout');

        $response->assertRedirect('/');

        $this->assertGuest();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/logout');

        $response->assertRedirect('/');

        $this->assertGuest();
    }

}
