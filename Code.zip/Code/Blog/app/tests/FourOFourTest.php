<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class FourOFourTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/404');

		$response->assertResponseOk();
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/404');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/404');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/404');

		$response->assertResponseOk();
    }

}
