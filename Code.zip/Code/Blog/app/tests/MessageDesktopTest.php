<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class MessageDesktopTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/messageDesktop');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/messageDesktop');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/messageDesktop');

		$response->assertResponseOk();
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/messageDesktop');

		$response->assertResponseOk();
    }
    
    
    
    
    
	
	public function testAdminLinkMenuStats()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Statistics')
	         ->seePageIs('/adminHome');
	}
	
	public function testAdminLinkMenuUsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Employees')
	         ->seePageIs('/adminEmployees');
	}
	
	public function testAdminLinkMenuAreas()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Constituencies')
	         ->seePageIs('/adminConstituencies');
	}
	
	public function testAdminLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testAdminLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}
    
    
    
    
    
	
	public function testCouncilLinkMenuHome()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Your Page')
	         ->seePageIs('/councilhome');
	}
	
	public function testCouncilLinkMenuBowsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Bowser New/Edit')
	         ->seePageIs('/bowseredit?BowserID=new');
	}
	
	public function testCouncilLinkMenuTasks()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Tasks')
	         ->seePageIs('/taskList');
	}
	
	public function testCouncilLinkMenuInquiries()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Inquiries')
	         ->seePageIs('/Inquiries');
	}
	
	public function testCouncilLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testCouncilLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}
    
    
    
    
    
	
	public function testMaintenanceLinkMenuTasks()
	{
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Tasks')
	         ->seePageIs('/taskList');
	}
	
	public function testMaintenanceLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testMaintenanceLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $this->actingAs($user)
        	 ->visit('/messageDesktop')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
