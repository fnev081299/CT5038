<?php

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CouncilHomeTest extends TestCase {
	
	public function testGuestAccess()
    {
        $response = $this->call('GET', '/councilhome');

        $response->assertRedirect('/');
    }
    
    public function testCouncilAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $response = $this->actingAs($user)->get('/councilhome');

		$response->assertResponseOk();
    }
    
    public function testAdminAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'A',
        ]);

        $response = $this->actingAs($user)->get('/councilhome');

        $response->assertRedirect('/adminHome');
    }
    
    public function testMaintenanceAccess()
    {
        $user = factory(User::class)->create([
            'user_type' => 'M',
        ]);

        $response = $this->actingAs($user)->get('/councilhome');

        $response->assertRedirect('/taskList');
    }
    
    
    
    
    
	
	public function testLinkMenuHome()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Your Page')
	         ->seePageIs('/councilhome');
	}
	
	public function testLinkMenuBowsers()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Bowser New/Edit')
	         ->seePageIs('/bowseredit?BowserID=new');
	}
	
	public function testLinkMenuTasks()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Tasks')
	         ->seePageIs('/taskList');
	}
	
	public function testLinkMenuInquiries()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Inquiries')
	         ->seePageIs('/Inquiries');
	}
	
	public function testLinkMenuChat()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Discussions')
	         ->seePageIs('/messageDesktop');
	}
	
	public function testLinkMenuLogout()
	{
        $user = factory(User::class)->create([
            'user_type' => 'C',
        ]);

        $this->actingAs($user)
        	 ->visit('/councilhome')
	         ->click('Log Out')
	         ->seePageIs('/login')
	         ->assertGuest();
	}

}
