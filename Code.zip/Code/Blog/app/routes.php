﻿<?php
/**
Purpose: Application Page Routing
Authors: Joe & Nick & Luke & Josh
*/

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/


// all users

Route::get('/', 'HomeController@index');


Route::get('bowserNearMe', 'BowserNearMeController@index');
Route::post('bowserNearMe_update', 'BowserNearMeController@update');


Route::get('contact', function() { return View::make('pages.contact'); });


Route::get('faq', 'faqController@index');
Route::post('faq_question', 'faqController@getQA');


Route::get('request', 'RequestController@index');
Route::post('request_submit', 'RequestController@submit');


Route::get('reset', 'ResetController@index');
Route::post('reset_strength', 'ResetController@strength');
Route::post('reset_submit', 'ResetController@submit');



// public(guest) users only
Route::group(array('before' => 'guest'), function() {
	
	Route::get('login', 'LoginController@index');
	Route::post('login_submit', 'LoginController@submit');
	
});



// any logged in users
Route::group(array('before' => 'auth'), function() {
	
	Route::get('messageDesktop', 'MessageDesktopController@index');
	Route::get('get_message_users_accounts', 'MessageDesktopController@getUsersAccounts');
	Route::post('get_messages', 'MessageDesktopController@get_messages');
	Route::post('send_message', 'MessageDesktopController@send_message');
	Route::post('create_connection', 'MessageDesktopController@create_connection');
	
	
	Route::post('save_image_text', 'MessageDesktopController@save_image');


	Route::get('logout', 'LogoutController@index');
	
});



// admin users only
Route::group(array('before' => 'auth.a'), function() {

	Route::get('adminHome', 'AdminHomeController@index');
	
	
	Route::get('adminConstituencies', 'AdminConstituenciesController@index');
	Route::get('adminConstituencyView', 'AdminConstituencyViewController@index');
	
	
	Route::get('adminEmployees', 'AdminEmployeesController@index');
	
	
	Route::get('adminEmployeeView', 'AdminEmployeeViewController@index');
	Route::post('reset_user', 'AdminEmployeeViewController@reset_user');
	Route::post('delete_user', 'AdminEmployeeViewController@delete_user');
	Route::post('create_user', 'AdminEmployeeViewController@create_user');
	
});



// council users only
Route::group(array('before' => 'auth.c'), function() {
	
	Route::get('bowseredit', 'BowserEditController@index');
	Route::post('get_constituency_bowsers', 'BowserEditController@get_all_constituency_bowsers');
	Route::post('be_addition_notes', 'BowserEditController@set_additional_notes');
	Route::post('be_data', 'BowserEditController@set_data');
	Route::post('be_maintenance', 'BowserEditController@set_maintenance');
	Route::post('be_new', 'BowserEditController@set_new');
	Route::post('be_bowser_types_by_name', 'BowserEditController@getBowserTypesByName');
	
	
	Route::get('councilhome', 'CouncilHomeController@index');
	
	
	Route::get('Inquiries', 'inquiriesController@index');
	Route::post('Inquiries_send', 'inquiriesController@send_email');
	Route::post('Inquiries_create', 'inquiriesController@create_Task');
	Route::post('Inquiries_delete', 'inquiriesController@delete_Inquiries');

});



// maintenance & council users only
Route::group(array('before' => 'auth.m&c'), function() {
	
	Route::get('taskList', 'taskListController@index');
	Route::post('taskList_update', 'taskListController@update');
	
});



// maintenance users only
Route::group(array('before' => 'auth.m'), function() {
	
	Route::post('taskList_assign', 'taskListController@assign');
	Route::post('taskList_unassign', 'taskListController@unassign');
	Route::post('taskList_finish', 'taskListController@finish');
	
});



