<?php
/**
Purpose: Controller for the logout page
Authors: Joe & Josh
*/

class BowserNearMeController extends \BaseController {

	// Get Load in information
	public function index()
	{
		//create a view with map user tracking and bowsers from database
		return View::Make('/pages/bowserNearMe')->with('mapDataA', array("track" => true, "bowsers" => []))->with('mapDataB', array("track" => false, "bowsers" => []));
	}
	
	
	// ajax send list of bowsers to page
	public function update() {
		
		try {
			$locationFound = isset($_POST['lat']) && isset($_POST['lng']);
			
			$dbBowsers = TblBowserInformationModel::getAllBowsers();
			
			$bowserList = array();
			
			foreach( $dbBowsers as $dbBowser ) {
				
					
				$bdBowserSize = $dbBowser->size;
				if( $bdBowserSize >= 1000000 ) {
					$bowserSize = number_format( $bdBowserSize/1000000	, 1, '.', ',' ) . " ML";
					
				} elseif ( $bdBowserSize >= 1000 ) {
					$bowserSize = number_format( $bdBowserSize/1000		, 1, '.', ',' ) . " kL";
					
				} else {
					$bowserSize = number_format( $bdBowserSize			, 1, '.', ',' ) . " L";
				}
				
				
				if($locationFound) {
					// calculate distance in miles
					$distanceNum = taskListController::vincentyGreatCircleDistance($_POST['lat'], $_POST['lng'], $dbBowser->latitude, $dbBowser->longitude);
					$distanceNum = $distanceNum / 1609.34;  // meters to miles
					
					$sortOrder = $distanceNum;
					
					// format distance string
					$bowserDistance = number_format( $distanceNum, 1, '.', ',' ) . " Miles";
				} else {
					$sortOrder = $dbBowser->BowserID;
					$bowserDistance = "-- Miles";
				}
				
				
				$bowserList[] = array(
					"order"		=> $sortOrder,
					"bowserID"	=> $dbBowser->BowserID,
					"inactive"	=> $dbBowser->bowserStatus != 0,
					"distance"	=> $bowserDistance,
					"size"		=> $bowserSize,
					"address"	=> $dbBowser->bowserAddress
				);
				
			}
					
			
			// sort bowsers by distance
			taskListController::SortByDistance($bowserList);
			
			// success
			$result = array(
			   'success' => true,
			   'bowsers' => $dbBowsers,
			   'bowserList' => $bowserList
			);
			return Response::json( $result );
			
			
		} catch( Exception $e ) {
			// error occured
			$result = array(
			   'success' => false,
			   'error' => "Unable to load bowser list\nError: " . $e->getMessage()
			);
			return Response::json( $result );
		}
	}


}


?>