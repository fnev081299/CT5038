<?php
/**
Purpose: Controller for the password reset page
Authors: Josh
*/



use Response;		// for ajax response reply


class ResetController extends \BaseController { //controller inherits from the baseController class

	// create page
	public function index()
	{
		if( isset($_GET['token']) ) {
			$token = $_GET[ 'token' ];
		} else {
			$token = '';
		}
		
		//return the view to make the page
		return View::Make('/pages/reset')->with('token', $token);
	}
	
	
	// return password strength
	public function strength()
	{
		
		$password = $_POST[ 'password' ];
		
		if ( empty($password) ) {
					
			// If empty display placeholder text
			$result = array(
			   'known' => true,
			   'message' => 'Passwords are checked against the haveibeenpwned.com database'
			);
			
		} else {
			
			// check against known hacked passwords
			$count = ResetController::hacked( $password );
			
			// Create UI message
			$message = '';
			if ($count > 0) {
				$message = 'This password has been found '.$count.' times in hacked websites';
			} else {
				$message = 'There are no known occurrences of this password being hacked';
			}
			
			// Return if known and message
			$result = array(
			   'known' => $count > 0,
			   'message' => $message
			);
		}
		
		return Response::json( $result );
	}
	
	
	// submit new password
	public function submit()
	{
		$password	= $_POST[ 'password' ];
		$confirm	= $_POST[ 'confirm' ];
		$complexity	= $_POST[ 'complexity' ];
		$token		= $_POST[ 'token' ];
		
		// Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Request new email and try again'
		);
	
		// Ensure that both inputs are valid and match
		if( !empty($password) && !empty($confirm) ) {
			if( $password == $confirm ) {
				
				
				// Check that password has atleast 10 characters
				if(strlen($password) >= 10) {
					
					
					// Check that the password meets the complexity requirement
					if($complexity >= 3) {
						
						
						// Check password is not the XKCD example "correcthorsebatterystaple"
						if( $password != "correcthorsebatterystaple" ) {
							
							
							// check that recovery token if not missing
							if( $token !== "" ) {
							
								// check against known hacked passwords
								$count = ResetController::hacked( $password );
								if( $count == 0 ) {
									
									// update password for user with token
									if( TblUserInformationModel::setPasswordByToken( $password, $token ) ) {
										
										$result['success'] = true;
										
									} else {
										$result['error'] = "Recovery token does not match: Request new email and try again";
									}
								} else {
									$result['error'] = "This password has been found ".$count." times in hacked websites: Try another";
								}
							} else {	
								$result['error'] = "Recovery token missing: Request new email and try again";
							}
						} else {
							$result['error'] = "This is the xkcd example password: Try another";
						}
					} else {
						$result['error'] = "Password does not meet minimum complexity requirement of 'Good': Try another";
					}
				} else {
					$result['error'] = "Password is not 10 characters or longer: Try another";
				}
			} else {
				$result['error'] = "Passwords do not match: Try again";
			}
		} else {
			$result['error'] = "Password fields cannot be empty: Try again";
		}
		
		return Response::json( $result );
	}
	
	
	// get number of times password has been hacked
	private static function hacked( $password ) {
		
		// hash passowrd to check against known hacked passwords
		$SHAhash = sha1($password);
		
		// Send first 5 character only of hash to get back list of possible matching hashes
		$page = file_get_contents("https://api.pwnedpasswords.com/range/".substr(strval($SHAhash), 0, 5));
		
		// Convert page into two arrays of all returned data and just hashes
		$returnedData = explode(PHP_EOL, $page);
		$hashList = array_map(function($string) {
			return substr($string, 0, 35);
		}, $returnedData);
		
		// Check for maching hash in list
		$needle = strtoupper(substr(strval($SHAhash), 5));
		$found = array_search($needle, $hashList);
		
		// State if found and how many times
		$known = ($found !== false);
		if($found) {
			$count = substr($returnedData[$found], 36);
		} else {
			$count = 0;
		}
		
		return $count;
	}

}
