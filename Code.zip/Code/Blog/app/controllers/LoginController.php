<?php
/**
Purpose: Controller for the login page
Authors: Nick & Joe & Josh
*/

use Response;		// for ajax response reply

class loginController extends \BaseController { //class extends baseController
	
	// create page
	public function index() {
		return View::Make('/pages/login');
	}
	
	// login request
	public function submit() {
		
		//attempt to authenticate the user and log them in
		$success = Auth::attempt(array('email' => $_POST[ 'email' ], 'password' => $_POST[ 'password' ]), true);
		
			
		if( $success ) {
			// success
			$result = array(
			   'success' => true,
			   'type' => "council"
			);
			
		} else {
			// incorrect login
			$result = array(
			   'success' => false,
			   'error' => "Wrong email or password"
			);
		}
		
        return Response::json( $result );
    }

}


?>