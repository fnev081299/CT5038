<?php
/**
Purpose: Controller for the messaging page
Authors: Luke
*/

class MessageDesktopController extends \BaseController {

    /*
    ################################
    Author: Luke Gassmann
    Purpose: Controller for Mobile
    ################################
    */
    
	// Get Load in information
	public function index()
	{
        
        // Get data to send to page
        $userID = Auth::user()->id;
    
		$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
        $constituencyID = $constituencyID[0]["attributes"]["ConstituencyID"];

        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        
        $userType = $usersName[0]["attributes"]["user_type"];
        
        $usersName = $usersName[0]["attributes"]["name"];
        
                
        $constituencyData = TblConstituencyModel::getConstituency($constituencyID);
        $constituencyData = $constituencyData[0]["attributes"];
        
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
            
        // Format data
        $councilInformation = array("name" => $usersName, 
                                    "constituencyData" => $constituencyData,
                                    "picture" => $profilePicture,
                                    "user_id" => $userID,
                                    "userType" => $userType
                                   );
                
        // Load page
		return View::Make('/pages/messagedesktop')->with('information', $councilInformation);
	}
    
    
    /*
    ################################
    Purpose: Get accounts
    ################################
    */
    public function getUsersAccounts(){
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);
        
        
        if (isset($_GET[ 'search' ]) && isset($_GET[ 'council_id' ])){
            
            // Get variables
            $search = trim($_GET[ 'search' ]);
            $council_id = (int)$_GET[ 'council_id' ];
            
            // Check length
            if (strlen($search) > 0){
                
                // Get users
                $result['value'] = TblUserInformationModel::getSearchedUsers($search, $council_id);

                // Add the users image
                foreach ($result['value'] as $user){
                    $image = TblUserProfilePictureModel::getProfilePictureLive($user["id"]);

                    
                    $user["picture"] = $image;


                }
                
                $result['success'] = true;
            }
            
            
            

        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
    }
    
    
    /*
    ################################
    Purpose: Get the users messages
    ################################
    */
    public function get_messages(){
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);
        
        
        if (isset($_POST[ 'user_1' ]) && isset($_POST[ 'user_2' ])){
            
            // Get messages
            $user_1 = (int)trim($_POST[ 'user_1' ]);
            $user_2 = (int)trim($_POST[ 'user_2' ]);
            
            // Get message id
            $id = TblMessagingOverview::get_messaging_id($user_1, $user_2);
            
            // Check messages exist
            if (sizeof($id) > 0){
                $result['value'] = TblMessages::get_messages($id[0]["messaging_id"]);
                $result['creation_date'] = $id[0]["creation_date"];

                $result['success'] = true;
            }
            
            // Get users names
            $usersName = TblUserInformationModel::getUserInformaiton($user_1);
            $result['user1'] = array("id"=>$user_1, "name"=>$usersName[0]["name"]);

            $usersName = TblUserInformationModel::getUserInformaiton($user_2);
            $result['user2'] =  array("id"=>$user_2, "name"=>$usersName[0]["name"]);
            
            $result["id"] = $id;
            
        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
    }
    
    /*
    ################################
    Purpose: Send a message
    ################################
    */
    public function send_message(){
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);
        
        
        if (isset($_POST[ 'message' ]) && isset($_POST[ 'type' ]) && isset($_POST[ 'council' ]) && isset($_POST[ 'friend' ])){

            // Get variables
            $sender = (int)trim($_POST[ 'council' ]);
            $receiver = (int)trim($_POST[ 'friend' ]);
            $message = trim($_POST[ 'message' ]);
            $type = trim($_POST[ 'type' ]);
            $id = TblMessagingOverview::get_messaging_id($sender, $receiver)[0]["messaging_id"];
            
            // Send message
            $success = TblMessages::sendMessage(array("thread_id"=>$id, 
                                                      "message_type"=>$type, 
                                                      "contents"=>$message,
                                                      "sender_id"=>$sender));
            $result['success'] = true;
        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
    }
    
    
    /*
    ###############################################
    Purpose: Create a connection between users
    ###############################################
    */
    public function create_connection(){
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);
        
        
        if (isset($_POST[ 'user_1' ]) && isset($_POST[ 'user_2' ])){
            
            // Get variables
            $user_1 = (int)trim($_POST[ 'user_1' ]);
            $user_2 = (int)trim($_POST[ 'user_2' ]);
            
            // Create connection
            TblMessagingOverview::create_connection($user_1, $user_2);
            
            $result['success'] = true;
        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
    }
    
    
    /*
    ################################
    Purpose: Save an image
    ################################
    */
    public function save_image(){
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);        
        
        // Move photo
        $info = pathinfo($_FILES['photoPicked']['tmp_name']);
        
        // Name of image
        $newname = $_FILES['photoPicked']['name']; 
        
        // New address
        $target = 'Resources/Images/Saved/'.round(microtime(true) * 1000).$newname;
        
        // Move file from temp
        move_uploaded_file( $_FILES['photoPicked']['tmp_name'], $target);
        
        $result['value'] = $target;

        return Response::json($result);
    }
    
    

}














?>