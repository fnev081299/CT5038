<?php
/**
Purpose: Controller for the maintenance user task list page
Authors: Josh & Joe
*/

use Response;		// for ajax response reply

class taskListController extends \BaseController { //class extends baseController
	
	// create page
	public function index() {
				
		return View::Make('/pages/taskList')->with('mapDataA', array("track" => true, "bowsers" => []))->with('mapDataB', array("track" => false, "bowsers" => []));
	}
	
	
	// ajax send list of tasks to page
	public function update() {
		
		try {
			//authenticate the user 
			$userID = Auth::user()->id;
	        
			//get the constituency ID of the user
			$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
	        $constituencyID = $constituencyID[0]["attributes"]["ConstituencyID"];
			
			//get the lat and long of the bowser a task relates to
			$locationFound = isset($_POST['lat']) && isset($_POST['lng']);
			
			$dbTasks = TblMaintenanceTasks::getAllNotComplete();
			
			$tasks = array();
			$bowsers = array();
			
			foreach( $dbTasks as $dbTask ) {
				
				
				// if task is not being created
				$taskReady = ( tblTaskType::getTaskType( $dbTask->TaskTypeID )[0]->ID  >=  0);
				if( $taskReady ) {
					
					
					// if task is not owned by another user
					$notTaken = ($dbTask->UserID == 0) || ($dbTask->UserID == $userID);
					if( $notTaken || Auth::user()->user_type == "C" ) {
					
						$bowser = TblBowserInformationModel::getLiveBowsersUnderBowserID( $dbTask->BowserID )[0];
						
						
						// if bowser is in users constituency
						$inConstituency = $bowser->ConstituencyID == $constituencyID;
						if( $inConstituency ) {
						
							$bowserSize = $bowser->size;
							if( $bowserSize >= 1000000 ) {
								$taskSize = number_format( $bowserSize/1000000	, 1, '.', ',' ) . " ML";
								
							} elseif ( $bowserSize >= 1000 ) {
								$taskSize = number_format( $bowserSize/1000		, 1, '.', ',' ) . " kL";
								
							} else {
								$taskSize = number_format( $bowserSize			, 1, '.', ',' ) . " L";
							}
							
							
							$taskAction = tblTaskType::getTaskType( $dbTask->TaskTypeID )[0]->Meaning;
							
							if($locationFound) {
								// calculate distance in miles
								$distanceNum = taskListController::vincentyGreatCircleDistance($_POST['lat'], $_POST['lng'], $bowser->latitude, $bowser->longitude);
								$distanceNum = $distanceNum / 1609.34;  // meters to miles
								
								// format distance string
								$taskDistance = number_format( $distanceNum, 1, '.', ',' ) . " Miles";
								
								// prioritise
								if($dbTask->UserID == $userID) {
									$sortOrder = $distanceNum - 100000;
								} else {
									$sortOrder = $distanceNum;
								}
							} else {
								$sortOrder = $dbTask->BowserID - 100000*$dbTask->Urgency;
								$taskDistance = "-- Miles";
							}
							
							
							if($dbTask->ReportID >= 0) {
								$taskProblem = tblReportInfo::getReport( $dbTask->ReportID )[0]->reportDescription;
							} else {
								$taskProblem = "";
							}
							
							//array of tasks
							$tasks[] = array( 
								"order"		=> $sortOrder,
								"taskID"	=> $dbTask->TaskID,
								"bowserID"	=> $dbTask->BowserID,
								"priority"	=> $dbTask->Urgency,
								"distance"	=> $taskDistance,
								"size"		=> $taskSize,
								"action"	=> $taskAction,
								"problem"	=> $taskProblem,
								"details"	=> $dbTask->additionalNotes,
								"myTask"	=> $dbTask->UserID > 0,
								"council"	=> Auth::user()->user_type == "C",
								"userID"	=> $dbTask->UserID,
								"reporterID"=> $dbTask->ReporterID
							);
							
							$bowser->taskID = $dbTask->TaskID;
							$bowsers[] = $bowser;
						}
					}
				}
			}
			
			//sort the tasks by distance from user
			taskListController::SortByDistance($tasks);
			
			// success
			$result = array(
			   'success' => true,
			   'bowsers' => $bowsers,
			   'tasks' => $tasks
			);
			return Response::json( $result );
			
		} catch( Exception $e ) {
			// error occured
			$result = array(
			   'success' => false,
			   'error' => "Unable to load task list\nError: " . $e->getMessage()
			);
			return Response::json( $result );
		}
	}
	
	
	// sort tasks by distance
	public function SortByDistance(array &$list) {
		usort($list, function($a, $b) {
			
		    if ($a['order'] == $b['order']) {
			    
			    if ($a['taskID'] == $b['taskID']) {
			    
				    if ($a['bowserID'] == $b['bowserID']) {
					    return 0;
				    }
					return ($a['bowserID'] < $b['bowserID']) ? -1 : 1;
			    }
				return ($a['taskID'] < $b['taskID']) ? -1 : 1;
		    }
		    return ($a['order'] < $b['order']) ? -1 : 1;
		});
	}
	
	
	// ajax assign task to user
	public function assign() {
		
		try {
			// attempt to assign task to user
			$userID = Auth::user()->id;
			
			$taken = TblMaintenanceTasks::getTask($_POST[ 'id' ])[0]->UserID > 0;
			
			if( $taken ) {
				// task already assigned
				$result = array(
				   'success' => false,
				   'error' => "Task already assigned"
				);
				
			} else {
				
				$success = TblMaintenanceTasks::assignMaintenance($_POST[ 'id' ], $userID);
				
				if( $success ) {
					// success
					$result = array(
					   'success' => true
					);
					
				} else {
					// unable to assign task
					$result = array(
					   'success' => false,
					   'error' => "Unable to assign task"
					);
				}
			}
			return Response::json( $result );
			
			
		} catch( Exception $e ) {
			// error occured
			$result = array(
			   'success' => false,
			   'error' => "Unable to load task list\nError: " . $e->getMessage()
			);
			return Response::json( $result );
		}
	}
	
	
	
	// ajax unassign task
	public function unassign() {
		
		try {
			// attempt to unassign task from user
			$userID = Auth::user()->id;
			
			$notOwned = TblMaintenanceTasks::getTask($_POST[ 'id' ])[0]->UserID != $userID;
			
			if( $notOwned ) {
				// task not assigned to user
				$result = array(
				   'success' => false,
				   'error' => "You do not own task"
				);
				
			} else {
				
				$success = TblMaintenanceTasks::unassignMaintenance($_POST[ 'id' ]);
				
				if( $success ) {
					// success
					$result = array(
					   'success' => true
					);
					
				} else {
					// unable to un-assign task
					$result = array(
					   'success' => false,
					   'error' => "Unable to un-assign task"
					);
				}
			}
			return Response::json( $result );
			
			
		} catch( Exception $e ) {
			// error occured
			$result = array(
			   'success' => false,
			   'error' => "Unable to un-assign task\nError: " . $e->getMessage()
			);
			//return the response
			return Response::json( $result );
		}
		
	}
	
	
	
	// ajax finish task
	public function finish() {
		
		try {
			// attempt to finish task for user
			$userID = Auth::user()->id;
			
			$notOwned = TblMaintenanceTasks::getTask($_POST[ 'id' ])[0]->UserID != $userID;
			
			if( $notOwned ) {
				// task not assigned to user
				$result = array(
				   'success' => false,
				   'error' => "You do not own task"
				);
				
			} else {
				
				$success = TblMaintenanceTasks::finishTask($_POST[ 'id' ]);
				
				if( $success ) {
					// success
					$result = array(
					   'success' => true
					);
					
				} else {
					// unable to finish task
					$result = array(
					   'success' => false,
					   'error' => "Unable to finish task"
					);
				}
			}
			//return the response
			return Response::json( $result );
			
			
		} catch( Exception $e ) {
			// error occured
			$result = array(
			   'success' => false,
			   'error' => "Unable to finish task\nError: " . $e->getMessage()
			);
			//return the response
			return Response::json( $result );
		}
	}
	
	
	//  martinstoeckli and Hein, D., 2016. Measuring The Distance Between Two Coordinates In PHP. [online] Stack Overflow.
	//  Available at: <https://stackoverflow.com/a/10054282> [Accessed 26 April 2020].
	/**
	 * Calculates the great-circle distance between two points, with
	 * the Vincenty formula.
	 * @param float $latitudeFrom Latitude of start point in [deg decimal]
	 * @param float $longitudeFrom Longitude of start point in [deg decimal]
	 * @param float $latitudeTo Latitude of target point in [deg decimal]
	 * @param float $longitudeTo Longitude of target point in [deg decimal]
	 * @param float $earthRadius Mean earth radius in [m]
	 * @return float Distance between points in [m] (same as earthRadius)
	 */
	public static function vincentyGreatCircleDistance(
	  $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
	{
	  // convert from degrees to radians
	  $latFrom = deg2rad($latitudeFrom);
	  $lonFrom = deg2rad($longitudeFrom);
	  $latTo = deg2rad($latitudeTo);
	  $lonTo = deg2rad($longitudeTo);
	
	  $lonDelta = $lonTo - $lonFrom;
	  $a = pow(cos($latTo) * sin($lonDelta), 2) +
	    pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
	  $b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);
	
	  $angle = atan2(sqrt($a), $b);
	 //return the angle multipled by radius of earth
	  return $angle * $earthRadius;
	}
}


?>