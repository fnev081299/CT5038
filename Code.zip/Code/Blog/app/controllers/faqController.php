<?php
/**
Purpose: Controller for the faq page
Authors: Joe and Nick
*/

class faqController extends \BaseController {
	
	// create page
    public function index() {
        return View::Make('/pages/faq');
    }
	
	// return FAQ list from database
	public function getQA() { //get the questions and answers from database
		for ($i = 1; $i < tblFAQModel::count(); $i++) {
			$QA = TblFAQModel::getByID($i);

			$Question = $QA[1]; 
			$Answer = $QA[2];
			echo $Question;
		}
		return Response::json( $QA ); //update page
	}
}

?>