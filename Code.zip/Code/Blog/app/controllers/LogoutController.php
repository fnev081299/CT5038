<?php
/**
Purpose: Controller for the logout page
Authors: Josh
*/

class logoutController extends \BaseController { //class extends baseController
	
	// Logout user
	public function index() {
		
		Auth::logout();
		
		return Redirect::to('/login');
	}

}

?>

