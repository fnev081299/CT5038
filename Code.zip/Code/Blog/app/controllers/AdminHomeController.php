<?php
/**
Purpose: Controller for the Admin home page
Authors: Luke
*/

class AdminHomeController extends \BaseController { //inherit default functionality from the baseController

	// Get Load in information
	public function index()
	{
		//get the authorised user ID
        $userID = Auth::user()->id;
        
		//get the constituency ID of the authenticated user
		$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
        $constituencyID = $constituencyID[0]["attributes"]["ConstituencyID"];

		//get the user information
        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
        
		
		//get all the bowsers in seperate arrays for all, live bowsers and offline bowsers
        $bowserInformation = TblBowserInformationModel::getAllBowsers();
        $bowserLiveInformation = TblBowserInformationModel::getAllLiveBowsers();
        $bowserOfflineInformation = TblBowserInformationModel::getAllOfflineBowsers();
        
        //get 2 arrays showing the tasks complete and not complete
        $maintenance_complete = TblMaintenanceTasks::getAllComplete();
        $maintenance_uncomplete = TblMaintenanceTasks::getAllNotComplete();
        
        $maintenance_tasks = array("complete"=>$maintenance_complete, "uncomplete"=>$maintenance_uncomplete);
        
		//get the task types for the bowsers 
        $bowserTypes = TblBowserTaskID::getBowserTaskTypes();
        $bowserTypesDict = array();        
        foreach($bowserTypes as $bowserType){
            $name = $bowserType["attributes"]["Meaning"];
            $id = $bowserType["attributes"]["ID"];
            $description = $bowserType["attributes"]["Description"];
            $image = $bowserType["attributes"]["image"];
            
            $bowserTypesDict[$id] = array('name'=>$name, 'id'=>$id, 'description'=>$description, 'image' => $image );
        }
        
		//get the constituency
        $constituencyData = TblConstituencyModel::getConstituency($constituencyID);
        $constituencyData = $constituencyData[0]["attributes"];
        
        //create an array with the returning data
        $councilInformation = array("name" => $usersName, 
                                    "constituencyData" => $constituencyData,
                                    "bowserData" => $bowserInformation,
                                    "bowserLiveData" => $bowserLiveInformation,
                                    "bowserOfflineData" => $bowserOfflineInformation,
                                    "bowserTypes"=>$bowserTypesDict,
                                    "maintenanceTasks"=>$maintenance_tasks
                                   );
       
        
        //return the view to create the page
		return View::Make('/pages/adminhome')->with('information', $councilInformation);
	}


}


?>