<?php
/**
Purpose: Controller for the Admin employee list page
Authors: Luke & Josh
*/

class AdminEmployeeViewController extends \BaseController {

	// Get Load in information
	public function index()
	{
		//get authenticated user
        $userID = Auth::user()->id;
        
        $user_account_data = array();
        
		//if user account is set and not equal to the default "new", get the account number, profile picture and constituency ID of said user
        if (isset($_GET["user_account"])){
            if ($_GET["user_account"] != "new"){
                $user_account_number = $_GET["user_account"];

                $user_account_details = TblUserInformationModel::getUserInformaiton($user_account_number);
                $user_account_name = $user_account_details[0]["attributes"]["name"];

                $user_account_profilePicture = TblUserProfilePictureModel::getProfilePicture($user_account_number);
                $user_account_profilePicture = $user_account_profilePicture[0]["attributes"]["picture_location"];

                $user_account_constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($user_account_number);
                $user_account_constituencyID = $user_account_constituencyID[0]["attributes"]["ConstituencyID"];

				//prevent errors with ID 0
                if ($user_account_constituencyID == 0){
                    $user_account_constituencyID = 1;
                }
                
				//get the constituency  of the user from the ID
                $user_account_constituencyData = TblConstituencyModel::getConstituency($user_account_constituencyID);
                $user_account_constituencyData = $user_account_constituencyData[0]["attributes"];

				//if user is a council member, get compairson data about them
                if ($user_account_details[0]["attributes"]["user_type"] == "C"){
                    $user_account_data["reporter_details"] = TblMaintenanceTasks::getComparisonStatsReporter($user_account_number);
                }
				//if user is a maintenance user, get comparison information about them
                elseif ($user_account_details[0]["attributes"]["user_type"] == "M"){
                    $user_account_data["reporter_details"] = TblMaintenanceTasks::getComparisonStatsMaintenance($user_account_number);
                }
                else{
					//pass
                }
                
				//get bowsers under the ID of the user's constituency
                $bowserInformation = TblBowserInformationModel::getBowsersUnderConstituencyID($user_account_constituencyID);

                $user_account_data["bowser_data"] = $bowserInformation;
                $user_account_data["id"] = $user_account_number;
                $user_account_data["user_type"] = $user_account_details[0]["attributes"]["user_type"];
                $user_account_data["name"] = $user_account_name;
                $user_account_data["picture"] = $user_account_profilePicture;
                $user_account_data["constituency_ID"] = $user_account_constituencyID;
                $user_account_data["constituency_data"] = $user_account_constituencyData;
            }
            else{ //use default profile picture if not set           
                $user_account_data["picture"] = "../userDefault.png";
                    
                if (!isset($_GET['user_account_type'])){
                    $_GET['user_account_type'] = "C";
                }
            }
            
        }
        else{ //if user account not set, create new council member
            $_GET['user_account'] = "new";
            $_GET['user_account_type'] = "C";
        }
        
        
        //get all constituencies
        $constituencies = TblConstituencyModel::getAll();
        
        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
                
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
                
        $councilInformation = array("name" => $usersName, 
                                    "picture" => $profilePicture,
                                    "user_account" => $user_account_data,
                                    "constituencies" => $constituencies
                                   );
        
        
		//return the view        
		return View::Make('/pages/adminemployeeview')->with('information', $councilInformation);
	}
    
    
    // ajax reset user
    public function reset_user(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);
		
		if (isset($_POST[ 'id' ])){
			
			$user = TblUserInformationModel::getUserByID($_POST[ 'id' ]);
			
			$return = TblUserInformationModel::resetPasswordbyEmail( $user['email'] );
			
			// store current user
			$user = Auth::user();
			
			// logout user
			Auth::setUser( User::find($_POST['id']) );
			Auth::logout();
			
			// return to user
			Auth::setUser($user);
			
			if ($return['success']) {
		        $result['success'] = EmailModel::sendReset( $user['email'], $user['name'], $return['token'] );
		
		        if ($result['success']){
		            $result['error'] = "Reset Email Sent";
		        }
		        else{
		            $result['error'] = 'Sending Email Failed';
		        }
			}
        } else {
            $result['error'] = 'No ID provided';
        }
        
        return Response::json($result);
    }
    
    
    // ajax delete user
    public function delete_user(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);

        if (isset($_POST[ 'id' ])){
            $result['value'] = TblUserInformationModel::deleteUser($_POST[ 'id' ]);
            $result['success'] = true;
            $result['error'] = "User Deleted";
        }
        else{
            $result['error'] = 'No ID provided';
        }
        
        return Response::json($result);
    }
    
    
    // ajax create user
    public function create_user(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);
		
		//ensure the informatikon has been provided correctly
        if (isset($_POST[ 'name' ]) && isset($_POST[ 'email' ]) && isset($_POST[ 'type' ]) && isset($_POST["constituency"])){
            if ($_POST[ 'name' ]!="" && $_POST[ 'email' ]!="" && $_POST[ 'type' ]!="" && $_POST[ 'constituency' ]!=""){
	            
	            
                $name = $_POST[ 'name' ];
                $email = $_POST[ 'email' ];
                $type = $_POST[ 'type' ];
				$constituency = $_POST["constituency"];
						    
			    $constituencyStr = TblConstituencyModel::getConstituency($constituency)[0]["constituencyName"];
			    
			    if($type == "C") {$typeStr = "Council";}
			    elseif($type == "M") {$typeStr = "Maintenance";}
			    elseif($type == "A") {$typeStr = "Admin";}
			    else {$typeStr = "";}

                $matching_users = TblUserInformationModel::getUserByEmail($email);

                if ($matching_users == null) { //ensures a unique email for each database entry
	                
                    $createUser = TblUserInformationModel::addUser($name, $email, $type);

                    $userID = TblUserInformationModel::getUserByEmail($email)["id"];
                    
					if ($createUser['success']) {
						if ($type == "C") {
							// council user
							
	                        $result['success'] = DB::table('CouncilMemberInformation')->insert(array("UserID"=>$userID, "ConstituencyID"=>$constituency));
		                    
					        
					    } else {
						    // other user type
						    $constituency = "";
							$result['success'] = true;
					    }
					    
					    
					    if( $result['success'] ) {
							
					        $result['success'] = EmailModel::sendWelcome( $email, $name, $constituencyStr, $typeStr, $createUser['token'] );
					        			
					        if ($result['success']){
					            $result['error'] = "Welcome Email Sent";
								$result['redirect'] = "/adminEmployeeView?user_account=" . $userID;
					        } else {
					            $result['error'] = 'Sending Email Failed';
					        }
					    }
					    
					    
					} else {
						$result['error'] = 'Create user failed: Please input information again';
					}
                } else {
                    $result['error'] = 'Email already exists';
                }
                
                
            } else {
                $result['error'] = 'Information not provided';
            }
        } else {
            $result['error'] = 'Information not provided';
        }
        //return the response
        return Response::json($result);
    }
    
}








?>