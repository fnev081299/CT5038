<?php
/*
Author: Luke
Purpose: Controller for the home page. Used to return a view
*/

class HomeController extends BaseController { //inherit from the baseController class for added functionality

	//run the set up the view of the website
	public function index()
	{
		//get all bowsers in an array
		$allBowsers = TblBowserInformationModel :: getAllBowsers();
		$bowsers = array();
		foreach($allBowsers as $bowser) {
				array_push($bowsers, $bowser);
		}
		//return the view to make the website
		return View::make('/pages/home')->with('mapData', array("track" => true, "lat" => 0, "lng" => 0, "bowsers" => $bowsers));
	}

}
