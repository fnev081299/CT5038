<?php
/**
Purpose: Controller for the council inquiries page
Authors: Joe & Nicolas E.V. & Josh
*/


use Response;		// for ajax response reply

class inquiriesController extends \BaseController {
	
	// create page
    public function index() {
	    
	    // get constituency information for email reply form
		$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency( Auth::user()->id )[0]->ConstituencyID;
        $constituencyName = TblConstituencyModel::getConstituency($constituencyID)[0]->constituencyName;
        
        // get list of public inqueries 
		$inqueryData = tblPublicRequests::getRequests();
		
		
		$repairsCount[ 'All' ] = count( $inqueryData );
		$repairsCount['Refill'] = 0;
		$repairsCount['Flooded Area'] = 0;
		$repairsCount['Leaking'] = 0;
		$repairsCount['Vandalism'] = 0;
		$repairsCount['Observation'] = 0;
		
		$inqueries = array();
		foreach($inqueryData as $dbInquery) {
			
			// create list of inqueries for page
			$bowserID = self::findNearestBowser($dbInquery['lat'], $dbInquery['long']);
			$show = !empty($dbInquery["description"]) && !empty($dbInquery["email"]);
			
			$inqueries[] = [
				"sendID"	=> $dbInquery["sendID"],
				"bowserID"	=> $bowserID,
				"type"		=> $dbInquery["type"],
				"description" => $dbInquery["description"],
				"show"		=> $show
			];
			
			
			// count total inqueries by type and bowser&type
			if( isset($repairsCount[ $dbInquery["type"] ]) ) {
				$repairsCount[ $dbInquery["type"] ]++;
			} else {
				$repairsCount[ $dbInquery["type"] ] = 1;
			}
			
			if( isset($bowsersCount[ $bowserID ][ $dbInquery["type"] ]) ) {
				$bowsersCount[ $bowserID ][ $dbInquery["type"] ]++;
			} else {
				$bowsersCount[ $bowserID ][ $dbInquery["type"] ] = 1;
			}
		}
		
		// sort inqueries to group by bowser then type
		self::SortInqueries($inqueries);
		
		
		$lastInquery = "";
		$inqueryList = array();
		foreach($inqueries as $inquery) {
			
			// add heading row into list for each group
			$string = strval($inquery["bowserID"]).$inquery["type"];
			if( strcmp($lastInquery, $string) ) {
				
				$address = TblBowserInformationModel::getLiveBowsersUnderBowserID( $inquery["bowserID"] )[0]->bowserAddress;
				
				$inqueryList[] = [
					"sendID"	=> -1,
					"reportID"	=> $inquery["sendID"],
					"bowserID"	=> $inquery["bowserID"],
					"type"		=> $inquery["type"],
					"address"	=> $address,
					"count"		=> $bowsersCount[ $inquery["bowserID"] ][ $inquery["type"] ]
				];
			}
			
			// only show individual entry if there is a message and return email address
			if( $inquery['show'] ) {
				
				$inqueryList[] = $inquery;
			}
			
			$lastInquery = $string;
		}
		
		
		//return the view to make the page
        return View::Make('/pages/councilinquiry')->with("inqueries", $inqueryList)->with("repairsCount", $repairsCount)->with("constituency", $constituencyName);
    }
    
    
    // ajax send reply email
    public function send_email() {
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);
		
		if(isset($_POST[ 'message' ]) && isset($_POST[ 'reportID' ])) {
	    
		    // get constituency information for email reply form
			$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency( Auth::user()->id )[0]->ConstituencyID;
	        $constituencyName = TblConstituencyModel::getConstituency($constituencyID)[0]->constituencyName;
			
			$request = tblPublicRequests::getFromID($_POST[ 'reportID' ]);
			
			$email = $request->email;
			$userName = Auth::user()->name;
			$inquery = $request->description;
			
			
	        $result['success'] = EmailModel::sendReply( $email, $userName, $constituencyName, $inquery, $_POST[ 'message' ] );
	
	        if ($result['success']){
		        // do nothing
	        } else {
	            $result['error'] = 'Sending Email Failed';
	        }
        } else {
            $result['error'] = 'Empty message or no ReportID';
        }
        
        return Response::json($result);
    }
    
    
    // ajax create task for inquiry
    public function create_Task() {
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try again',
		);
		
		if(isset($_POST[ 'bowserID' ]) && isset($_POST[ 'type' ])) {
			
			$bowser = TblBowserInformationModel::getLiveBowsersUnderBowserID( $_POST[ 'bowserID' ] )[0];
			
			
				if( $_POST[ 'type' ] == 'Refill' )		 { $jobType = 2; }
			elseif( $_POST[ 'type' ] == 'Flooded Area' ) { $jobType = 6; }
			elseif( $_POST[ 'type' ] == 'Leaking' )		 { $jobType = 1; }
			elseif( $_POST[ 'type' ] == 'Vandalism' )	 { $jobType = 5; }
			elseif( $_POST[ 'type' ] == 'Observation' )	 { $jobType = 6; }
            
            
            $values = array(
                "ReportID"		=> -1,
                "ReporterID"	=> Auth::user()->id,
                "Urgency"		=> 2,
                "TaskTypeID"	=> $jobType,
                "BowserID"		=> $bowser->BowserID
            );

            $result['value'] = TblMaintenanceTasks::createTask( $values );
            $result['value2'] = TblBowserInformationModel::setBowserIndividual($bowser->BowserID, array('bowserStatus' => $jobType));
            $result['success'] = true;
			
        } else {
            $result['error'] = 'BowserID or inquiry type missing';
        }
        
        return Response::json($result);
    }
    
    
    // ajax delete inquiries matching bowser and type
    public function delete_Inquiries() {
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try again',
		);
		
		if(isset($_POST[ 'sendID' ]) && isset($_POST[ 'type' ])) {
			
			$result['success'] = tblPublicRequests::removeByIDandType($_POST[ 'sendID' ], $_POST[ 'type' ]);
	
	        if ($result['success']){
		        // do nothing
	        } else {
	            $result['error'] = 'Delete failed';
	        }
        } else {
            $result['error'] = 'BowserID or inquiry type missing';
        }
        
        return Response::json($result);
    }
	
	
	// sort inqueries by bowser and type
	public function SortInqueries(array &$list) {
		usort($list, function($a, $b) {
			
		    if ($a['bowserID'] == $b['bowserID']) {
		    
			    if ($a['type'] == $b['type']) {
			    
				    if ($a['sendID'] == $b['sendID']) {
					    return 0;
				    }
					return ($a['sendID'] < $b['sendID']) ? -1 : 1;
			    }
				return ($a['type'] < $b['type']) ? -1 : 1;
		    }
			return ($a['bowserID'] < $b['bowserID']) ? -1 : 1;
		});
	}
	
	
	// find nearest bowser to lat lng co-ordinates
	public function findNearestBowser($compLat, $compLong) {
		$data = TblBowserInformationModel::getAllBowsers();
		
		$comparative = array();
		//forloop making array of arrays
		foreach($data as $data) {
			$helper = array([
				"ID" => $data["BowserID"],
				"Lat" => $data["latitude"],
				"Long" => $data["longitude"]
				]);
			
			array_push($comparative, $helper);
			
		}
		$closest  = array();
		$currentLowest = 100000000000;
		$currentIDLowest = 0;
		
		foreach($comparative as $comparative_data) {
			$lat = $comparative_data[0]["Lat"];
			$long = $comparative_data[0]["Long"];
			$ID = $comparative_data[0]["ID"];
			
			// convert from degrees to radians
			$earthR = 6371000;
			$latF = deg2rad($lat);
			$lonF = deg2rad($long);
			$latT = deg2rad($compLat);
			$lonT = deg2rad($compLong);

			$latD = $latT - $latF;
			$lonD = $lonT - $lonF;

			$angle = 2 * asin(sqrt(pow(sin($latD / 2), 2) +
								   cos($latF) * cos($latT) * pow(sin($lonD / 2), 2)));
			$totalDifference = $angle * $earthR;
			
					
			if ($totalDifference < $currentLowest) {
				$currentLowest = $totalDifference;
				$currentIDLowest = $ID;
			}
		}
		
		//return the results
		return $currentIDLowest;
	}
}
?>