<?php
/**
Purpose: Controller for the New & Edit bowser page
Authors: Luke & Josh
*/

class BowserEditController extends \BaseController {

	// Get Load in information
	public function index()
	{
        
        
        if(isset($_GET['BowserID'])) {
			$bowserID = $_GET[ 'BowserID' ];
		} else {
            return Redirect::to('/councilhome');
            exit;
		}
        
		//get the authenticated users
        $userID = Auth::user()->id;
        
		//get user information
        $constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
        $constituencyID = $constituencyID[0]["attributes"]["ConstituencyID"];
        
        $constituencyData = TblConstituencyModel::getConstituency($constituencyID);
        $constituencyData = $constituencyData[0]["attributes"];
        
        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
        
		//get the types of tasks for the bowsers
        $bowserTypes = TblBowserTaskID::getBowserTaskTypes();
        $bowserTypesDict = array();        
        foreach($bowserTypes as $bowserType){
            $name = $bowserType["attributes"]["Meaning"];
            $id = $bowserType["attributes"]["ID"];
            $description = $bowserType["attributes"]["Description"];
            $image = $bowserType["attributes"]["image"];
            
            $bowserTypesDict[$id] = array('name'=>$name, 'id'=>$id, 'description'=>$description, 'image' => $image );
        }
        
		//get the urgency of the tasks
        $urgencyTypes = TblUrgencyModel::getUrgencyList();
        $urgencyDict = array();
        foreach($urgencyTypes as $urgencyType){
            $name = $urgencyType["attributes"]["name"];
            $id = $urgencyType["attributes"]["id"];

            $urgencyDict[$id] = array('name'=>$name, 'id'=>$id);
        }

        
        if ($bowserID != 'new'){
            $bowserData = TblBowserInformationModel::getLiveBowsersUnderBowserID($bowserID);
        }
        else{
            $bowserData = 'new';
        }
        
        $maintenanceWorkers = TblUserInformationModel::getUserInformationFromType("M");
        
        
        $maintenanceWorkersDict = array();
        
		//show information about the maintenance staff based on the constituency the user is responsible for
        foreach($maintenanceWorkers as $worker){
            $name = $worker["attributes"]["name"];
            $id = $worker["attributes"]["id"];
            
	        $constID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($id);
	        $constID = $constID[0]["attributes"]["ConstituencyID"];
            
            if( $constituencyID == $constID ) {
            	$maintenanceWorkersDict[$id] = $name;
            }
        }
        
        
        
        
        if (sizeof($bowserData) == 0){ //return to council home if there is no bowser data
            return Redirect::to('/councilhome');
            exit;
        }
        elseif ($bowserData != 'new'){
            $bowserData = $bowserData[0]["attributes"];
        }
        else{
			//create an array for bowser data
            $bowserData = array();
            
            $bowserData['BowserID'] = "N/A";
            $bowserData['bowserAddress'] = "N/A";
            $bowserData['bowserPostcode'] = "";
            $bowserData['bowserStatus'] = -1;
            $bowserData['AdditionalNotes'] = "";
            $bowserData['ConstituencyID'] = $constituencyID;
            $bowserData['latitude'] = $constituencyData['latitude'];
            $bowserData['longitude'] = $constituencyData['longitude'];;
            $bowserData['creation_date'] = date('Y-m-d'); 
            $bowserData['size'] = 0;
                
        }
        
        //get the user profile picture
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
                
                  
        $councilInformation = array("name" => $usersName,
                                    "picture" => $profilePicture,
                                    "bowser_data" => $bowserData,
                                    "maintenance" => $maintenanceWorkersDict,
                                    "constituency" => $constituencyData,
                                    "bowserStatusTypes" => $bowserTypesDict,
                                    "userID" => $userID,
                                    "urgencyTypes" => $urgencyDict
                                   );
                
        //return the view being made
        return View::Make('/pages/councilbowseredit')->with('information', $councilInformation);
	}
    
    
    public function set_additional_notes(){
        
        // Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again'
		);
        
        

        
        if (isset($_POST[ 'additional_notes' ]) && isset($_POST[ 'bowser_id' ])){

            $notes = trim($_POST[ 'additional_notes' ]);
            $bowser_id = (int)$_POST[ 'bowser_id' ];

            TblBowserInformationModel::setBowserIndividual($bowser_id, array('AdditionalNotes' => $notes));
            $result['success'] = true;

        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
        
    }
    
    public function set_data(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);

        if (isset($_POST[ 'id' ]) && isset($_POST[ 'size' ]) && isset($_POST[ 'address' ]) && isset($_POST[ 'lat' ]) && isset($_POST[ 'lon' ]) && isset($_POST['constituency_id'])){
            
            if ($_POST[ 'address' ] != 'N/A' && $_POST[ 'address' ] != ''){
                $id = (int)trim($_POST[ 'id' ]);
                $size = (int)trim($_POST[ 'size' ]);
                $address = trim($_POST[ 'address' ]);
                $lat = floatval(trim($_POST[ 'lat' ]));
                $lon = floatval(trim($_POST[ 'lon' ]));
                $constituencyID = (int)trim($_POST['constituency_id']);
                
                if ($size != 0){
                    
                    if ($id != -1){
                        $result['value'] = TblBowserInformationModel::setBowserIndividual($id, array('bowserAddress' => $address,
                                                                                                     'size' => $size));
                        $result['error'] = 'Bowser Updated';
                    }
                    else{
                        $result['value'] = TblBowserInformationModel::createNewBowser(array(
                                                                                'bowserAddress' => $address,
                                                                                'bowserStatus' => 3,
                                                                                'size' => $size,
                                                                                'latitude' => $lat,
                                                                                'longitude' => $lon,
                                                                                'ConstituencyID' => $constituencyID));
                        
						$result['value2'] = TblMaintenanceTasks::createTask(array("ReportID"=> -1,
											                                    "UserID"=> 0, 
											                                    "ReporterID"=> Auth::user()->id,
											                                    "Urgency"=> 2,
											                                    "TaskTypeID"=> 3,
											                                    "BowserID"=> $result['value']));
						
                        $result['error'] = 'New Bowser Created';
                    }
                    
                    $result['success'] = true;
                    
                }
                else{
                    $result['error'] = 'Bowser Size is to Small';
                }
            }
            else{
                $result['error'] = 'Address Missing';
            }
            
        }
        else{
            $result['error'] = 'No provided';
        }
        
        return Response::json($result);
    }
    
    
    public function set_maintenance(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);
        

        if (isset($_POST[ 'workerID' ]) && isset($_POST[ 'reportRef' ]) && isset($_POST[ 'jobType' ]) && isset($_POST[ 'notes' ]) && isset($_POST[ 'bowserID' ]) && isset($_POST[ 'reporterID' ]) && isset($_POST[ 'urgency' ])){
            
            $workerID = (int)$_POST[ 'workerID' ];
            $reportRef = (int)$_POST[ 'reportRef' ];
            $jobType = (int)$_POST[ 'jobType' ];
            $notes = trim($_POST[ 'notes' ]);
            $bowserID = (int)$_POST[ 'bowserID' ];
            $reporterID = (int)$_POST[ 'reporterID' ];
            $urgency = (int)$_POST[ 'urgency' ];
            
            if ($urgency != -1){
                if ($jobType != -1){
                
                    $values = array("ReportID"=>$reportRef,
                                    "UserID"=>$workerID, 
                                    "ReporterID"=>$reporterID,
                                    "Urgency"=>$urgency,
                                    "additionalNotes"=>$notes,
                                    "TaskTypeID"=>$jobType,
                                    "BowserID"=>$bowserID);

                    $result['value'] = TblMaintenanceTasks::createTask($values);
                    $result['value2'] = TblBowserInformationModel::setBowserIndividual($id, array('bowserStatus' => $jobType));
                    $result['success'] = true;
                }
                else{
                    $result['error'] = 'Please specify Job';
                }
            }
            else{
                $result['error'] = 'Please specify urgency';
            }
        }
        else{
            $result['error'] = 'No provided';
        }
        
        return Response::json($result);
    }
    
    
    
    
    public function getBowserTypesByName(){
        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
		);

        if (isset($_POST[ 'name' ])){
            $result['value'] = TblBowserTaskID::getBowserTypeByName($_POST[ 'name' ]);
            $result['success'] = true;
        }
        else{
            $result['error'] = 'No provided';
        }
        
        return Response::json($result);
    }
    
    
    public function get_all_constituency_bowsers(){

        $result = array(
		   'success' => false,
		   'error' => 'Unknown error: Please try to input information again',
            'value' => 'null'
		);

        if (isset($_POST[ 'constituency_id' ])){
            $constituency_id = trim($_POST[ 'constituency_id' ]);

            $result['value'] = TblBowserInformationModel::getConstituencyBowser($constituency_id);
            $result['success'] = true;
            
        }
        else{
            $result['error'] = 'No ID or Notes provided';
        }
        
        return Response::json($result);
    }


}


?>