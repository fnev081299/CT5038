<?php
/**
Purpose: Controller for the public request page
Authors: Nick
*/

class RequestController extends BaseController {
	
	// create page
	public function index()
	{
		
		return View::Make('/pages/request');
	}
	
	
	// add request to database
	public function submit()
	{
		$drop_down		= isset($_POST[ 'drop_down' ]);
		$description	= isset($_POST[ 'description' ]);
		$emailAdder		= isset($_POST[ 'emailAdder' ]);
		
		// Return if known and message
		$result = array(
		   'success' => false,
		   'error' => 'Unknown error: try again'
		);
		
		// validate inputs - as lat and long
		if(isset($_POST['drop_down'])){
			
			$problem = array('type' => $_POST['drop_down']); 
			echo( $drop_down );
			
			if(isset($_POST['description'])){
				$problem['description'] = $_POST['description'];
			}
			if(isset($_POST['emailAdder'])){
				$problem['email'] = $_POST['emailAdder'];
			}
			if(isset($_POST['lat'])){ // add lat
				$problem['lat'] = $_POST['lat'];
			}
			if(isset($_POST['long'])){ // add long
				$problem['long'] = $_POST['long'];
			}
			
			// update report to database
			if( tblReportInfo::addReport( $problem ) ) {
				$result['success'] = true;
			} else {
				$result['error'] = "Could not submit, reload page";
			}
		}
		
		//return the response
		return Response::json( $result );
	}
}