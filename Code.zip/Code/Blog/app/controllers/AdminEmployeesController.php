<?php
/**
Purpose: Controller for the Admin employee page
Authors: Luke
*/

class AdminEmployeesController extends \BaseController { //class inherits from the baseController containing default functionality

	// Get Load in required data for the page
	public function index()
	{
		//get the authenticated user ID
        $userID = Auth::user()->id;
        
		//get the user information
        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
                
		//get the user profile picture
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
        
		//if there is no group set, allow all access
        if(!isset($_GET['group'])){
            $_GET['group'] = "all";
        }
		//if search is not set, default to empty string
        if(!isset($_GET['search'])){
            $_GET['search'] = "";
        }
            
		// if group is not all, get the user information from the type of user
        if ($_GET['group'] != "all"){
            $council_members = TblUserInformationModel::getUserInformationFromType($_GET['group']);
        }
        else{
            $council_members = TblUserInformationModel::getSearchedUsers($_GET['search'], $userID);
        }

        // Add the users image
        $member_list = array();
        foreach ($council_members as $council_member){
            
			$userConstituency = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
	        $userConstituency = $userConstituency[0]["attributes"]["ConstituencyID"];
            
            // hide admin users
            if( $council_member->user_type != 'A' ) {
	            
				$memberConstituency = TblCouncilMemberInformationModel::getCouncilMemberConstituency($council_member->id);
		        $memberConstituency = $memberConstituency[0]["attributes"]["ConstituencyID"];
		        
	            // hide users from other constituencies
	            if( $userConstituency == $memberConstituency ) {
		            
		            $image = TblUserProfilePictureModel::getProfilePictureLive($council_member["id"]);
		            $council_member["picture"] = $image;
		            
            		$member_list[] = $council_member;
            	}
            }
        }
        
        //array containing the information about a council member        
        $councilInformation = array("name" => $usersName, 
                                    "picture" => $profilePicture,
                                    "employees" => $member_list
                                   );
        
        
		return View::Make('/pages/adminemployees')->with('information', $councilInformation);
	}
    

        
        
    

}



?>