<?php
/**
Purpose: Controller for the council home page
Authors: Luke
*/

class CouncilHomeController extends \BaseController {

	// Get Load in information
	public function index()
	{
        $userID = Auth::user()->id;
        
		$constituencyID = TblCouncilMemberInformationModel::getCouncilMemberConstituency($userID);
        $constituencyID = $constituencyID[0]["attributes"]["ConstituencyID"];

        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
        
        $bowserInformation = TblBowserInformationModel::getBowsersUnderConstituencyID($constituencyID);
        
        $bowserLiveInformation = TblBowserInformationModel::getLiveBowsersUnderConstituencyID($constituencyID);
        		
        $constituencyData = TblConstituencyModel::getConstituency($constituencyID);
        $constituencyData = $constituencyData[0]["attributes"];
        
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
                
        $councilInformation = array("name" => $usersName, 
                                    "constituencyData" => $constituencyData,
                                    "bowserData" => $bowserInformation,
                                    "bowserLiveData" => $bowserLiveInformation,
                                    "picture" => $profilePicture
                                   );
        
        //$constituencyID = $councilInformation[0]["attributes"]["ConstituencyID"];
        
        
		return View::Make('/pages/councilhome')->with('information', $councilInformation);
	}


}


?>