<?php
/**
Purpose: Controller for the admin constituencies page
Authors: Luke
*/

class AdminConstituenciesController extends \BaseController {

	// Get Load in information
	public function index()
	{
        $userID = Auth::user()->id;
        
        $constituencies = TblConstituencyModel::getAll();
        
        foreach ($constituencies as $constituency){
            $bowserInformation = TblBowserInformationModel::getBowsersUnderConstituencyID($constituency["ConstituencyID"]);
            $constituency["bowserData"] = $bowserInformation;
        }
        
        $usersName = TblUserInformationModel::getUserInformaiton($userID);
        $usersName = $usersName[0]["attributes"]["name"];
                
        $profilePicture = TblUserProfilePictureModel::getProfilePicture($userID);
        $profilePicture = $profilePicture[0]["attributes"]["picture_location"];
        
                
        $councilInformation = array("name" => $usersName, 
                                    "picture" => $profilePicture,
                                    "constituencies" => $constituencies
                                   );
        
        //$constituencyID = $councilInformation[0]["attributes"]["ConstituencyID"];
        
        
		return View::Make('/pages/adminconstituencies')->with('information', $councilInformation);
	}    
    
}























?>