/*
############################
 Purpose: bowsers near me 
############################
*/

let rowIndex = 1;
const bowsersTable = document.getElementById("bowsersTable");


// Update bowsers
function update() {
	
	// update bowser list //
	if(typeof userLocation !== 'undefined') {
		var formData = {
			'lat': userLocation.lat,
			'lng': userLocation.lng
		};
	} else {
		var formData = {
		};
	}
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to controller
	$.ajax({
		type        : 'POST',
		url         : 'bowserNearMe_update',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		
		// Was data received?
		if(data.success) {
			
			// update bowsers list
			rowIndex = 1;
			data.bowserList.forEach(updateRow);
			
			circlesA.forEach(cirle => cirle.setMap(null));
			circlesB.forEach(cirle => cirle.setMap(null));
			circlesA = [];
			circlesB = [];
			markersA.forEach(marker => marker.setMap(null));
			markersB.forEach(marker => marker.setMap(null));
			markersA = [];
			markersB = [];
			
			data.bowsers.forEach(updateMap);
			
			// remove excess rows
			while( bowsersTable.rows[rowIndex] !== undefined ) {
				bowsersTable.deleteRow(rowIndex);
			}
		} else {
			failAlert(data.error);
		}
	});
}
setTimeout(update, 3000); // load bowsers after page load
setInterval(update, 30000); // Update list of bowsers every 30s



// update row in table
function updateRow(row) {
	
	// clear row if exists / add row if it does not exist
	if( bowsersTable.rows[rowIndex] === undefined ) {
		bowsersTable.insertRow(rowIndex);
	} else {
		bowsersTable.rows[rowIndex].classList.remove('bowserRow');
	}
	
	// tag and style row
	let bowserRow = bowsersTable.rows[rowIndex];
	bowserRow.classList.add("bowserRow");
	bowserRow.setAttribute("id", "bowser" + row.bowserID);
	bowserRow.setAttribute('data-bowserID', row.bowserID);
	bowserRow.setAttribute('data-distance', row.distance);
	bowserRow.setAttribute('data-size', row.size);
	bowserRow.setAttribute('data-address', row.address);
	
	// style based on if assigned to user
	if( row.inactive ) {
		bowserRow.classList.add("inactive");
	}
	
	var addressParts = row.address.split(', ');
	var postcodeParts = addressParts[addressParts.length - 2].split(' ');
	
	// set row contents
	bowserRow.innerHTML = 
		'<td width="15%">'+
            '<p>' + row.distance + '</p>'+
        '</td>'+
        '<td width="15%">'+
            '<p>' + row.size + '</p>'+
        '</td>'+
        '<td width="55%">'+
            '<p>' + addressParts[0] + ', ' + postcodeParts[1] + ' ' + postcodeParts[2] + '</p>'+
        '</td>'+
        '<td width="15%" class="details" onclick="details(' + row.bowserID + ')">'+
			'<p>Details</p>'+
		'</td>';
	
	rowIndex ++;
	
}


// Update bowsers on map
function updateMap(bowser) {
	
	
    bowserlng		= bowser.longitude;
    bowserlat		= bowser.latitude;
    bowserID		= bowser.BowserID;
    bowserStatus	= bowser.bowserStatus;
    bowserAddress	= bowser.bowserAddress;
    bowserRadius	= bowser.size;
    
    var myLatlng = new google.maps.LatLng(bowserlat, bowserlng);
	
	var url = "";
	if(bowserStatus == 0) {
	    url = "Resources/Images/waterMap.png";
	} else if (bowserStatus == 1) {
	    url = "Resources/Images/tools.png";
	} else if (bowserStatus == 2) {
	    url = "Resources/Images/waterMap.gif";
	} else if (bowserStatus == 3) {
	    url = "Resources/Images/waterMapDeploy.png";
	}
	
    var icon = {
        url: url,
        scaledSize: new google.maps.Size(50, 50), // scaled size
    };
	
	// add circle and marker to mapA
    var markerA = new google.maps.Marker({
        position: myLatlng,
        title: "Bowser ID: " + bowserID + " - " + bowserAddress,
        map: mapA,
        icon: icon
    });
	markersA[bowserID] = markerA;
	
    var circleA = new google.maps.Circle({
		map: mapA,
		radius: bowser.size/10,    // 10k Liter = 1km
		fillColor: '#AA0000',
        strokeColor: '#6600AA',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#6600AA',
        fillOpacity: 0.35,
    });
    circleA.bindTo('center', markerA, 'position');
	circlesA[bowserID] = circleA;
	
	
	
	// add circle and marker to mapA
    var markerB = new google.maps.Marker({
        position: myLatlng,
        title: "Bowser ID: " + bowserID + " - " + bowserAddress,
        map: mapB,
        icon: icon
    });
	markersB[bowserID] = markerB;
	
    var circleB = new google.maps.Circle({
		map: mapB,
		radius: bowser.size/10,    // 10k Liter = 1km
		fillColor: '#AA0000',
        strokeColor: '#6600AA',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#6600AA',
        fillOpacity: 0.35,
    });
    circleB.bindTo('center', markerB, 'position');
	circlesB[bowserID] = circleB;
	
	
    // Bind to marker
    google.maps.event.addListener(markerA, 'click', function() {
        $(".mainContentsSwipeTable").css("left", "-100%");
        $(".mapBackground").css("opacity", "0");
        $(".mapBackground").css("pointer-events", "none");
        $(".statsDiv").css("opacity", "1");
        $(".statsDiv").css("pointer-events", "auto")
        $(".bowserStatsButton p").addClass("focusedTabButton")
        $(".mapCoverageButton p").removeClass("focusedTabButton");
        
        details(bowserID);
    });
    
    google.maps.event.addListener(markerB, 'click', function() {
        $(".mainContentsSwipeTable").css("left", "-100%");
        $(".mapBackground").css("opacity", "0");
        $(".mapBackground").css("pointer-events", "none");
        $(".statsDiv").css("opacity", "1");
        $(".statsDiv").css("pointer-events", "auto")
        $(".bowserStatsButton p").addClass("focusedTabButton")
        $(".mapCoverageButton p").removeClass("focusedTabButton");
    });
}


// Display bowser details
function details(bowserID) {
    
    // update info
	bowserRow = document.getElementById("bowser" + bowserID);
	
	document.getElementById("bowser-distance").innerHTML	= bowserRow.getAttribute('data-distance');
	document.getElementById("bowser-size").innerHTML		= bowserRow.getAttribute('data-size');
	document.getElementById("bowser-address").innerHTML		= bowserRow.getAttribute('data-address').replace(/, /g, "</br>");
	
	
	// update map
	mapB.panTo( markersB[ bowserID ].getPosition() );
	
    markersB.forEach(marker => marker.setVisible(false));
    markersB[ bowserID ].setVisible(true);
    
    circlesB.forEach(circle => circle.setOptions({fillOpacity:0, strokeOpacity:0}));
    circlesB[ bowserID ].setOptions({fillOpacity:0.35, strokeOpacity:0.8});
    
    
	// move to details pane
	$(".mainContentsSwipeTable").css("left", "-100%");
}

