
/*
######################################################################
 Author : Josh
 Description : JS for password reset page
######################################################################
*/




// Show user if the password is complex enough
function checkComplexity() {
	var strength = {
		0: "Worst",
		1: "Bad",
		2: "Weak",
		3: "Good",
		4: "Strong"
	};
	var strengthMeter = document.getElementById('password-strength-meter');
	var strengthText = document.getElementById('password-strength-text');
	var textout = "";
	var password = $('input[name=Password]').val();
	
	
	
	
	// Check password complexity //
	// Update the password strength meter
	var result = zxcvbn(password);
	strengthMeter.value = result.score;
	
	// Update the text indicator
	if (password !== "") {
		strengthText.innerHTML = "Strength: " + strength[result.score]; 
	} else {
		strengthText.innerHTML = "Strength: Worst";
	}
	
	
	
	
	// Check that password has atleast 10 characters //
	if(password.length < 10) {
		textout = textout + "Password is not 10 characters or longer" + "<br/><br/>";
	}
	
	
	
	
	// Check if the password is a known hacked password //
	var formData = {
		'password': password
	};
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to controller
	$.ajax({
		type        : 'POST',
		url         : 'reset_strength',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		
		// Tell user how known that password is
		textout = textout + data.message + "<br/>";
		
		$("#textout-password").html(textout);
	});
}



// Update password
function updatePassword() {
	
	// Check if the password is a known hacked password //
	var formData = {
		'password': $('input[name=Password]').val(),
		'confirm': $('input[name=ConfirmPassword]').val(),
		'complexity': zxcvbn( $('input[name=Password]').val() ).score,
		'token': $('input[name=Token]').val()
	};
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to controller
	$.ajax({
		type        : 'POST',
		url         : 'reset_submit',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		
		// Is it a known hacked password?
		if(data.success) {
			// alert user that account has been made and return to homepage
			alert( "Password updated" );
			window.location.href = "/login";
		} else {
			alert(data.error);
		}
	});
}
