// check login
function login() {
	
	// Attempt to login //
	var formData = {
		'email': $('input[name=email]').val(),
		'password': $('input[name=password]').val()
	};
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to class.functions.php
	$.ajax({
		type        : 'POST',
		url         : 'login_submit',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		
		// were the login credencials correct
		if(data.success) {
			if(data.type == "council") {
				// council login
				window.location.href = "/councilhome";
			} else {
				// maintenance login
				window.location.href = "/councilhome";
			}
		} else {
			alert(data.error);
		}
	});
}