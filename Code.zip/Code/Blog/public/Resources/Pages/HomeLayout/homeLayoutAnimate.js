/*eslint-env browser*/

/*
######################################################################
 Author : Luke Gassmann
 Description : This page gives the default page animations for users
 			   (none-council members)
######################################################################
*/

function main(){
    
	// Have burger menu pop in and out when elipsis is clicked
    var burgerMenuOnScreen = false;
    $(document).on('click', '#elipsis', function(){
        
		// Move on screen
        if (!burgerMenuOnScreen){
            $(".burgerMenu").css("left", "0");
            burgerMenuOnScreen = true;
        }
		
		// Move off screen
        else{
            $(".burgerMenu").css("left", "-80%");
            burgerMenuOnScreen = false;
        }
    })
    
}



















