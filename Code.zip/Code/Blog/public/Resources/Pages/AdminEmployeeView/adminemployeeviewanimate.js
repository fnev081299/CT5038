/*eslint-env browser*/


/*
########################################################
# Author: Luke Gassmann
# Purpose: This is the Javascript page for the page
########################################################
*/
function main(user_account_number){
    
    // Reset a users password
    $("#resetPasswordAccount").click(function(){
	    
	    var formData = {
            'id': user_account_number
        };
	
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
        
        $.ajax({
            type        : 'POST',
            url         : 'reset_user',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {
            
            if(data.success) {
                
                successAlert(data['error']);
                
            } else {
                failAlert(data['error'])
            }
        });
    });
    
    
    
    // Remove a users account
    $("#deleteAccount").click(function(){
        
        var formData = {
            'id': user_account_number
        };
	
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
        
        $.ajax({
            type        : 'POST',
            url         : 'delete_user',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {
            
            if(data.success) {
                
                successAlert(data['error']);
                window.location.href = "/adminEmployees";
                
            } else {
                failAlert(data['error'])
            }
        });
    });
}


function mainCreate(user_type){



	// Remove a users account
	$(document).on('click', '#createAccount', function(){
	    
	    if( $('#constituency').attr( "statusvalue" ) != "" ) {
	    
	        var formData = {
	            'name': $('#name').val(),
	            'email': $('#email').val(),
	            'type': user_type,
	            'constituency': $('#constituency').attr( "statusvalue" )
	        };
	        
	        
		
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				}
			});
	        
	        $.ajax({
	            type        : 'POST',
	            url         : 'create_user',
	            data        : formData,
	            dataType    : 'json'
	
	        }).done(function(data) {
	            
	            if(data.success) {
	                
	                successAlert(data['error']);
	                window.location.href = data['redirect'];
	                
	            } else {
	                failAlert(data['error'])
	            }
	        });
	        
	    } else {
	        
	        alert("Constituency input required");
	        
	    }
	});
    
}
















