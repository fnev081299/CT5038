/*eslint-env browser*/


/*
########################################################
# Author: Luke Gassmann
# Purpose: This is the Javascript page for the council 
#          home page
########################################################

*/


function main(){
    
    // Animate
    $(".mapCoverageButton p").addClass("focusedTabButton")
    
    // Move in and out of screen when necessary
    $(".bowserStatsButton").click(function(){
        if (!$(".bowserStatsButton p").hasClass("focusedTabButton")){
            $(".mainContentsSwipeTable").css("left", "-100%");
            $(".mapBackground").css("opacity", "0");
            $(".mapBackground").css("pointer-events", "none");
            $(".statsDiv").css("opacity", "1");
            $(".statsDiv").css("pointer-events", "auto")
            $(".bowserStatsButton p").addClass("focusedTabButton")
            $(".mapCoverageButton p").removeClass("focusedTabButton");
        }
    })
    
    $(".mapCoverageButton").click(function(){
        if (!$(".mapCoverageButton p").hasClass("focusedTabButton")){
            $(".mainContentsSwipeTable").css("left", "0");
            $(".mapBackground").css("opacity", "1");
            $(".mapBackground").css("pointer-events", "auto");
            $(".statsDiv").css("opacity", "0");
            $(".statsDiv").css("pointer-events", "none")
            $(".mapCoverageButton p").addClass("focusedTabButton")
            $(".bowserStatsButton p").removeClass("focusedTabButton");
        }
    })
}



















