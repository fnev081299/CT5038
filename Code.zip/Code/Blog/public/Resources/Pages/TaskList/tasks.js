
/*
######################################################################
 Author : Joe & Josh
 Description : JS for the task list page
######################################################################
*/


// Show current date and time
function getTime() {
	var Now = new Date(); //get the current time
	var Hours = String(Now.getHours() < 10 ? '0' : '') + String(Now.getHours()); //get hours and force to 2 digits
	var Minutes = String(Now.getMinutes() < 10 ? '0' : '') + String(Now.getMinutes()); //force minutes to 2 digits
	var Day = Now.getDate();
	var Year = Now.getFullYear();
	
	var Month = new Array(); //array of month names
	Month[0] = "January";
	Month[1] = "February";
	Month[2] = "March";
	Month[3] = "April";
	Month[4] = "May";
	Month[5] = "June";
	Month[6] = "July";
	Month[7] = "August";
	Month[8] = "September";
	Month[9] = "October";
	Month[10] = "November";
	Month[11] = "December";
	var fullMonth = Month[Now.getMonth()]; //gets index of month from array to get full month name
	
	document.getElementById('timeA').textContent= Hours + ":" + Minutes; //update the span by time id
	document.getElementById('timeB').textContent= Hours + ":" + Minutes; //update the span by time id
	
	document.getElementById('dateA').textContent= Day + " " + fullMonth + " " + Year; //update span by date id 
	document.getElementById('dateB').textContent= Day + " " + fullMonth + " " + Year; //update span by date id 
	
}
getTime(); // call function on page load to prevent space being empty for 1000ms
setInterval(getTime, 1000); // Call function every second to update the time and date



let rowIndex = 1;
const tasksTable = document.getElementById("tasksTable");


// Update Tasks
function update() {
	
	// update task list //
	if(typeof userLocation !== 'undefined') {
		var formData = {
			'lat': userLocation.lat,
			'lng': userLocation.lng
		};
	} else {
		var formData = {
		};
	}
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to controller
	$.ajax({
		type        : 'POST',
		url         : 'taskList_update',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		
		// Was data received?
		if(data.success) {
			
			// update tasks list
			rowIndex = 1;
			data.tasks.forEach(updateRow);
			
			circlesA.forEach(cirle => cirle.setMap(null));
			circlesB.forEach(cirle => cirle.setMap(null));
			circlesA = [];
			circlesB = [];
			markersA.forEach(marker => marker.setMap(null));
			markersB.forEach(marker => marker.setMap(null));
			markersA = [];
			markersB = [];
			
			data.bowsers.forEach(updateMap);
			
			// remove excess rows
			while( tasksTable.rows[rowIndex] !== undefined ) {
				tasksTable.deleteRow(rowIndex);
			}
		} else {
			failAlert(data.error);
		}
	});
}
setTimeout(update, 3000); // load tasks after page load
setInterval(update, 30000); // Update list of tasks every 30s



// update row in table
function updateRow(row) {
	
	// clear row if exists / add row if it does not exist
	if( tasksTable.rows[rowIndex] === undefined ) {
		tasksTable.insertRow(rowIndex);
	} else {
		tasksTable.rows[rowIndex].classList.remove('taskRow');
		tasksTable.rows[rowIndex].classList.remove('myTask');
	}
	
	// tag and style row
	let taskRow = tasksTable.rows[rowIndex];
	taskRow.classList.add("taskRow");
	taskRow.setAttribute("id", "task" + row.taskID);
	taskRow.setAttribute('data-taskID', row.taskID);
	taskRow.setAttribute('data-bowserID', row.bowserID);
	taskRow.setAttribute('data-priority', row.priority);
	taskRow.setAttribute('data-distance', row.distance);
	taskRow.setAttribute('data-size', row.size);
	taskRow.setAttribute('data-action', row.action);
	taskRow.setAttribute('data-problem', row.problem);
	taskRow.setAttribute('data-details', row.details);
	taskRow.setAttribute('data-myTask', row.myTask);
	taskRow.setAttribute('data-council', row.council);
	taskRow.setAttribute('data-userID', row.userID);
	taskRow.setAttribute('data-reporterID', row.reporterID);
	
	// style based on if assigned to user
	if( row.myTask ) {
		taskRow.classList.add("myTask");
	}
	
	// set row contents
	taskRow.innerHTML = 
		'<td width="15%">'+
            '<p>' + row.priority + '</p>'+
        '</td>'+
		'<td width="15%">'+
            '<p>' + row.distance + '</p>'+
        '</td>'+
        '<td width="15%">'+
            '<p>' + row.size + '</p>'+
        '</td>'+
        '<td width="40%">'+
            '<p>' + row.action + '</p>'+
        '</td>'+
        '<td width="15%" class="details" onclick="details(' + row.taskID + ')">'+
			'<p>Details</p>'+
		'</td>';
	
	rowIndex ++;
	
}


// Update bowsers on map
function updateMap(bowser) {
    
    taskID = bowser.taskID;
    
    bowserlng		= bowser.longitude;
    bowserlat		= bowser.latitude;
    bowserID		= bowser.BowserID;
    bowserStatus	= bowser.bowserStatus;
    bowserAddress	= bowser.bowserAddress;
    bowserRadius	= bowser.size;
    
    var myLatlng = new google.maps.LatLng(bowserlat, bowserlng);
	
	var url = "";
	if (bowserStatus == 1 || bowserStatus == 4 || bowserStatus == 5) {
	    url = "Resources/Images/tools.png";
	} else if (bowserStatus == 2) {
	    url = "Resources/Images/waterMap.gif";
	} else if (bowserStatus == 3) {
	    url = "Resources/Images/waterMapDeploy.png";
	} else {
	    url = "Resources/Images/waterMap.png";
	}
	
    var icon = {
        url: url,
        scaledSize: new google.maps.Size(50, 50), // scaled size
    };
	
	// add circle and marker to mapA
    var markerA = new google.maps.Marker({
        position: myLatlng,
        title: "Bowser ID: " + bowserID + " - " + bowserAddress,
        map: mapA,
        icon: icon
    });
	markersA[bowserID] = markerA;
	
    var circleA = new google.maps.Circle({
		map: mapA,
		radius: bowser.size/10,    // 10k Liter = 1km
		fillColor: '#AA0000',
        strokeColor: '#6600AA',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#6600AA',
        fillOpacity: 0.35,
    });
    circleA.bindTo('center', markerA, 'position');
	circlesA[bowserID] = circleA;
	
	
	
	// add circle and marker to mapA
    var markerB = new google.maps.Marker({
        position: myLatlng,
        title: "Bowser ID: " + bowserID + " - " + bowserAddress,
        map: mapB,
        icon: icon
    });
	markersB[bowserID] = markerB;
	
    var circleB = new google.maps.Circle({
		map: mapB,
		radius: bowser.size/10,    // 10k Liter = 1km
		fillColor: '#AA0000',
        strokeColor: '#6600AA',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#6600AA',
        fillOpacity: 0.35,
    });
    circleB.bindTo('center', markerB, 'position');
	circlesB[bowserID] = circleB;
	
	
    // Bind to marker
    google.maps.event.addListener(markerA, 'click', function() {
        $(".mainContentsSwipeTable").css("left", "-100%");
        $(".mapBackground").css("opacity", "0");
        $(".mapBackground").css("pointer-events", "none");
        $(".statsDiv").css("opacity", "1");
        $(".statsDiv").css("pointer-events", "auto")
        $(".bowserStatsButton p").addClass("focusedTabButton")
        $(".mapCoverageButton p").removeClass("focusedTabButton");
        
        details(taskID);
    });
}


// Display task details
function details(taskID) {
    
    // update info
	taskRow = document.getElementById("task" + taskID);
	bowserID = taskRow.getAttribute('data-bowserID');
	
	document.getElementById("task-id").innerHTML		= taskRow.getAttribute('data-taskID');
	document.getElementById("bowser-id").innerHTML		= bowserID;
	document.getElementById("task-priority").innerHTML	= taskRow.getAttribute('data-priority');
	document.getElementById("task-distance").innerHTML	= taskRow.getAttribute('data-distance');
	document.getElementById("task-size").innerHTML		= taskRow.getAttribute('data-size');
	document.getElementById("task-action").innerHTML	= taskRow.getAttribute('data-action');
	document.getElementById("task-problem").innerHTML	= taskRow.getAttribute('data-problem');
	document.getElementById("task-details").innerHTML	= taskRow.getAttribute('data-details');
	
	
	
	if( taskRow.getAttribute('data-council') == "true" ) {
		// if council user
		
		if( taskRow.getAttribute('data-myTask') == "true" ) {
			// if task is owned a user
			document.getElementById("contactBtn").classList.remove('hidden');
			document.getElementById("contactBtn").onclick = function() { location.href='/messageDesktop?friend='+taskRow.getAttribute('data-userID'); };
			
		} else {
			// if task is not owned a user
			document.getElementById("contactBtn").classList.add('hidden');
		}
	
	} else {
		// if maintenance user
		
		document.getElementById("contactBtn").onclick = function() { location.href='/messageDesktop?friend='+taskRow.getAttribute('data-reporterID'); };
		
		if( taskRow.getAttribute('data-myTask') == "true" ) {
			// if task is owned by user
			document.getElementById("aquireTask").classList.add('hidden');
			
			document.getElementById("finishTask").classList.remove('hidden');
			document.getElementById("unassignTask").classList.remove('hidden');
			
		} else {
			// if task is not owned by current user
			document.getElementById("aquireTask").classList.remove('hidden');
			
			document.getElementById("finishTask").classList.add('hidden');
			document.getElementById("unassignTask").classList.add('hidden');
		}
	}
	
	
	// update map
	mapB.panTo( markersB[ bowserID ].getPosition() );
	
    markersB.forEach(marker => marker.setVisible(false));
    markersB[ bowserID ].setVisible(true);
    
    circlesB.forEach(circle => circle.setOptions({fillOpacity:0, strokeOpacity:0}));
    circlesB[ bowserID ].setOptions({fillOpacity:0.35, strokeOpacity:0.8});
    
    
	// move to details pane
	$(".mainContentsSwipeTable").css("left", "-100%");
}


// Aquire task
function aquireTask() {
	
	taskID = Number( document.getElementById("task-id").innerHTML );
	
	if(taskID != "N/A") {
	
		// Assign task to user //
		var formData = {
			'id': taskID
		};
		
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		
		// Send formData to controller
		$.ajax({
			type        : 'POST',
			url         : 'taskList_assign',
			data        : formData,
			dataType    : 'json',
			encode      : true
		}).done(function(data) {
			
			// Was assigning the task successful?
			if(data.success) {
				// alert user that account has been made and return to homepage
				successAlert( "Task Assigned" );
				update();
	            $(".mainContentsSwipeTable").css("left", "0");
			} else {
				failAlert(data.error);
				update();
			}
		});
	}
}


// Return task to unassigned
function unassignTask() {
	
	taskID = Number( document.getElementById("task-id").innerHTML );
	
	if(taskID != "N/A") {
	
		// Assign task to user //
		var formData = {
			'id': taskID
		};
		
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		
		// Send formData to controller
		$.ajax({
			type        : 'POST',
			url         : 'taskList_unassign',
			data        : formData,
			dataType    : 'json',
			encode      : true
		}).done(function(data) {
			
			// Was assigning the task successful?
			if(data.success) {
				// alert user that account has been made and return to homepage
				successAlert( "Task Un-Assigned" );
				update();
	            $(".mainContentsSwipeTable").css("left", "0");
			} else {
				failAlert(data.error);
				update();
			}
		});
	}
}


// Finish task
function finishTask() {
	
	taskID = Number( document.getElementById("task-id").innerHTML );
	
	if(taskID != "N/A") {
	
		// Assign task to user //
		var formData = {
			'id': taskID
		};
		
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		
		// Send formData to controller
		$.ajax({
			type        : 'POST',
			url         : 'taskList_finish',
			data        : formData,
			dataType    : 'json',
			encode      : true
		}).done(function(data) {
			
			// Was assigning the task successful?
			if(data.success) {
				// alert user that account has been made and return to homepage
				successAlert( "Task Closed" );
				update();
	            $(".mainContentsSwipeTable").css("left", "0");
			} else {
				failAlert(data.error);
				update();
			}
		});
	}
}

