/*eslint-env browser*/


/*
######################################################################
 Author : Luke Gassmann altered by Nicolas Euliarte 
 Description : This page allows for JS animations and interactions
######################################################################
*/

// run on page load
function main(){
	
		// Send the user to the Log In Page once clicked
    $(document).on('click', '.logInButton', function(){
        window.location = "/login";
    })
    
	setTimeout(hideTag, 2000); // remove tag after load
}

// load map
function mainMap(){
		// Select the Map Div and focus on this location
   var map = new google.maps.Map(document.getElementById('map'), {
       	center: {lat: 51.8994, lng: -2.0783},
       	zoom: 11,
        disableDefaultUI: true,
       	mapTypeId: google.maps.MapTypeId.ROADMAP
   });
}


function hideTag() {
	$("#eapps-twitter-feed-1 > a").css('display', 'none');
}














