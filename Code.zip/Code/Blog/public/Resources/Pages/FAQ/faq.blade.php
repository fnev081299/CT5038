
@section('pageJS')
        <script src="Resources/Pages/FAQ/faqAnimate.js"></script>
        <script type="text/javascript"> window.onload = main();</script>
@stop

@section('pageCSS')
        <link rel="stylesheet" type="text/css" href="Resources/Pages/FAQ/faqStyles.css"/>
@stop

@section('title')
    FAQ
@stop

@section('pageCSS')
        
@stop

@section('upperBackground')
@stop
                    
@section('upperContents')

@stop

@section('mainContents')
<p>Hello</p>
@stop



@include('layouts.homeLayout')















