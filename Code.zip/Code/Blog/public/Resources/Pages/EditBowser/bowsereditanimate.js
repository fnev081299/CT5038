/*eslint-env browser*/

/*
########################################################
# Author: Luke Gassmann
# Purpose: This is the Javascript page for the page
########################################################
*/

function main(bowserID, constituency_id, userID){
        
    // Save button
    $("#bowserInformationSave").click(function(){
        
        // Bowser Data
        $bowser_size = $(".bowserSizeInput input").val();
        $bowser_address = $(".bowserAddressEdit").text();
        $bowser_lat = parseFloat( $(".bowserLatSub").text() );
        $bowser_lon = parseFloat( $(".bowserLongSub").text() );
        
        
        // Convert to form
        var formData = {
            'id': bowserID,
            'size': $bowser_size,
            'address': $bowser_address,
            'lat': $bowser_lat,
            'lon': $bowser_lon,
            'constituency_id': constituency_id
        };
        
        console.log(formData);
        
        // Send to database
        $.ajax({
            type        : 'POST',
            url         : 'be_data',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {
            
            console.log(data)
            if(data.success) {
                
                if (bowserID == -1){
                    $("#bowserInformationSave").css("pointer-events", "none");
                }
                
                successAlert(data['error']);
                
                if (bowserID == -1){
                    setTimeout(function(){
                        window.location.href = "councilhome";
                    }, 2000)
                }
                
                
            } else {
                failAlert(data['error'])
            }
        });
        
    })
    
    // Save notes
    $("#additionalNotesButton").click(function(){
        notes = $(".notesSectionText").html();
        
        var formData = {
            'additional_notes': notes,
            'bowser_id': bowserID
        };
        
        console.log(formData);
        
        $.ajax({
            type        : 'POST',
            url         : 'be_addition_notes',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {
            
            console.log(data)
            if(data.success) {
                successAlert("Additional Notes Updated");
            } else {
                console.log(data)
            }
        });
        
    })
    
    // Submit to maintenance
    $("#maintenanceSubmission").click(function(){
        if (bowserID != -1){
            workerID = $("#maintenanceWorkerChosenID").val();
            reportRef = $("#reportRefNumber input").val();
            urgency = $(".urgencyButtonStatus").attr("urgencytype");
            
            if (reportRef == "N/A"){
                reportRef = -1;
            }
            
            jobType = $(".jobButtonStatus").attr("jobType");
            notes = $(".maintenanceNotesEdit").text();

            var formData = {
                'workerID': workerID,
                'reportRef': reportRef,
                'jobType':jobType,
                'notes': notes,
                'bowserID': bowserID,
                'reporterID': userID,
                'urgency': urgency
            };

            console.log(formData);

            $.ajax({
                type        : 'POST',
                url         : 'be_maintenance',
                data        : formData,
                dataType    : 'json'

            }).done(function(data) {

                console.log(data)
                
                if(data.success) {
                    $("#maintenanceSubmission").css("pointer-events", "none");
                    
                    successAlert("Maintenance Request Sent");
                    
                    setTimeout(function(){
                        window.location.href = "councilhome";
                    }, 2000)
                } else {
                    failAlert(data['error'])
                }
            });
        }
        else{
            failAlert("Finish creating Bowser")
        }
        
    })
    
    // Number spinner
    $(document).on('click', '.number-spinner button', function () {    
        var btn = $(this),
            oldValue = btn.closest('.number-spinner').find('input').val().trim(),
            newVal = 0;

        if (btn.attr('data-dir') == 'up') {
            if (oldValue == 'N/A'){
                newVal = 0;
            }
            else{
                newVal = parseInt(oldValue) + 1;
            }
        } else {
            if (oldValue > 1) {
                if (oldValue != 'N/A'){
                    newVal = parseInt(oldValue) - 1;
                }
            } else {
                newVal = 1;
            }
        }
        btn.closest('.number-spinner').find('input').val(newVal);
    });
    
    
    
    
}



















