/*eslint-env browser*/

/*
########################################################
# Author: Luke Gassmann
# Purpose: This is the Javascript page for the page
########################################################
*/

function main(){
    
    // Council Search
    $("#reviewGroupImage1").click(function(){
        var path = window.location.href;
        
        path = path.split("?")[0] + "?group=C"
        
        window.location.href = path;
    })
    
    // Maintenance Search
    $("#reviewGroupImage2").click(function(){
        var path = window.location.href;
        
        path = path.split("?")[0] + "?group=M"
        
        window.location.href = path;
    })
    
    // Email Search
    $("#searchUsersButton").click(function(){
        var path = window.location.href;
        
        path = path.split("?")[0] + "?group=all&search=" + $(".searchBar input").val()
        
        window.location.href = path;
    })
    
    // Create Users
    $(".userViewButton").click(function(){
        $account_number = $(this).attr("employeenumber");
        
        window.location.href = "/adminEmployeeView?user_account=" + $account_number;
    })
    
    $(".createButton").click(function(){
        $create_type = $(this).attr("create_type");
        
        window.location.href = "/adminEmployeeView?type=" + $create_type;
    })
}



















