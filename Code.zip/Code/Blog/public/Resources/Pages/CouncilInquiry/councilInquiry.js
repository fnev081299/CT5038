/*
############################
 Author: Nicolas Euliarte and Josh Walker
 Purpose: inquiry details and emails
############################
*/

// show subset of inquiries to user
function showDetails(type) {
	
	if(type != 'All') {
		// hide all rows
		$(".rowOf").addClass("hidden");
		
		// show type
		$("."+type).removeClass("hidden");
		
	} else {
		// show all rows
		$(".rowOf").removeClass("hidden");
	}
	
	
	// move to reports pane
	$(".mainContentsSwipeTable").css("left", "-100%");
}


// show form to create email
function createEmail(reportID, description) {
	// show form to send email
	$('#emailForm').removeClass('hidden');
	document.getElementById("emailForm").scrollIntoView();
	
	// show inquery text in email
	$('#emailText').html(description);
	$('#emailReportID').val(reportID);
}


// send email using form
function sendEmail() {
	
	// send email
	message = document.getElementById("emailMessage").value;
	reportID = $('#emailReportID').val();
	
	if( message != "" && reportID != "" ) {
	
		// Send Reply Email //
		var formData = {
			'message': message,
			'reportID': reportID
		};
		
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		
		// Send formData to controller
		$.ajax({
			type        : 'POST',
			url         : 'Inquiries_send',
			data        : formData,
			dataType    : 'json',
			encode      : true
		}).done(function(data) {
			
			// Was sending the email successful?
			if(data.success) {
				successAlert( "Email Sent" );
				$('#emailForm').addClass('hidden');
			} else {
				failAlert(data.error);
			}
		});
	} else {
		failAlert("Message empty or reportID missing");
	}
}


// create task based on inqueries
function createTask(bowserID, type) {
	
	if( bowserID != "" && type != "" ) {
	
		// Create Task //
		var formData = {
			'bowserID': bowserID,
			'type': type
		};
		
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
			}
		});
		
		// Send formData to controller
		$.ajax({
			type        : 'POST',
			url         : 'Inquiries_create',
			data        : formData,
			dataType    : 'json',
			encode      : true
		}).done(function(data) {
			
			// Was creating the task successful?
			if(data.success) {
				successAlert( "Task Created" );
			} else {
				failAlert(data.error);
			}
		});
	} else {
		failAlert("BowserID or type missing");
	}
}


// close all inqueries for bowser and type combination
function closeInquiries(bowserID, sendID, type, quantity) {
	// close all inqueries of this type
	if( confirm("This will delete the "+quantity+" "+type+" reports for BowserID: "+bowserID) ) {
		
		if( sendID != "" && type != "" ) {
		
			// Delete Inquiries //
			var formData = {
				'sendID': sendID,
				'type': type
			};
			
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				}
			});
			
			// Send formData to controller
			$.ajax({
				type        : 'POST',
				url         : 'Inquiries_delete',
				data        : formData,
				dataType    : 'json',
				encode      : true
			}).done(function(data) {
				
				// Was deleting the inquiries successful?
				if(data.success) {
					successAlert( "Inquiries Closed" );
					location.reload();
				} else {
					failAlert(data.error);
				}
			});
		} else {
			failAlert("BowserID or type missing");
		}
	}
}







