/*eslint-env browser*/

/*
###########################################################
Author: Luke Gassmann
Purpose: This page is the Javascript for messaging
###########################################################
*/



// Global Variables
$previous_messages = null;
$search_messages = null;



/*
###########################################################
Purpose: In the event that no users are found
###########################################################
*/
function noUsersFound(){
    overall_html = "<img class='searchUsers' src='Resources/Images/searchUsers.png'>";
    $(".accountSearchTD").html(overall_html);
}


/*
###########################################################
Purpose: Connect to users to enable messaging between them
###########################################################
*/
function connect_users(friend, council){
    console.log("Connecting Users")
    console.log(friend)
    
    // Create html
    html = `
        <tr>
            <td>
                <p class="createConnectionButton">Create a Connection</p>
            </td>
        </tr>
        <tr>
            <td>
                <p class="createConnectionText">Connect with ` + friend["name"] + `?</p>
            </td>
        </tr>
    `
    
    // Insert html
    $(".messagesTable").html(html);
    
    // Set connect button
    $(".createConnectionButton").unbind();
    $(".createConnectionButton").click(function(){
        var formData = {
            'user_1': council["id"],
            'user_2': friend["id"]
        };

        console.log(formData)

        // Send form to connect users
        $.ajax({
            type        : 'POST',
            url         : 'create_connection',
            data        : formData,
            dataType    : 'json'

        }).done(function(data) {

            console.log(data)
            
            // Get the users messages
            if(data.success) {
                getMessages(friend["id"], council["id"])
            }
        });
    })
}


/*
###########################################################
Purpose: Loads the messages onto the page
###########################################################
*/
function loadMessages(data_set, creation_date, council_member, friend){
    
    console.log(data_set)
    console.log(council_member)
    console.log(friend)
    
    // Set title
    $(".messagesDiv .titleCell p").text("Your Messages with " + friend["name"].split(" ")[0])
    
    // Set upper messages
    overall_html = `
        <tr>
            <td>
                <p class="messageUpper">Creation Date: ` + creation_date + `</p>
                <p class="messageUpper">Your Chat with ` + friend["name"] + `</p>
            </td>
        </tr>
    `;
    
    // For each message
    map_num = 0;
    for (data in data_set){
        data = data_set[data]
        
        // Check the sender
        if (data["sender_id"] == council_member["id"]){
            number = 1;
        }
        else{
            number = 2;
        }
        
        // What type of message is it?
        html = `<tr><td>`;
        
        // Text
        if (data["message_type"] == "T"){
            html = html + `<p class="message user` + number + `">` + data["contents"] + `</p>`;
        }
        
        // Maps
        else if (data["message_type"] == "M"){
            html = html + `<div id="mapTextNum` + map_num + `" lat="` + data["contents"].split(" ")[0] + `" long="` + data["contents"].split(" ")[1] + `" class="mapText user` + number + `"></div>`;
            map_num++;
        }
        
        // Pictures
        else if (data["message_type"] == "P"){
            html = html + `<img class="imageText user` + number + `" src="` + data["contents"] + `">`;
            map_num++;
        }
        
        // Add the date and time the message was sent
        html = html + `
                    </td>
                </tr>
                <tr>
                    <td>
                        <p class="message_date date` + number + `">` + data["date_sent"] + `</p>
                    </td>
                </tr>
                `
        overall_html = overall_html + html;
    }
    
    // Add html to table
    $(".messagesTable").html(overall_html);
    
    
    // For each map
    $(".mapText").each(function(){
        
        // Get the id and long and lat
        $id = $(this).attr("id");
        $long = parseFloat($(this).attr("long"));
        $lat = parseFloat($(this).attr("lat"));
        
        console.log("MAP ID: " + $id)
        
        // Create the map
        mapText = createMap($id, $lat, $long)
        
        // Set the marker
        var marker = new google.maps.Marker({
            position: {lat: $lat, lng: $long},
            map: mapText,
        });
		
		console.log("MAP Created: " + $id)
        
    })
    
    // Activate the ability for google maps and image sending
    activate_google_maps(council_member, friend)

    activate_photo(council_member, friend)
    
    
    // If user send text message
    $(".messagingBox input").unbind();
    $(".messagingBox input").keyup(function(e){
        
        // If enter key is pressed
        if(e.keyCode == 13){
            
            // Send message and reset
            sendMessage($(this).val(), council_member, friend, "T");
            $(this).val("");
            
        }
    })
    
    // Scroll messages to bottom
    setTimeout(function(){scrollToBottom()}, 50)
}


/*
###########################################################
Purpose: Scroll the messages to the bottom
###########################################################
*/
function scrollToBottom(){
    $(".messageHolderOverflow").animate({ scrollTop: $(".messagesTable").height() }, "fast");
}


/*
###########################################################
Purpose: Load all users to select for messaging
###########################################################
*/
function loadUsers(users_data, council_id){
    
    overall_html = "";
    
    // For each message
    for ($user in users_data){
        
        // Get the user data
        $user = users_data[$user]
        
        
        if ($user["user_type"] == "A"){
	        // Admin User
            $userTypeImage = "/Resources/Images/adminMessaging.png";
            $userTypeText = "Admin";
            
        } else if ($user["user_type"] == "M"){
	        // Maintenance User
            $userTypeImage = "/Resources/Images/maintenanceMessaging.png";
            $userTypeText = "Maintenance";
            
        } else {
	        // Council User
            $userTypeImage = "/Resources/Images/councilMessaging.png";
            $userTypeText = "Council";
        }
        
        console.log($user["picture"])
        
        // Create HTML
        html = `
            <div account_number="` + $user["id"] + `" class="userAccountDiv">
                <table>
                    <tr>
                        <td rowspan="2">
                            <div class="titleHeaderProfileImg userAccountsSearchImage" style="background-image: url(Resources/Images/Saved/` + $user["picture"] + `)"></div>
                        </td>
                        <td width=90%>
                            <p class="nameSearch">` + $user["name"] + `</p>
                        </td>
                        <td rowspan="2">
                            <img class="userTypeImage" src="` + $userTypeImage + `">
                            <p class="userType">` + $userTypeText + `</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p class="emailSearch">` + $user["email"] + `</p>
                        </td>
                    </tr>
                </table>
            </div>
        `
        
        // Join to overall html
        overall_html = overall_html + html;
    }
    
    // Set html
    $(".accountSearchTD").html(overall_html);
    
    // If the user selects an account
    $(".userAccountDiv").click(function(){
        
        // Load data
        friend = $(this).attr("account_number")
        post_load_users(friend, council_id)
        
        // Move screen if in mobile mode
        if (mobile_mode){
            $(".mainTableContent").css("left", "-100%");
        }
        
    })
}


/*
###########################################################
Purpose: Loads the messages for users
###########################################################
*/
function post_load_users(friend, council_id){
    
    // Get messages
    getMessages(friend, council_id)

    // Reload messages every 5 seconds [This causes me to be band]
    /*
    clearInterval($search_messages)
    $search_messages = setInterval(function(){
        console.log("Checking messages")
        getMessages(friend, council_id);
    }, 5000)
*/

    
}


/*
###########################################################
Purpose: Allows users to send photo messages
###########################################################
*/
function activate_photo(council, friend){
    
    
    // If the photo button is pressed
    $("#takePhoto").unbind();
    $("#takePhoto").click(function(){
        console.log("Getting File")
        
        // Trigger the input
        $('#photoPicked').trigger('click'); 
        
    })
    
    // If the input has updated
    $('#photoPicked').unbind();
    $('#photoPicked').change(function(){
        
        // Send image
        $("#photoForm").unbind();
        $("#photoForm").submit(function(e){
            e.preventDefault();
            
            var formData = new FormData(this);
            
            console.log(formData)
            
            $.ajax({
                type        : 'POST',
                url         : 'save_image_text',
                data        : formData,
                dataType    : 'json',
                cache: false,
                contentType: false,
                processData: false

            }).done(function(data) {
                
                // Send message with the location of the image
                image_location = data["value"];
                
                sendMessage(image_location, council, friend, "P")
                
            });
            
        })
        
        $("#photoForm").submit();
        
    })
}


/*
###########################################################
Purpose: Get the users messages with their other user
###########################################################
*/
function getMessages(friend_id, council_id){
    
    // User IDS
    var formData = {
        'user_1': parseInt(friend_id),
        'user_2': parseInt(council_id)
    };
    
    
    // Get messages
    $.ajax({
        type        : 'POST',
        url         : 'get_messages',
        data        : formData,
        dataType    : 'json'

    }).done(function(data) {
        
        // Format which user is which
        if (data["user1"]["id"] == council_id){
            council_member = data["user1"]
            friend = data["user2"]
        }
        else{
            council_member = data["user2"]
            friend = data["user1"]
        }
        
        // Offer user connection if connection is not set
        if (data["value"] == null){
            clearInterval($search_messages)
            connect_users(friend, council_member);
        }
        else{
            // Set messages
            if ($previous_messages == null){
                postGetMessages(data)
            }
            else if ($previous_messages.length != data["value"].length){
                postGetMessages(data)
            }
            
        }

    });
}


/*
###########################################################
Purpose: Set new message attributes
###########################################################
*/
function postGetMessages(data){
    
    // Alert if there is a new message
    if ($previous_messages != null){
        var audio = new Audio('/Resources/Sounds/text.mp3');
        audio.loop = false;
        audio.play();
    }
    
    // Load messages
    loadMessages(data["value"], data["creation_date"], council_member, friend);
    
    // Set messages to compare
    $previous_messages = data["value"];
}


/*
###########################################################
Purpose: Sends a message for a user
###########################################################
*/
function sendMessage(message, council, friend, type){
    
    // Create form
    var formData = {
        'message': message,
        'type': type,
        'council': council["id"],
        'friend': friend["id"]
    };
    
    console.log(formData);
    
    // Send message
    $.ajax({
        type        : 'POST',
        url         : 'send_message',
        data        : formData,
        dataType    : 'json'

    }).done(function(data) {
        
        
        getMessages(friend["id"], council["id"])
        
        
        
    });
}



/*
###########################################################
Purpose: Gets Users from the database
###########################################################
*/
function getUsers(search, council_id){
    
    // Set form
    var formData = {
        'search': search,
        'council_id': council_id
    };
        
    // Get Users from database
    $.ajax({
        type        : 'GET',
        url         : 'get_message_users_accounts',
        data        : formData,
        dataType    : 'json'

    }).done(function(data) {

        
        if(data.success && data['value'].length != 0 ) {
            loadUsers(data['value'], council_id);
        }
        else{
            noUsersFound();
        }
    });
}


/*
###########################################################
Purpose: Create a map
###########################################################
*/
function createMap(map, lat_, lng_){
    var mainMap = new google.maps.Map(document.getElementById(map), {
        center: {lat: lat_, lng: lng_},
        zoom: 13,
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }); 
    return mainMap;
}


/*
###########################################################
Purpose: Google maps main
###########################################################
*/
function activate_google_maps(council, friend){
    console.log("Enabling Google Maps")
    
    // Default
    mainMap = null;
    marker = null;
        
    // Get the users current location
    navigator.geolocation.getCurrentPosition(function(position){
        const latitude  = position.coords.latitude;
        const longitude = position.coords.longitude;
        
        // Create map
        mainMap = createMap("map_create", latitude, longitude)
        
        // Create marker
        marker = new google.maps.Marker({
            position: {lat: latitude, lng: longitude},
            map: mainMap,
        });
        
        // Add click event
        google.maps.event.addListener(mainMap, 'click', function(e){
            
            if (marker != null){
                // Remove the previous marker
                marker.setMap(null);
            }

            // Create a new marker with the new position
            marker = new google.maps.Marker({
                position: e.latLng,
                map: mainMap,
            });
            mainMap.setCenter(e.latLng);
        });
        
    }, function(){});
    
    
    // Cancel map message
    $("#cancelMap").click(function(){
        $(".googleMapsDisplay").css("left", "150%");
        marker.setMap(null);
    })
    
    // Send map message
    $("#sendMap").unbind();
    $("#sendMap").click(function(){
        
        // Create message text
        var lat = marker.getPosition().lat();
        var lng = marker.getPosition().lng();
        
        message = lat + " " + lng;
        
        // Send message    
        sendMessage(message, council, friend, "M");
        
        // Move off screen
        $(".googleMapsDisplay").css("left", "150%");
        
        marker.setMap(null);
        
    })
    
    // Use the users current location
    $("#useMyLocation").unbind()
    $("#useMyLocation").click(function(){
        
        // Get users location
        navigator.geolocation.getCurrentPosition(function(position){
            
            if (marker != null){
                // Remove the previous marker
                marker.setMap(null);
            }
            
            // Get long lat
            const latitude  = position.coords.latitude;
            const longitude = position.coords.longitude;

            var myLatlng = new google.maps.LatLng(latitude, longitude);
            
            // Set pin
            var marker = new google.maps.Marker({
                position: myLatlng,
                map: mainMap,
            });
            
            // Center map
            mainMap.setCenter(marker.getPosition());
            
        }, function(){});
    })
    
    
    // Bring map on screen
    $("#takeMap").unbind();
    $("#takeMap").click(function(){
        $(".googleMapsDisplay").css("left", "50%");
    })
    
    
    
}


mobile_mode = false;

/*
###########################################################
Purpose: Begining function
###########################################################
*/
function main(council_id, friend, mobile_mode_var){
    
    // If the user is trying to message themselves
    if (council_id == friend){
        friend = -1;
    }
    
    // Mobile mode?
    mobile_mode = mobile_mode_var;
    
    // If there is a shortcut to speak to a friend
    if (friend > -1){
        if (mobile_mode){
            $(".mainTableContent").css("left", "-100%");
        }
        post_load_users(friend, council_id);
    }
    
    // Back button on mobile
    $(".backImage").click(function(){
        $(".mainTableContent").css("left", "0%");
    })
    
    // For searching for users
    $(".searchUsersBar input").keyup(function(){
        
        getUsers($(this).val(), council_id)
        
    })
}



















