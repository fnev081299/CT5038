
/*
######################################################################
 Author : Luke Gassmann
 Description : This page animates a slide show element
######################################################################
*/

var increment = 0;
    
// Set an interval to move the slide show from left to right
setInterval(function(){
	
	// Return to start
    if (increment == 2){
        increment = 0;
        $(".slideshowTable").css("left", "0px");
    }
	
	// Move to next
    else{
        $(".slideshowTable").css("left", "-=" + $(".slide").width());
        increment++;
    }
}, 7500);

// If the window resizes return to the start
$(window).resize(function(){
    increment = 0;
    $(".slideshowTable").css("left", "0px");
})






