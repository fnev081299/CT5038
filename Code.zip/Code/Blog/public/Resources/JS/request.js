/*
######################################################################
 Author : Nicolas Euliarte
 Description : requesting a new inquiry
######################################################################
*/

var long;
var lat;

// Displays the map and the on click on the map for the pin drop
function mainRequest() {
	// Select the Map Div and focus on this location
   var mainMap = new google.maps.Map(document.getElementById('map'), {
       	center: {lat: 51.8994, lng: -2.0783},
       	zoom: 11,
        disableDefaultUI: true,
       	mapTypeId: google.maps.MapTypeId.ROADMAP
   });
	
	// Create marker
        var marker = new google.maps.Marker({
            map: mainMap
        });
	
	// Set event listener on the google maps div
        google.maps.event.addListener(mainMap, 'click', function(e){
           
                // Remove the previous marker
                marker.setMap(null);

                // Create a new marker with the new position
                marker = new google.maps.Marker({
                    position: e.latLng,
                    map: mainMap
                });
                mainMap.setCenter(e.latLng);
			
			long = e.latLng.lng();
			lat = e.latLng.lat();
        })
}

// sending a new request
function newRequest() {
	
	// data for the inquiry
	var formData = {
		'drop_down': $('select option:selected').val(),
		'description': $('#desc').val(),
		'emailAdder': $('#eml').val(),
		'lat':lat,
		'long':long
	};
	
	
	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
		}
	});
	
	// Send formData to class.functions.php
	$.ajax({
		type        : 'POST',
		url         : 'request_submit',
		data        : formData,
		dataType    : 'json',
		encode      : true
	}).done(function(data) {
		console.log(data)
		if(data.success) {
			// alert user that account has been made and return to homepage
			alert( "Added" );
			//window.location.href = "/request";
		} else {
			alert(data.error);
		}
	});
}


