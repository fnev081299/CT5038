
/*
######################################################################
 Author : Josh
 Description : JS for the map include
######################################################################
*/



	// global values
	var map;
	
	const createMap = () => {
		
		var mapOptions = {
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			draggable: true,
			scrollwheel: true,
			navigationControl: true,
			mapTypeControl: true,
			scaleControl: true,
			zoom: 16,
			zoomControl: true,
			streetViewControl: true
		};
		
		map = new google.maps.Map(document.getElementById('map'), mapOptions);
		
		map.setOptions({styles: mapStyles});
		
		return map;
	};
	
	
	const createMarker = ({ map, position }) => {
	  return new google.maps.Marker({ map, position });
	}
	
	// Track user location
	const trackLocation = ({ onSuccess, onError = () => { } }) => {
	  if ('geolocation' in navigator === false) {
	    return onError(new Error('Geolocation is not supported by your browser.'));
	  }
	
	  return navigator.geolocation.watchPosition(onSuccess, onError, {
	    enableHighAccuracy: true,
	    timeout: 5000,
	    maximumAge: 0
	  });
	}
	
	// Define error messages
	const getPositionErrorMessage = code => {
	  switch (code) {
	    case 1:
	      return 'Permission denied.';
	    case 2:
	      return 'Position unavailable.';
	    case 3:
	      return 'Timeout reached.';
	  }
	}
	
	// run after page load 
	function init() {
		const initialPosition = { lat: 0, lng: 0 };
		const map = createMap();
		const marker = createMarker({ map, position: initialPosition });
		const $info = document.getElementById('info');
		
		let watchId = trackLocation({
			onSuccess: ({ coords: { latitude: lat, longitude: lng } }) => {
				marker.setPosition({ lat, lng });
				//map.panTo({ lat, lng });
				$info.classList.remove('error');
			},
			onError: err => {
				console.log($info);
				$info.textContent = `Error: ${err.message || getPositionErrorMessage(err.code)}`;
				$info.classList.add('error');
			}
		});
	}
	window.onload = init();

        
        
        
        @foreach($information["bowserData"] as $bowser)
	        <?php
	        $bowserlon = $bowserInfo["longitude"];
	        $bowserlat = $bowserInfo["latitude"];
	        $bowserID = $bowserInfo["BowserID"];
	        $bowserStatus = $bowserInfo["bowserStatus"];
	        $bowserAddress = $bowserInfo["bowserAddress"];
	        $bowserRadius = $bowserInfo["size"];
	        ?>
	        var myLatlng = new google.maps.LatLng({{$bowserlat}},{{$bowserlon}});
	
	        var icon = {
	            
	            url: @if($bowserStatus == 0)         
	                    "Resources/Images/waterMap.png"
	                @elseif ($bowserStatus == 1)
	                    "Resources/Images/tools.png"
	                @elseif ($bowserStatus == 2)
	                    "Resources/Images/waterMap.gif"
	                @elseif ($bowserStatus == 3)
	                    "Resources/Images/waterDeploy.png"
	                @endif,
	            scaledSize: new google.maps.Size(50, 50), // scaled size
	        };
	    
	        var marker{{$bowserID}} = new google.maps.Marker({
	            position: myLatlng,
	            title:"<?php echo "Bowser ID: " . $bowserID . " - " . $bowserAddress; ?>",
	            map: mainMap,
	            icon: icon
	        });
	    
	        // Add circle overlay and bind to marker
	        var circle = new google.maps.Circle({
	          map: mainMap,
	          radius: {{$bowserRadius}}*10,    // 100 Liter = 10km
	          fillColor: '#AA0000',
	            strokeColor: '#6600AA',
	            strokeOpacity: 0.8,
	            strokeWeight: 2,
	            fillColor: '#6600AA',
	            fillOpacity: 0.35,
	        });
	        circle.bindTo('center', marker{{$bowserID}}, 'position');
	
	        google.maps.event.addListener(marker{{$bowserID}}, 'click', function() {
	            $(".mainContentsSwipeTable").css("left", "-100%");
	            $(".mapBackground").css("opacity", "0");
	            $(".mapBackground").css("pointer-events", "none");
	            $(".statsDiv").css("opacity", "1");
	            $(".statsDiv").css("pointer-events", "auto")
	            $(".bowserStatsButton p").addClass("focusedTabButton")
	            $(".mapCoverageButton p").removeClass("focusedTabButton");
	            
	            $("#searchBarBowser").val({{$bowserID}});
	            statsData();
	        });
    
        @endforeach
        
