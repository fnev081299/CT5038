<?php

    // ##################################################################
    // Author: Zayd Dawood
    // Last Update: 4th January 2020
    // Purpose: Creates a session to connect to the Database
    // ##################################################################
    

    // Display PHP errors
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    // Start Session with database 
    ob_start();
	session_start();

	// Database credentials
	define( 'DBHOST', 'localhost' );
	define( 'DBUSER', 'CT5038Group2' );
	define( 'DBPASS', '126Ub-g@zo(GiURF' );
	define( 'DBNAME', 'CT5038Group2_' ); 

    // Conect to database
	$db = new PDO( "mysql:host=" . DBHOST . ";port=8889;dbname=" . DBNAME, DBUSER, DBPASS);
	$db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

	//set timezone
	date_default_timezone_set('Europe/London');
	echo "Database Set Up";
?>

